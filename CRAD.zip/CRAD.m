%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CRAD: for peak picking and denoising before the origin, application, or composition of a sample are known
%%% Copyright (C) <2016>  Wang Renqi
%%% This program is free software: you can redistribute it and/or modify
%%% it under the terms of the GNU General Public License as published by
%%% the Free Software Foundation, either version 3 of the License, or
%%% any later version.


%%% This program is distributed in the hope that it will be useful,
%%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%%% GNU General Public License for more details.

%%% For details of the GNU General Public License, please see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SamNoSt = 1; %Sample number Start spot
SamNoEn = 2;%Sample number End spot
ConNo = 5;  %Total Condition No
PXSet =10;
RelArea = 0.2;
IntensityThreshold = 1.25*10^4;
IRT = 0.01; %minimum isotope ratio of detected ions (C13/C12 1.1/100; S34/S32 4.5/100;
TimeDifferTor = 0.5;
MassDifferTor = 0.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

t00=cputime;
IMI = 0.09;
files = dir(fullfile('.', '*.txt'));
[nOfFiles,~] = size(files);

Mats = dir(fullfile('.', '*.mat'));
[nOfMats,~]=size(Mats);

for CRAD_Calculation=1:1
    
    for SamID=SamNoSt:SamNoEn
        for ConID=1:ConNo
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:3),'Sam'))
                    MaSuUV(1,1)=0;
                    
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                                && strcmp(files(iFile).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                                && strcmp(files(iFile).name(13),'.')
                            MaSuUV(1,1)=9;
                        end
                    end
                    
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iFile).name);
                        UVTempLS=size(UVTemp,1);
                        TIRA =UVTemp(UVTempLS,1);
                        
                        UVSPOR = load(files(iFile).name);
                        UVLS  = size(UVSPOR,1);
                        UVSP(1:UVLS, 1:2) = UVSPOR(1:UVLS, 1:2);
                        HighPoint = max(UVSP(:,2));
                        LowPoint  = min(UVSP(:,2));
                        sectionNo = 100;
                        Incre     = (HighPoint-LowPoint)/sectionNo;
                        section   = zeros(sectionNo,3);
                        
                        for i=1:sectionNo
                            section(i,1) = Incre*(i-1)+LowPoint;
                            section(i,2) = Incre*i+LowPoint;
                            section(i,3) = 0;
                        end;
                        
                        for j=1:UVLS
                            for u=1:sectionNo
                                if (UVSP(j,2)>=section(u,1) && ...
                                        UVSP(j,2)<section(u,2) )
                                    section(u,3)=section(u,3)+1;
                                end;
                            end;
                        end;
                        chooseSection=max(section(:,3));
                        
                        for i=1:sectionNo
                            if section(i,3)==chooseSection
                                baselineLow=section(i,1);
                                baselineHigh=section(i,2);
                            end;
                        end;
                        
                        BaseLineValue=0;
                        count=0;
                        
                        for i=1:UVLS
                            if (UVSP(i,2)>=baselineLow && ...
                                    UVSP(i,2)<baselineHigh)
                                BaseLineValue=BaseLineValue+UVSP(i,2);
                                count=count+1;
                            end;
                        end;
                        BaseLineValue=BaseLineValue/count;
                        
                        UVSP(:,2) = UVSP(:,2)-BaseLineValue;
                        
                        DeadTime=0.001;
                        DPT=0;
                        for i=2:UVLS-1
                            if (UVSP(i,2)>=UVSP(i-1,2) && ...
                                    UVSP(i,2)>=UVSP(i+1,2) && ...
                                    UVSP(i,2)-UVSP(1,2)> HighPoint*DeadTime && ...
                                    ( UVSP(i,2)-UVSP(i-1,2))+...
                                    (UVSP(i,2)-UVSP(i+1,2))~=0 )&& DPT==0
                                t0=UVSP(i,1);
                                DPT=1;
                            end;
                        end;
                    end;
                    
                    
                    
                    if MaSuUV(1,1)>0
                        fr = 15;
                        dt = 0.01;
                        rick = ricker(160,fr,dt,20);
                        rick_smooth = getSmoothRicker(rick);
                        MaxMajorPeakNo=PXSet;
                        MajorPeakThreshold=RelArea;
                        for iMat=1:nOfMats
                            if strcmp( Mats(iMat).name(1:3),'Sam')
                                nPeakInforSummaryGS=0;
                                
                                MaSuMa(1,1)=0;
                                MaSuMa(1,1)=0;
                                if SamID<10 && ConID<10
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                            && (strcmp(Mats(iMat).name(9),'N') || strcmp(Mats(iMat).name(9),'P'))...
                                            && strcmp(Mats(iMat).name(10),'.')
                                        MaSuMa(1,1)=1;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID<10
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'N') || strcmp(Mats(iMat).name(10),'P'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=2;
                                    end
                                end
                                if SamID>=100 && ConID<10
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=3;
                                    end
                                end
                                if SamID<10 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'N') || strcmp(Mats(iMat).name(10),'P'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=4;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=5;
                                    end
                                end
                                if SamID>=100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'N') || strcmp(Mats(iMat).name(12),'P'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=6;
                                    end
                                end
                                if SamID<10 && ConID>=100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=7;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'N') || strcmp(Mats(iMat).name(12),'P'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=8;
                                    end
                                end
                                if SamID>=100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                            && (strcmp(Mats(iMat).name(13),'N') || strcmp(Mats(iMat).name(13),'P'))...
                                            && strcmp(Mats(iMat).name(14),'.')
                                        MaSuMa(1,1)=9;
                                    end
                                end
                                if MaSuMa(1,1)>0
                                    data = load(Mats(iMat).name);
                                    Scans=data.Scans;
                                    dataWidth=size(Scans,2);
                                    MergeMass=data.Masses;
                                    dataLength=size(MergeMass,1);
                                    MergeData=data.Data;
                                    FixedWidth=162;
                                    AcualWidth=dataWidth;
                                    Ratio=round(AcualWidth/FixedWidth);
                                    if Ratio>=1
                                        iCol=0;
                                        for k=1:Ratio:AcualWidth-Ratio
                                            iCol=iCol+1;
                                            dataTemp(1:dataLength,1:Ratio)=MergeData(1:dataLength,k:k+Ratio-1);
                                            for o=1:dataLength
                                                Data_New(o,iCol)=sum(dataTemp(o,1:Ratio));
                                            end
                                            MergeTime(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+Ratio-1))/Scans(1,dataWidth)*TIRA;
                                        end
                                    else
                                        Ratio2=Round(FixedWidth/AcualWidth);
                                        iCol=Ratio2*AcualWidth;
                                        for o=1:dataWidth
                                            MergeTime(1,o*Ratio2-Ratio2+1:o*Ratio2)=Scans(1,o)/Scans(1,dataWidth)*TIRA;
                                            for k=1:dataLength
                                                Data_New(k,o*Ratio2-Ratio2+1:o*Ratio2)=MergeData(k,o);
                                            end
                                        end
                                    end
                                    dataWidth=iCol;
                                    
                                    XIC=zeros(dataWidth,2);
                                    nPeakInforSummaryGS=0;
                                    
                                    
                                    for h=6:dataLength-5
                                        
                                        for j=1:dataWidth
                                            XIC(j,1)=MergeTime(1,j);
                                            XIC(j,2)=sum(Data_New(h,j));
                                        end
                                        
                                        smoothXIC0  = conv( rick_smooth(:,1),XIC(:,2) );
                                        smoothXIC(:,1)=XIC(:,1);
                                        smoothXIC(:,2)=smoothXIC0( round(length(rick_smooth)/2)+1:length(XIC(:,2))+round(length(rick_smooth)/2));
                                        smoothXICLength=size(smoothXIC,1);
                                        
                                        PeakThreshold=0.01;
                                        PeakPointGSNo=0;
                                        HighPoint=max(smoothXIC(:,2));
                                        for i=2:smoothXICLength-1
                                            if smoothXIC(i,2)>=smoothXIC(i-1,2) && smoothXIC(i,2)>=smoothXIC(i+1,2) && smoothXIC(i,2)> HighPoint*PeakThreshold && (smoothXIC(i,2)-smoothXIC(i-1,2))+(smoothXIC(i,2)-smoothXIC(i+1,2))~=0
                                                PeakPointGSNo=PeakPointGSNo+1;
                                                PeakPointGS(PeakPointGSNo,1) = smoothXIC(i,1);
                                                PeakPointGS(PeakPointGSNo,2) = smoothXIC(i,2);
                                            end;
                                        end;
                                        
                                        BaseLineTolerance=0.01;
                                        nPeakInfor=0;
                                        
                                        if PeakPointGSNo>0
                                            for m=1:PeakPointGSNo
                                                PeakTime=PeakPointGS(m,1);
                                                PeakHight=PeakPointGS(m,2);
                                                PeakPosition(1,1)=PeakPointGS(m,1);
                                                PeakPosition(1,2)=PeakPointGS(m,2);
                                                halfPH=PeakHight/2;
                                                
                                                for z=1:smoothXICLength
                                                    if smoothXIC(z,1)==PeakTime
                                                        PP=z;
                                                    end;
                                                end;
                                                
                                                vbv1=0;
                                                for z=PP:-1:2
                                                    if smoothXIC(z,2)>=0 && smoothXIC(z-1,2)<=0 && vbv1==0
                                                        CrossZeroLeft=smoothXIC(z,1);
                                                        LeftIndex=z;
                                                        vbv1=1;
                                                    end;
                                                end;
                                                
                                                if vbv1==0
                                                    CrossZeroLeft=0;
                                                    LeftIndex=1;
                                                end;
                                                
                                                vbv2=0;
                                                for z=PP:smoothXICLength-1
                                                    if smoothXIC(z,2)>=0 && smoothXIC(z+1,2)<=0 && vbv2==0
                                                        CrossZeroRight=smoothXIC(z,1);
                                                        RightIndex=z;
                                                        vbv2=1;
                                                    end;
                                                end;
                                                
                                                if vbv2==0
                                                    CrossZeroRight=smoothXIC(smoothXICLength,1);
                                                    RightIndex=smoothXICLength;
                                                end;
                                                
                                                PeakPointGS(m,3)=CrossZeroLeft;
                                                PeakPointGS(m,4)=CrossZeroRight;
                                                PeakPointGS(m,5)=(CrossZeroRight-CrossZeroLeft)/TIRA;
                                                PeakPointGS(m,6)=PeakHight/HighPoint;
                                                PeakPointGS(m,7)=PeakPointGS(m,6)/PeakPointGS(m,5);
                                                
                                                
                                                if LeftIndex>1 && RightIndex<smoothXICLength
                                                    PeakPointGS(m,8)=0;
                                                    for z=LeftIndex:RightIndex
                                                        PeakPointGS(m,8)=PeakPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                    end
                                                end
                                                if LeftIndex==1 && RightIndex<smoothXICLength
                                                    PeakPointGS(m,8)=(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                    for z=2:RightIndex
                                                        PeakPointGS(m,8)=PeakPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                    end
                                                end
                                                if LeftIndex>1 && RightIndex==smoothXICLength
                                                    PeakPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                    for z=LeftIndex:RightIndex-1
                                                        PeakPointGS(m,8)=PeakPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                    end
                                                end
                                                
                                                if LeftIndex==1 && RightIndex==smoothXICLength
                                                    PeakPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                    PeakPointGS(m,8)=PeakPointGS(m,8)+(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                    for z=2:smoothXICLength-1
                                                        PeakPointGS(m,8)=PeakPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                    end
                                                end
                                            end;
                                            
                                            PeakPointGSShort(1,:)=PeakPointGS(1,:);
                                            nPPShort=1;
                                            for z=1:PeakPointGSNo
                                                if PeakPointGS(z,1)-PeakPointGSShort(nPPShort,1)<TimeDifferTor
                                                    if PeakPointGS(z,2)>PeakPointGSShort(nPPShort,2)
                                                        PeakPointGSShort(nPPShort,1)=PeakPointGS(z,1);
                                                        PeakPointGSShort(nPPShort,2)=PeakPointGS(z,2);
                                                    end;
                                                    if PeakPointGS(z,3)>PeakPointGSShort(nPPShort,3)
                                                        PeakPointGSShort(nPPShort,3)=PeakPointGS(z,3);
                                                    end;
                                                    if PeakPointGS(z,4)<PeakPointGSShort(nPPShort,4)
                                                        PeakPointGSShort(nPPShort,4)=PeakPointGS(z,4);
                                                    end;
                                                    PeakPointGSShort(nPPShort,5)=(PeakPointGSShort(nPPShort,4)-PeakPointGSShort(nPPShort,3))/TIRA;
                                                    PeakPointGSShort(nPPShort,6)=PeakPointGSShort(nPPShort,2)/HighPoint;
                                                    PeakPointGSShort(nPPShort,7)=PeakPointGSShort(nPPShort,6)/PeakPointGSShort(nPPShort,5);
                                                    PeakPointGSShort(nPPShort,8)=(PeakPointGSShort(nPPShort,4)-PeakPointGSShort(nPPShort,3))*PeakPointGSShort(nPPShort,2)/2;
                                                else
                                                    nPPShort=nPPShort+1;
                                                    PeakPointGSShort(nPPShort,:)=PeakPointGS(z,:);
                                                end;
                                            end;
                                            
                                            LargestPeak=max(PeakPointGSShort(:,8));
                                            
                                            PeakPointGSShort(:,9)=PeakPointGSShort(:,8)/LargestPeak;
                                            
                                            if nPPShort>0
                                                PeakPointGSShort=sortrows(PeakPointGSShort,-9);
                                                countNoMajor=0;
                                                for z=1:nPPShort
                                                    if (PeakPointGSShort(z,9)>MajorPeakThreshold &&...
                                                            PeakPointGSShort(z,1)>t0)
                                                        countNoMajor=countNoMajor+1;
                                                    end;
                                                end;
                                                if countNoMajor<=MaxMajorPeakNo
                                                    for z=1:nPPShort
                                                        if (PeakPointGSShort(z,9)>MajorPeakThreshold && ...
                                                                PeakPointGSShort(z,7)>MajorPeakThreshold/PeakPointGSShort(z,5) && ...
                                                                PeakPointGSShort(z,1)>t0 && PeakPointGSShort(z,4)<TIRA-1)
                                                            nPeakInforSummaryGS=nPeakInforSummaryGS+1;
                                                            PeakInforSummaryGS(nPeakInforSummaryGS,1)=MergeMass(h,1);
                                                            PeakInforSummaryGS(nPeakInforSummaryGS,2:10)=PeakPointGSShort(z,1:9);
                                                        end;
                                                    end;
                                                end
                                            end;
                                            clear PeakPointGS LeftPoint RightPoint PeakPointGSShort ...
                                                width PeakPosition;
                                        end;
                                        clear XIC smoothXIC section;
                                        
                                        
                                        
                                    end;
                                    t01=cputime-t00;
                                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                                        'Con',num2str(ConID),'_Step1.2']);
                                end
                                
                                
                                
                                if nPeakInforSummaryGS>0
                                    PIG=PeakInforSummaryGS(:,1);
                                    PIGS=unique(PIG,'rows');
                                    
                                    PISGSLength = size(PeakInforSummaryGS,1);
                                    PeakAreaMax=max(PeakInforSummaryGS(:,9));
                                    PeakInforSummaryGSTemp=zeros(PISGSLength,11);
                                    PeakInforSummaryGSTemp(1:PISGSLength,1:10) = PeakInforSummaryGS(1:PISGSLength,1:10);
                                    PeakInforSummaryGSTemp(1:PISGSLength,11)   = PeakInforSummaryGSTemp(1:PISGSLength,9)/PeakAreaMax;
                                    
                                    
                                    t01=cputime-t00;
                                    disp(['squezzing time1 = ',num2str(t01), ' seconds' ]);
                                    
                                    PeakInforSummaryGS2=zeros(PISGSLength,13);
                                    nPeakInforSummaryGS2=0;
                                    for i=1:PISGSLength
                                        if PeakInforSummaryGSTemp(i,9)>IntensityThreshold
                                            for j=1:PISGSLength
                                                hit=0;
                                                hot=0;
                                                if PeakInforSummaryGSTemp(j,9)>IntensityThreshold
                                                    if PeakInforSummaryGSTemp(i,1)-(PeakInforSummaryGSTemp(j,1))<-1/3+IMI &&...
                                                            PeakInforSummaryGSTemp(i,1)-(PeakInforSummaryGSTemp(j,1))>=-1-IMI && ...
                                                            abs(PeakInforSummaryGSTemp(i,2)-(PeakInforSummaryGSTemp(j,2)))<TimeDifferTor &&...
                                                            PeakInforSummaryGSTemp(j,11)/PeakInforSummaryGSTemp(i,11)<1 && ...
                                                            PeakInforSummaryGSTemp(j,11)/PeakInforSummaryGSTemp(i,11)>=IRT
                                                        IsotopeRatio=PeakInforSummaryGSTemp(j,11)/PeakInforSummaryGSTemp(i,11);
                                                        hit=1;
                                                        hot=1;
                                                    end
                                                    if PeakInforSummaryGSTemp(j,1)-(PeakInforSummaryGSTemp(i,1))<-1/3+IMI &&...
                                                            PeakInforSummaryGSTemp(j,1)-(PeakInforSummaryGSTemp(i,1))>=-1-IMI && ...
                                                            abs(PeakInforSummaryGSTemp(i,2)-(PeakInforSummaryGSTemp(j,2)))<TimeDifferTor &&...
                                                            PeakInforSummaryGSTemp(i,11)/PeakInforSummaryGSTemp(j,11)<1 && ...
                                                            PeakInforSummaryGSTemp(i,11)/PeakInforSummaryGSTemp(j,11)>=IRT
                                                        IsotopeRatio=PeakInforSummaryGSTemp(i,11)/PeakInforSummaryGSTemp(j,11);
                                                        hit=1;
                                                    end
                                                end
                                                if hit==1
                                                    nPeakInforSummaryGS2=nPeakInforSummaryGS2+1;
                                                    PeakInforSummaryGS2(nPeakInforSummaryGS2,1:11)=PeakInforSummaryGSTemp(i,1:11);
                                                    if hot==1
                                                        PeakInforSummaryGS2(nPeakInforSummaryGS2,12)=IsotopeRatio;
                                                    else
                                                        PeakInforSummaryGS2(nPeakInforSummaryGS2,13)=IsotopeRatio;
                                                    end
                                                end
                                            end
                                        end
                                    end
                                    
                                    PeakInforSummaryGS2T=PeakInforSummaryGS2(1:nPeakInforSummaryGS2,1:13);
                                    clear PeakInforSummaryGS2
                                    PeakInforSummaryGS2=PeakInforSummaryGS2T;
                                    clear PeakInforSummaryGS2T
                                    
                                    
                                    if size(PeakInforSummaryGS2,1)>0
                                        t02=cputime-t00;
                                        disp(['squezzing time2 = ',num2str(t02), ' seconds' ]);
                                        
                                        nPeakInforSummaryGS3=0;
                                        for i=1:nPeakInforSummaryGS2
                                            if PeakInforSummaryGS2(i,12)>0
                                                nPeakInforSummaryGS3=nPeakInforSummaryGS3+1;
                                                PeakInforSummaryGS3(nPeakInforSummaryGS3,1:12)=PeakInforSummaryGS2(i,1:12);
                                            end
                                        end
                                        
                                        if nPeakInforSummaryGS3>0
                                            for i=1:nPeakInforSummaryGS3
                                                Temp=PeakInforSummaryGS3(i,:);
                                                for j=1:nPeakInforSummaryGS3
                                                    if abs(PeakInforSummaryGS3(i,1)-PeakInforSummaryGS3(j,1))<1 && ...
                                                            abs(PeakInforSummaryGS3(i,2)-PeakInforSummaryGS3(j,2))<0.1 && ...
                                                            PeakInforSummaryGS3(j,11)>=Temp(1,11)
                                                        Temp=PeakInforSummaryGS3(j,:);
                                                    end
                                                end
                                                PeakInforSummaryGS4(i,:)=Temp;
                                                clear Temp
                                            end
                                            
                                            
                                            t03=cputime-t00;
                                            disp(['squezzing time3 = ',num2str(t03), ' seconds' ]);
                                            
                                            if size(PeakInforSummaryGS4,1)>0
                                                PeakInforSummaryGS5=unique(PeakInforSummaryGS4,'rows');
                                                nPeakInforSummaryGS5=size(PeakInforSummaryGS5,1);
                                                
                                                PIG5=PeakInforSummaryGS5(:,1);
                                                PIG5S=unique(PIG5,'rows');
                                                
                                                
                                                clear PeakInforSummaryGSTemp;
                                                
                                                
                                                t04=cputime-t00;
                                                disp(['squezzing time4 = ',num2str(t04), ' seconds' ]);
                                                
                                                MajorPeakThreshold=round(MajorPeakThreshold*1000)/1000;
                                                dataOutputShort=PeakInforSummaryGS5(1:nPeakInforSummaryGS5, 1:12);
                                                [~, outputFile0] = fileparts( Mats(iMat).name );
                                                outputFilename = strcat( 'DENO',outputFile0,'.txt' );
                                                save(outputFilename,'dataOutputShort','-ascii');
                                                clearvars -except ConID ConNo IMI IRT IntensityThreshold MajorPeakThreshold ...
                                                    MassDifferTor Mats MaxMajorPeakNo PXSet RelArea SamID SamNoEn SamNoSt TimeDifferTor ...
                                                    dt files fr iFile iMat nOfFiles nOfMats DPT DeadTime TIRA rick rick_smooth t0 t00
                                            end
                                        end
                                    end
                                end
                                
                            end
                        end
                    end
                end
                clearvars -except ConID ConNo IMI IRT IntensityThreshold MassDifferTor Mats PXSet RelArea SamID SamNoEn SamNoSt ...
                    TimeDifferTor files iFile nOfFiles nOfMats t00
            end
        end
        t01=cputime-t00;
        disp(['Step1 = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),'Con',num2str(ConID)]);
    end
    t01=cputime-t00;
    disp(['Step1 = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    
    
    ITD=0.05;
    MR=3;
    ML=0.9;
    MA=2;
    
    load Mobile_Phase.txt
    MB=Mobile_Phase;
    MBLength=size(MB,1);
    
    
    files = dir(fullfile('.', '*.txt'));
    [nOfFiles,~] = size(files);
    
    
    for SamID=SamNoSt:SamNoEn
        
        LengthRef=0;
        for ConID=1:ConNo
            for iFile=1:nOfFiles
                if (strcmp( files(iFile).name(1:4),'DENO'))
                    MaSuDN(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'N')
                            MaSuDN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuDN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuDN(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuDN(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuDN(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'N')
                            MaSuDN(1,1)=9;
                        end
                    end
                    
                    if MaSuDN(1,1)>0
                        dataTemp=load(files(iFile).name);
                        LengthTemp=size(dataTemp,1);
                        dataSummary(1:LengthTemp,1,ConID)=dataTemp(1:LengthTemp,1);
                        dataSummary(1:LengthTemp,2,ConID)=dataTemp(1:LengthTemp,2);
                        dataSummary(1:LengthTemp,3,ConID)=dataTemp(1:LengthTemp,7);
                        dataSummary(1:LengthTemp,4,ConID)=dataTemp(1:LengthTemp,12);
                        
                        
                        LengthSummary(ConID,1)=ConID;
                        LengthSummary(ConID,2)=LengthTemp;
                        
                        
                        Ref(LengthRef+1:LengthRef+LengthTemp,1:4)=dataSummary(1:LengthTemp,1:4,ConID);
                        LengthRef=LengthRef+LengthTemp;
                        clear dataTemp;
                        
                    end
                end
            end
        end
        if LengthRef>0
            Ref=sortrows(Ref,1);
            nMultiply=0;
            for i=1:LengthRef
                nFound=0;
                for w=1:size(LengthSummary,1)
                    for z=1:LengthSummary(w,2)
                        if abs(dataSummary(z,1,w)-Ref(i,1))<MassDifferTor &&...
                                abs(dataSummary(z,4,w)-Ref(i,4))<1 &&...
                                abs(dataSummary(z,3,w)-Ref(i,3))<ITD
                            
                            nFound=nFound+1;
                            Found(nFound,1:4)=dataSummary(z,1:4,w);
                            Found(nFound,5)=w;
                        end
                    end
                end
                if nFound>=MR
                    nTimeGood=0;
                    for z=1:nFound
                        nSet=1;
                        SetU(nSet,:)=Found(z,:);
                        for z1=1:nFound
                            vot=0;
                            for z2=1:nSet
                                if SetU(z2,5)==Found(z1,5)
                                    vot=1;
                                end
                            end
                            if vot==0
                                nSet=nSet+1;
                                SetU(nSet,:)=Found(z1,:);
                            end
                        end
                        for z1=1:nSet
                            nTimeRoutine=1;
                            RefU(nTimeRoutine,:)=SetU(z1,:);
                            for z2=1:nSet
                                if RefU(nTimeRoutine,5)<SetU(z2,5) && RefU(nTimeRoutine,2)-SetU(z2,2)>TimeDifferTor
                                    nTimeRoutine=nTimeRoutine+1;
                                    RefU(nTimeRoutine,:)=SetU(z2,:);
                                end
                            end
                            if nTimeRoutine>=MR && max(SetU(:,2))-min(SetU(:,2))>2*TimeDifferTor
                                nTimeGood=nTimeGood+1;
                                for z3=1:nTimeRoutine
                                    TempU(nTimeGood,RefU(z3,5)*4-3:RefU(z3,5)*4)=RefU(z3,1:4);
                                end
                            end
                            clear RefU
                        end
                    end
                    clear SetU
                    if nTimeGood>0
                        nTimeGoodShort=1;
                        TimeGoodWdith=size(TempU,2);
                        TimeGoodShort(nTimeGoodShort,:)=TempU(1,:);
                        for v=2:nTimeGood
                            vot=0;
                            vbt=0;
                            for v1=1:nTimeGoodShort
                                vpt=1;
                                for v2=4:4:TimeGoodWdith
                                    if TimeGoodShort(v1,v2-3)*TempU(v,v2-3)~=0
                                        if TimeGoodShort(v1,v2-3)==TempU(v,v2-3) && TimeGoodShort(v1,v2-2)==TempU(v,v2-2) && ...
                                                TimeGoodShort(v1,v2-1)==TempU(v,v2-1) && TimeGoodShort(v1,v2)==TempU(v,v2)
                                            vpt=vpt*2;
                                        else
                                            vpt=vpt*0;
                                        end
                                    end
                                end
                                if vpt>1
                                    for v3=4:4:TimeGoodWdith
                                        if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                            vbt=1;
                                        end
                                    end
                                    if vbt==0
                                        for v3=4:4:TimeGoodWdith
                                            if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                                TimeGoodShort(v1,v3-3:v3)=TempU(v,v3-3:v3);
                                            end
                                        end
                                    end
                                    vot=1;
                                end
                            end
                            if vot==0
                                nTimeGoodShort=nTimeGoodShort+1;
                                TimeGoodShort(nTimeGoodShort,:)=TempU(v,:);
                            end
                        end
                        TGSWidth=size(TimeGoodShort,2);
                        clear TempU;
                        
                        for v=1:nTimeGoodShort
                            Multiply0(nMultiply+v,1:TGSWidth)=TimeGoodShort(v,1:TGSWidth);
                        end
                        nMultiply=nMultiply+nTimeGoodShort;
                        clear TimeGoodShort;
                        
                    end
                end
            end
            if nMultiply>0
                Multiply1=unique(Multiply0,'rows');
                MultiplyLength=size(Multiply1,1);
                MultiplyWidth=size(Multiply1,2);
                nMultiply_Short=0;
                for w=1:MultiplyLength
                    for z=2:4:MultiplyWidth
                        if Multiply1(w,z)>0
                            conditionNo=(z+2)/4;
                            for u=2:MBLength
                                if Multiply1(w,z)>MB(u-1,1) && Multiply1(w,z)<=MB(u,1)
                                    RatioH2O=(Multiply1(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                    u0=u;
                                    volH2O(1,conditionNo)=0;
                                    for u1=1:u0-1
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                    end
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-Multiply1(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-Multiply1(w,z));
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                    volMeOH(1,conditionNo)=Multiply1(w,z)-volH2O(1,conditionNo);
                                    RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/Multiply1(w,z));
                                    lnTime(1,conditionNo)=log10(Multiply1(w,z));
                                end
                            end
                        end
                    end
                    
                    countNo=0;
                    for u=1:conditionNo
                        if lnTime(1,u)~=0
                            countNo=countNo+1;
                            RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                            lnTime_PSS(1,countNo)=lnTime(1,u);
                        end
                    end
                    
                    vot=0;
                    for z=1:4:MultiplyWidth
                        if Multiply1(w,z)>0 && vot==0
                            pSS(w,1)=Multiply1(w,z);
                            vot=1;
                        end
                    end
                    pSS(w,2:3)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                    
                    for z=1:countNo
                        RatioStrongfit2(1,z)=pSS(w,2)*lnTime_PSS(1,z)+pSS(w,3);
                    end
                    
                    R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                    pSS(w,4)=R2;
                    
                    if R2>ML
                        nMultiply_Short=nMultiply_Short+1;
                        p2(nMultiply_Short,:)=pSS(w,:);
                        Multiply(nMultiply_Short,:)=Multiply1(w,:);
                    end
                    
                    clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                end
                if nMultiply_Short>0
                    nMultiply=size(Multiply,1);
                    CWidth=size(Multiply,2);
                    nGroup=1;
                    condition=0;
                    for i=2:4:CWidth
                        condition=condition+1;
                        GroupFeature(nGroup,condition)=Multiply(1,i);
                    end
                    for i=2:nMultiply
                        condition=0;
                        for j=2:4:CWidth
                            condition=condition+1;
                            Temp(1,condition)=Multiply(i,j);
                        end
                        vot=0;
                        vbt=0;
                        for z=1:nGroup
                            vpt=1;
                            for u=1:condition
                                if Temp(1,u)*GroupFeature(z,u)~=0
                                    if abs(Temp(1,u)-GroupFeature(z,u))<TimeDifferTor
                                        vpt=vpt*2;
                                    else
                                        vpt=vpt*0;
                                    end
                                end
                            end
                            if vpt>1
                                for u=1:condition
                                    if Temp(1,u)~=0 && GroupFeature(z,u)==0
                                        if (u==1 && Temp(1,u)-GroupFeature(z,u+1)>TimeDifferTor)||...
                                                (u==condition && GroupFeature(z,u-1)-Temp(1,u)>TimeDifferTor) ||...
                                                (u<condition && u>1 && GroupFeature(z,u-1)-Temp(1,u)>TimeDifferTor...
                                                && Temp(1,u)-GroupFeature(z,u+1)>TimeDifferTor)
                                            GroupFeature(z,u)=Temp(1,u);
                                        end
                                    end
                                end
                                vot=1;
                            end
                        end
                        if vot==0
                            nGroup=nGroup+1;
                            condition=0;
                            for v=2:4:CWidth
                                condition=condition+1;
                                GroupFeature(nGroup,condition)=Multiply(i,v);
                            end
                        end
                    end
                    
                    for w=1:nGroup
                        for z=1:size(GroupFeature,2)
                            if GroupFeature(w,z)>0
                                conditionNo=z;
                                for u=2:MBLength
                                    if GroupFeature(w,z)>MB(u-1,1) && GroupFeature(w,z)<=MB(u,1)
                                        RatioH2O=(GroupFeature(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                        u0=u;
                                        volH2O(1,conditionNo)=0;
                                        for u1=1:u0-1
                                            volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                        end
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-GroupFeature(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-GroupFeature(w,z));
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                        volMeOH(1,conditionNo)=GroupFeature(w,z)-volH2O(1,conditionNo);
                                        RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/GroupFeature(w,z));
                                        lnTime(1,conditionNo)=log10(GroupFeature(w,z));
                                    end
                                end
                            end
                        end
                        
                        countNo=0;
                        for u=1:conditionNo
                            if lnTime(1,u)~=0
                                countNo=countNo+1;
                                RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                                lnTime_PSS(1,countNo)=lnTime(1,u);
                            end
                        end
                        
                        
                        pSS(w,1:2)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                        
                        for z=1:countNo
                            RatioStrongfit2(1,z)=pSS(w,1)*lnTime_PSS(1,z)+pSS(w,2);
                        end
                        
                        R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                        pSS(w,3)=R2;
                        
                        GroupFeatureRecorded(w,:)=pSS(w,:);
                        
                        clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                    end
                    
                    GroupNum=zeros(nGroup,2);
                    
                    for g=1:nGroup
                        for i=1:nMultiply
                            condition=0;
                            vht=0;
                            for j=2:4:CWidth
                                condition=condition+1;
                                if abs(Multiply(i,j)-GroupFeature(g,condition))>TimeDifferTor && Multiply(i,j)*GroupFeature(g,condition)~=0
                                    vht=1;
                                end
                                if Multiply(i,j)~=0 && GroupFeature(g,condition)==0
                                    if (condition==1 && Multiply(i,j)-GroupFeature(g,condition+1)<=TimeDifferTor)||...
                                            (condition==CWidth/4 && GroupFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor)||...
                                            (condition<CWidth/4 && condition>1 && (GroupFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor ||...
                                            Multiply(i,j)-GroupFeature(g,condition+1)<=TimeDifferTor))
                                        vht=1;
                                    end
                                end
                                if Multiply(i,j)==0 && GroupFeature(g,condition)~=0
                                    if (condition==1 && GroupFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor)||...
                                            (condition==CWidth/4 && Multiply(i,j-4)-GroupFeature(g,condition)<=TimeDifferTor)||...
                                            (condition<CWidth/4 && condition>1 && (Multiply(i,j-4)-GroupFeature(g,condition)<=TimeDifferTor ||...
                                            GroupFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor))
                                        vht=1;
                                    end
                                end
                            end
                            if vht==0;
                                GroupNum(g,1)=GroupNum(g,1)+1;
                                GroupAbunTemp=0;
                                countMP=0;
                                for u=3:4:CWidth
                                    GroupAbunTemp=GroupAbunTemp+Multiply(i,u);
                                    if Multiply(i,u)>0
                                        countMP=countMP+1;
                                    end
                                end
                                GroupAbunTemp=GroupAbunTemp/countMP;
                                if GroupAbunTemp>GroupNum(g,2)
                                    GroupNum(g,2)=GroupAbunTemp;
                                end
                                GroupedIons(GroupNum(g,1),1:CWidth,g)=Multiply(i,1:CWidth);
                                GroupedIons(GroupNum(g,1),ConNo*4+1:ConNo*4+3,g)=GroupFeatureRecorded(g,1:3);
                            end
                        end
                    end
                    
                    nTapdanceGroup=0;
                    nGroupVisible=0;
                    UpperGroupedIonAbun=max(GroupNum(:,2));
                    LowerGroupedIonAbun=min(GroupNum(:,2));
                    GridNumber=nGroup;
                    Interval_UL=(UpperGroupedIonAbun-LowerGroupedIonAbun)/GridNumber;
                    GroupedIonAbunSummary=zeros(GridNumber,3);
                    for g=1:GridNumber
                        GroupedIonAbunSummary(g,1)=LowerGroupedIonAbun+Interval_UL*(g-1);
                        GroupedIonAbunSummary(g,2)=LowerGroupedIonAbun+Interval_UL*g;
                    end
                    for g=1:GridNumber
                        for z=1:nGroup
                            if GroupNum(z,2)<=GroupedIonAbunSummary(g,2) && GroupNum(z,2)>GroupedIonAbunSummary(g,1)
                                GroupedIonAbunSummary(g,3)=GroupedIonAbunSummary(g,3)+1;
                            end
                        end
                    end
                    if nGroup>1
                        HorizonNo=max(GroupedIonAbunSummary(1:nGroup-1,3));
                        for g=GridNumber:-1:1
                            if GroupedIonAbunSummary(g,3)==HorizonNo
                                HorizonAbun=GroupedIonAbunSummary(g,1);
                            end
                        end
                    else
                        HorizonAbun=GroupedIonAbunSummary(nGroup,1);
                    end
                    
                    GILength=size(GroupedIons,1);
                    GIWidth=size(GroupedIons,2);
                    nTapdanceGroup=0;
                    for g=1:nGroup
                        if GroupNum(g,2)>=HorizonAbun
                            DifferIonNumber=0;
                            INTempNo=0;
                            for p=1:GILength
                                for q=1:4:GIWidth-3
                                    if GroupedIons(p,q,g)>0
                                        INTempNo=INTempNo+1;
                                        IonNumberTemp(INTempNo,1)=GroupedIons(p,q,g);
                                    end
                                end
                            end
                            if INTempNo>0
                                IonNumberTempS=unique(IonNumberTemp,'rows');
                                IonNumberTempS=sortrows(IonNumberTempS);
                                INTS=size(IonNumberTempS,1);
                                if INTS>=MA
                                    IonNumberTempS1(1,1)=IonNumberTempS(1,1);
                                    DifferIonNumber=1;
                                    for p=2:INTS
                                        if IonNumberTempS(p,1)-IonNumberTempS1(DifferIonNumber,1)>1.1
                                            DifferIonNumber=DifferIonNumber+1;
                                            IonNumberTempS1(DifferIonNumber,1)=IonNumberTempS(p,1);
                                        end
                                    end
                                end
                                if DifferIonNumber>=MA
                                    nTapdanceGroup=nTapdanceGroup+1;
                                    TapdanceGroupBYAbun(:,:,nTapdanceGroup)=GroupedIons(:,:,g);
                                    Sample_Feature(nTapdanceGroup,1)=g;
                                    Sample_Feature(nTapdanceGroup,2)=GroupNum(g,2);
                                end
                            end
                            
                            clear IonNumberTemp IonNumberTempS IonNumberTempS1
                        end
                    end
                    if nTapdanceGroup>0
                        
                        LengthTDBA=size(TapdanceGroupBYAbun,1);
                        WidthTDBA=size(TapdanceGroupBYAbun,2);
                        NoTDBA=size(TapdanceGroupBYAbun,3);
                        
                        save(sprintf('%s%s%s','MULTSam',num2str(SamID),'N.txt'),'Multiply','-ascii');
                        
                        save(sprintf('%s%s%s','GRFRSam',num2str(SamID),'N.txt'),'GroupFeatureRecorded','-ascii');
                        
                        SFLength=size(Sample_Feature,1);
                        dataOutputFull1=Sample_Feature(1:SFLength, 1:2);
                        save(sprintf('%s%s%s','SAFESam',num2str(SamID),'N.txt'),'dataOutputFull1','-ascii');
                        
                        save(sprintf('%s%s%s','TDANSam',num2str(SamID),'N.mat'),'TapdanceGroupBYAbun');
                        
                    end
                end
            end
            
            clearvars -except ConID ConNo IMI ITD IRT IntensityThreshold MB MBLength MA ...
                MassDifferTor Mats ML MR SamID SamNoEn SamNoSt TimeDifferTor files iFile ...
                nOfFiles nOfMats t00
            
            t01=cputime-t00;
            disp(['Calculation time = ',num2str(t01), ' seconds', 'Sam',num2str(SamID),'N']);
        end
        
        
        
        LengthRef=0;
        for ConID=1:ConNo
            for iFile=1:nOfFiles
                if (strcmp( files(iFile).name(1:4),'DENO'))
                    MaSuDN(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'P')
                            MaSuDN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuDN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuDN(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuDN(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuDN(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'P')
                            MaSuDN(1,1)=9;
                        end
                    end
                    
                    if MaSuDN(1,1)>0
                        dataTemp=load(files(iFile).name);
                        LengthTemp=size(dataTemp,1);
                        dataSummary(1:LengthTemp,1,ConID)=dataTemp(1:LengthTemp,1);
                        dataSummary(1:LengthTemp,2,ConID)=dataTemp(1:LengthTemp,2);
                        dataSummary(1:LengthTemp,3,ConID)=dataTemp(1:LengthTemp,7);
                        dataSummary(1:LengthTemp,4,ConID)=dataTemp(1:LengthTemp,12);
                        
                        LengthSummary(ConID,1)=ConID;
                        LengthSummary(ConID,2)=LengthTemp;
                        
                        Ref(LengthRef+1:LengthRef+LengthTemp,1:4)=dataSummary(1:LengthTemp,1:4,ConID);
                        LengthRef=LengthRef+LengthTemp;
                        clear dataTemp;
                        
                    end
                end
            end
        end
        if LengthRef>0
            Ref=sortrows(Ref,1);
            nMultiply=0;
            for i=1:LengthRef
                nFound=0;
                for w=1:size(LengthSummary,1)
                    for z=1:LengthSummary(w,2)
                        if abs(dataSummary(z,1,w)-Ref(i,1))<MassDifferTor &&...
                                abs(dataSummary(z,4,w)-Ref(i,4))<1 &&...
                                abs(dataSummary(z,3,w)-Ref(i,3))<ITD
                            
                            nFound=nFound+1;
                            Found(nFound,1:4)=dataSummary(z,1:4,w);
                            Found(nFound,5)=w;
                        end
                    end
                end
                
                if nFound>=MR
                    nTimeGood=0;
                    for z=1:nFound
                        nSet=1;
                        SetU(nSet,:)=Found(z,:);
                        for z1=1:nFound
                            vot=0;
                            for z2=1:nSet
                                if SetU(z2,5)==Found(z1,5)
                                    vot=1;
                                end
                            end
                            if vot==0
                                nSet=nSet+1;
                                SetU(nSet,:)=Found(z1,:);
                            end
                        end
                        for z1=1:nSet
                            nTimeRoutine=1;
                            RefU(nTimeRoutine,:)=SetU(z1,:);
                            for z2=1:nSet
                                if RefU(nTimeRoutine,5)<SetU(z2,5) && RefU(nTimeRoutine,2)-SetU(z2,2)>TimeDifferTor
                                    nTimeRoutine=nTimeRoutine+1;
                                    RefU(nTimeRoutine,:)=SetU(z2,:);
                                end
                            end
                            if nTimeRoutine>=MR && max(SetU(:,2))-min(SetU(:,2))>2*TimeDifferTor
                                nTimeGood=nTimeGood+1;
                                for z3=1:nTimeRoutine
                                    TempU(nTimeGood,RefU(z3,5)*4-3:RefU(z3,5)*4)=RefU(z3,1:4);
                                end
                            end
                            clear RefU
                        end
                    end
                    clear SetU
                    if nTimeGood>0
                        nTimeGoodShort=1;
                        TimeGoodWdith=size(TempU,2);
                        TimeGoodShort(nTimeGoodShort,:)=TempU(1,:);
                        for v=2:nTimeGood
                            vot=0;
                            vbt=0;
                            for v1=1:nTimeGoodShort
                                vpt=1;
                                for v2=4:4:TimeGoodWdith
                                    if TimeGoodShort(v1,v2-3)*TempU(v,v2-3)~=0
                                        if TimeGoodShort(v1,v2-3)==TempU(v,v2-3) && TimeGoodShort(v1,v2-2)==TempU(v,v2-2) && ...
                                                TimeGoodShort(v1,v2-1)==TempU(v,v2-1) && TimeGoodShort(v1,v2)==TempU(v,v2)
                                            vpt=vpt*2;
                                        else
                                            vpt=vpt*0;
                                        end
                                    end
                                end
                                if vpt>1
                                    for v3=4:4:TimeGoodWdith
                                        if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                            vbt=1;
                                        end
                                    end
                                    if vbt==0
                                        for v3=4:4:TimeGoodWdith
                                            if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                                TimeGoodShort(v1,v3-3:v3)=TempU(v,v3-3:v3);
                                            end
                                        end
                                    end
                                    vot=1;
                                end
                            end
                            if vot==0
                                nTimeGoodShort=nTimeGoodShort+1;
                                TimeGoodShort(nTimeGoodShort,:)=TempU(v,:);
                            end
                        end
                        TGSWidth=size(TimeGoodShort,2);
                        clear TempU;
                        
                        for v=1:nTimeGoodShort
                            Multiply0(nMultiply+v,1:TGSWidth)=TimeGoodShort(v,1:TGSWidth);
                        end
                        nMultiply=nMultiply+nTimeGoodShort;
                        clear TimeGoodShort;
                        
                    end
                end
            end
            if nMultiply>0
                Multiply1=unique(Multiply0,'rows');
                MultiplyLength=size(Multiply1,1);
                MultiplyWidth=size(Multiply1,2);
                nMultiply_Short=0;
                for w=1:MultiplyLength
                    for z=2:4:MultiplyWidth
                        if Multiply1(w,z)>0
                            conditionNo=(z+2)/4;
                            for u=2:MBLength
                                if Multiply1(w,z)>MB(u-1,1) && Multiply1(w,z)<=MB(u,1)
                                    RatioH2O=(Multiply1(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                    u0=u;
                                    volH2O(1,conditionNo)=0;
                                    for u1=1:u0-1
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                    end
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-Multiply1(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-Multiply1(w,z));
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                    volMeOH(1,conditionNo)=Multiply1(w,z)-volH2O(1,conditionNo);
                                    RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/Multiply1(w,z));
                                    lnTime(1,conditionNo)=log10(Multiply1(w,z));
                                end
                            end
                        end
                    end
                    
                    countNo=0;
                    for u=1:conditionNo
                        if lnTime(1,u)~=0
                            countNo=countNo+1;
                            RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                            lnTime_PSS(1,countNo)=lnTime(1,u);
                        end
                    end
                    
                    vot=0;
                    for z=1:4:MultiplyWidth
                        if Multiply1(w,z)>0 && vot==0
                            pSS(w,1)=Multiply1(w,z);
                            vot=1;
                        end
                    end
                    pSS(w,2:3)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                    
                    for z=1:countNo
                        RatioStrongfit2(1,z)=pSS(w,2)*lnTime_PSS(1,z)+pSS(w,3);
                    end
                    
                    R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                    pSS(w,4)=R2;
                    
                    if R2>ML
                        nMultiply_Short=nMultiply_Short+1;
                        p2(nMultiply_Short,:)=pSS(w,:);
                        Multiply(nMultiply_Short,:)=Multiply1(w,:);
                    end
                    
                    clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                end
                if nMultiply_Short>0
                    nMultiply=size(Multiply,1);
                    CWidth=size(Multiply,2);
                    nGroup=1;
                    condition=0;
                    for i=2:4:CWidth
                        condition=condition+1;
                        GroupFeature(nGroup,condition)=Multiply(1,i);
                    end
                    for i=2:nMultiply
                        condition=0;
                        for j=2:4:CWidth
                            condition=condition+1;
                            Temp(1,condition)=Multiply(i,j);
                        end
                        vot=0;
                        vbt=0;
                        for z=1:nGroup
                            vpt=1;
                            for u=1:condition
                                if Temp(1,u)*GroupFeature(z,u)~=0
                                    if abs(Temp(1,u)-GroupFeature(z,u))<TimeDifferTor
                                        vpt=vpt*2;
                                    else
                                        vpt=vpt*0;
                                    end
                                end
                            end
                            if vpt>1
                                for u=1:condition
                                    if Temp(1,u)~=0 && GroupFeature(z,u)==0
                                        if (u==1 && Temp(1,u)-GroupFeature(z,u+1)>TimeDifferTor)||...
                                                (u==condition && GroupFeature(z,u-1)-Temp(1,u)>TimeDifferTor) ||...
                                                (u<condition && u>1 && GroupFeature(z,u-1)-Temp(1,u)>TimeDifferTor...
                                                && Temp(1,u)-GroupFeature(z,u+1)>TimeDifferTor)
                                            GroupFeature(z,u)=Temp(1,u);
                                        end
                                    end
                                end
                                vot=1;
                            end
                        end
                        if vot==0
                            nGroup=nGroup+1;
                            condition=0;
                            for v=2:4:CWidth
                                condition=condition+1;
                                GroupFeature(nGroup,condition)=Multiply(i,v);
                            end
                        end
                    end
                    
                    for w=1:nGroup
                        for z=1:size(GroupFeature,2)
                            if GroupFeature(w,z)>0
                                conditionNo=z;
                                for u=2:MBLength
                                    if GroupFeature(w,z)>MB(u-1,1) && GroupFeature(w,z)<=MB(u,1)
                                        RatioH2O=(GroupFeature(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                        u0=u;
                                        volH2O(1,conditionNo)=0;
                                        for u1=1:u0-1
                                            volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                        end
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-GroupFeature(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-GroupFeature(w,z));
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                        volMeOH(1,conditionNo)=GroupFeature(w,z)-volH2O(1,conditionNo);
                                        RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/GroupFeature(w,z));
                                        lnTime(1,conditionNo)=log10(GroupFeature(w,z));
                                    end
                                end
                            end
                        end
                        
                        countNo=0;
                        for u=1:conditionNo
                            if lnTime(1,u)~=0
                                countNo=countNo+1;
                                RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                                lnTime_PSS(1,countNo)=lnTime(1,u);
                            end
                        end
                        
                        
                        pSS(w,1:2)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                        
                        for z=1:countNo
                            RatioStrongfit2(1,z)=pSS(w,1)*lnTime_PSS(1,z)+pSS(w,2);
                        end
                        
                        R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                        pSS(w,3)=R2;
                        
                        GroupFeatureRecorded(w,:)=pSS(w,:);
                        
                        clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                    end
                    GroupNum=zeros(nGroup,2);
                    
                    for g=1:nGroup
                        for i=1:nMultiply
                            condition=0;
                            vht=0;
                            for j=2:4:CWidth
                                condition=condition+1;
                                if abs(Multiply(i,j)-GroupFeature(g,condition))>TimeDifferTor && Multiply(i,j)*GroupFeature(g,condition)~=0
                                    vht=1;
                                end
                                if Multiply(i,j)~=0 && GroupFeature(g,condition)==0
                                    if (condition==1 && Multiply(i,j)-GroupFeature(g,condition+1)<=TimeDifferTor)||...
                                            (condition==CWidth/4 && GroupFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor)||...
                                            (condition<CWidth/4 && condition>1 && (GroupFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor ||...
                                            Multiply(i,j)-GroupFeature(g,condition+1)<=TimeDifferTor))
                                        vht=1;
                                    end
                                end
                                if Multiply(i,j)==0 && GroupFeature(g,condition)~=0
                                    if (condition==1 && GroupFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor)||...
                                            (condition==CWidth/4 && Multiply(i,j-4)-GroupFeature(g,condition)<=TimeDifferTor)||...
                                            (condition<CWidth/4 && condition>1 && (Multiply(i,j-4)-GroupFeature(g,condition)<=TimeDifferTor ||...
                                            GroupFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor))
                                        vht=1;
                                    end
                                end
                            end
                            if vht==0;
                                GroupNum(g,1)=GroupNum(g,1)+1;
                                GroupAbunTemp=0;
                                countMP=0;
                                for u=3:4:CWidth
                                    GroupAbunTemp=GroupAbunTemp+Multiply(i,u);
                                    if Multiply(i,u)>0
                                        countMP=countMP+1;
                                    end
                                end
                                GroupAbunTemp=GroupAbunTemp/countMP;
                                if GroupAbunTemp>GroupNum(g,2)
                                    GroupNum(g,2)=GroupAbunTemp;
                                end
                                GroupedIons(GroupNum(g,1),1:CWidth,g)=Multiply(i,1:CWidth);
                                GroupedIons(GroupNum(g,1),ConNo*4+1:ConNo*4+3,g)=GroupFeatureRecorded(g,1:3);
                            end
                        end
                    end
                    nTapdanceGroup=0;
                    nGroupVisible=0;
                    UpperGroupedIonAbun=max(GroupNum(:,2));
                    LowerGroupedIonAbun=min(GroupNum(:,2));
                    GridNumber=nGroup;
                    Interval_UL=(UpperGroupedIonAbun-LowerGroupedIonAbun)/GridNumber;
                    GroupedIonAbunSummary=zeros(GridNumber,3);
                    for g=1:GridNumber
                        GroupedIonAbunSummary(g,1)=LowerGroupedIonAbun+Interval_UL*(g-1);
                        GroupedIonAbunSummary(g,2)=LowerGroupedIonAbun+Interval_UL*g;
                    end
                    for g=1:GridNumber
                        for z=1:nGroup
                            if GroupNum(z,2)<=GroupedIonAbunSummary(g,2) && GroupNum(z,2)>GroupedIonAbunSummary(g,1)
                                GroupedIonAbunSummary(g,3)=GroupedIonAbunSummary(g,3)+1;
                            end
                        end
                    end
                    if nGroup>1
                        HorizonNo=max(GroupedIonAbunSummary(1:nGroup-1,3));
                        for g=GridNumber:-1:1
                            if GroupedIonAbunSummary(g,3)==HorizonNo
                                HorizonAbun=GroupedIonAbunSummary(g,1);
                            end
                        end
                    else
                        HorizonAbun=GroupedIonAbunSummary(nGroup,1);
                    end
                    
                    GILength=size(GroupedIons,1);
                    GIWidth=size(GroupedIons,2);
                    nTapdanceGroup=0;
                    for g=1:nGroup
                        if GroupNum(g,2)>=HorizonAbun
                            DifferIonNumber=0;
                            INTempNo=0;
                            for p=1:GILength
                                for q=1:4:GIWidth-3
                                    if GroupedIons(p,q,g)>0
                                        INTempNo=INTempNo+1;
                                        IonNumberTemp(INTempNo,1)=GroupedIons(p,q,g);
                                    end
                                end
                            end
                            if INTempNo>0
                                IonNumberTempS=unique(IonNumberTemp,'rows');
                                IonNumberTempS=sortrows(IonNumberTempS);
                                INTS=size(IonNumberTempS,1);
                                if INTS>=MA
                                    IonNumberTempS1(1,1)=IonNumberTempS(1,1);
                                    DifferIonNumber=1;
                                    for p=2:INTS
                                        if IonNumberTempS(p,1)-IonNumberTempS1(DifferIonNumber,1)>1.1
                                            DifferIonNumber=DifferIonNumber+1;
                                            IonNumberTempS1(DifferIonNumber,1)=IonNumberTempS(p,1);
                                        end
                                    end
                                end
                                if DifferIonNumber>=MA
                                    nTapdanceGroup=nTapdanceGroup+1;
                                    TapdanceGroupBYAbun(:,:,nTapdanceGroup)=GroupedIons(:,:,g);
                                    Sample_Feature(nTapdanceGroup,1)=g;
                                    Sample_Feature(nTapdanceGroup,2)=GroupNum(g,2);
                                end
                            end
                            
                            clear IonNumberTemp IonNumberTempS IonNumberTempS1
                        end
                    end
                    if nTapdanceGroup>0
                        
                        LengthTDBA=size(TapdanceGroupBYAbun,1);
                        WidthTDBA=size(TapdanceGroupBYAbun,2);
                        NoTDBA=size(TapdanceGroupBYAbun,3);
                        
                        save(sprintf('%s%s%s','MULTSam',num2str(SamID),'P.txt'),'Multiply','-ascii');
                        
                        save(sprintf('%s%s%s','GRFRSam',num2str(SamID),'P.txt'),'GroupFeatureRecorded','-ascii');
                        
                        SFLength=size(Sample_Feature,1);
                        dataOutputFull1=Sample_Feature(1:SFLength, 1:2);
                        save(sprintf('%s%s%s','SAFESam',num2str(SamID),'P.txt'),'dataOutputFull1','-ascii');
                        
                        save(sprintf('%s%s%s','TDANSam',num2str(SamID),'P.mat'),'TapdanceGroupBYAbun');
                        
                    end
                end
            end
            
            clearvars -except ConID ConNo IMI ITD IRT IntensityThreshold MB MBLength MA ...
                MassDifferTor Mats ML MR SamID SamNoEn SamNoSt TimeDifferTor files iFile ...
                nOfFiles nOfMats t00
            
            t01=cputime-t00;
            disp(['Calculation time = ',num2str(t01), ' seconds', 'Sam',num2str(SamID),'P']);
        end
        
    end
    t01=cputime-t00;
    disp(['Step2 = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    
    
    RedundantIons=4;
    TimeVariance=TimeDifferTor/ConNo;
    GroupDifferRatioControl=0.5;
    files = dir(fullfile('.', '*.txt'));
    [nOfFiles,~] = size(files);
    
    Mats = dir(fullfile('.', '*.mat'));
    [nOfMats,~]=size(Mats);
    
    
    for SamID=SamNoSt:SamNoEn
        TIRALength=0;
        
        for iFile=1:nOfFiles
            for ConID=1:ConNo
                if (strcmp(files(iFile).name(1:3),'Sam'))
                    MaSuUV(1,1)=0;
                    
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                                && strcmp(files(iFile).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=4;
                        end
                    end
                    
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=5;
                        end
                    end
                    
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=6;
                        end
                    end
                    
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=7;
                        end
                    end
                    
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=8;
                        end
                    end
                    
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                                && strcmp(files(iFile).name(13),'.')
                            MaSuUV(1,1)=9;
                        end
                    end
                    
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iFile).name);
                        UVTempLS=size(UVTemp,1);
                        TIRA(ConID,1)=ConID;
                        TIRA(ConID,2) =UVTemp(UVTempLS,1);
                        TIRALength=size(TIRA,1);
                    end
                end;
            end;
        end;
        
        
        if TIRALength>0
            nGroup=0;nFeature=0;DRLength=0;
            
            
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'GRFR')
                    MaSuGF(1,1)=0;
                    
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'N'))
                            MaSuGF(1,1)=1;
                        end
                    end
                    
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'N'))
                            MaSuGF(1,1)=2;
                        end
                    end
                    
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'N'))
                            MaSuGF(1,1)=3;
                        end
                    end
                    
                    if MaSuGF(1,1)>0
                        GroupFeatureRecord=load(files(iFile).name);
                        nGroup=size(GroupFeatureRecord,1);
                    end
                end
            end
            
            
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'SAFE')
                    MaSuSF(1,1)=0;
                    
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'N'))
                            MaSuSF(1,1)=1;
                        end
                    end
                    
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'N'))
                            MaSuSF(1,1)=2;
                        end
                    end
                    
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'N'))
                            MaSuSF(1,1)=3;
                        end
                    end
                    
                    if MaSuSF(1,1)>0
                        Sample_Feature=load(files(iFile).name);
                        nFeature=size(Sample_Feature,1);
                    end
                end
            end
            
            for iMatRef=1:nOfMats
                GroupPeak_Vis_Mark=0;
                if strcmp( Mats(iMatRef).name(1:4),'TDAN')
                    MaSuMa(1,1)=0;
                    if SamID<10
                        if str2double(Mats(iMatRef).name(8))==SamID ...
                                && (strcmp(Mats(iMatRef).name(9),'N'))
                            MaSuMa(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100
                        if str2double(Mats(iMatRef).name(8:9))==SamID ...
                                && (strcmp(Mats(iMatRef).name(10),'N'))
                            MaSuMa(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(Mats(iMatRef).name(8:10))==SamID ...
                                && (strcmp(Mats(iMatRef).name(11),'N'))
                            MaSuMa(1,1)=3;
                        end
                    end
                    if MaSuMa(1,1)>0
                        dataRef = load(Mats(iMatRef).name);
                        Refdata=dataRef.TapdanceGroupBYAbun;
                        DRLength=size(Refdata);
                        if size(DRLength,2)==2
                            DRLength(1,3)=1;
                        end
                    end
                end
            end
            
            if nGroup*nFeature*DRLength(1,1)~=0
                GroupPeak_Vis_Mark=0;
                con_count=0;
                for d2=1:4:DRLength(1,2)-3
                    
                    con_count=con_count+1;
                    ion_count_present=0;
                    ion_count_table_row=0;
                    
                    for d3=1:DRLength(1,3)
                        ion_count=0;
                        ion_count_table=0;
                        
                        for d1=1:DRLength(1,1)
                            
                            if Refdata(d1,d2,d3)>0
                                ion_count=ion_count+1;
                                ionSummary_Temp(ion_count,1:4)=Refdata(d1,d2:d2+3,d3);
                                ionSummary_Temp(ion_count,5:7)=Refdata(d1,ConNo*4+1:ConNo*4+3,d3);
                                ionSummary_Temp(ion_count,8)=d3;
                            end
                            
                        end
                        
                        if ion_count>1
                            ionSummary_Temp00=unique(ionSummary_Temp,'rows');
                            clear ionSummary_Temp
                            ionSummary_Temp00=sortrows(ionSummary_Temp00,1);
                            iTemp=1;
                            ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(1,:);
                            for u=2:size(ionSummary_Temp00,1)
                                vot=0;
                                if ionSummary_Temp00(u,1)-ionSummary_Temp0(iTemp,1)>=IMI && vot==0
                                    iTemp=iTemp+1;
                                    ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(u,:);
                                end
                            end
                            
                            
                            if iTemp>=MA
                                clear ionSummary_Temp0
                                if iTemp>RedundantIons
                                    ionSummary_Temp0(:,1:3)=ionSummary_Temp00(:,1:3);
                                    ionSummary_Temp010=unique(ionSummary_Temp0,'rows');
                                    GridNumber=size(ionSummary_Temp010,1);
                                    ISTHigh=max(ionSummary_Temp010(:,3));
                                    ISTLow=min(ionSummary_Temp010(:,3));
                                    
                                    Interval_UL=(ISTHigh-ISTLow)/GridNumber;
                                    GroupedIonAbunSummary=zeros(GridNumber,3);
                                    
                                    for g=1:GridNumber
                                        GroupedIonAbunSummary(g,1)=ISTLow+Interval_UL*(g-1);
                                        GroupedIonAbunSummary(g,2)=ISTLow+Interval_UL*g;
                                    end
                                    
                                    for g=1:GridNumber
                                        for z=1:size(ionSummary_Temp010,1)
                                            if ionSummary_Temp010(z,3)<=GroupedIonAbunSummary(g,2) ...
                                                    && ionSummary_Temp010(z,3)>=GroupedIonAbunSummary(g,1)
                                                GroupedIonAbunSummary(g,3)=GroupedIonAbunSummary(g,3)+1;
                                            end
                                        end
                                    end
                                    HorizonNo=max(GroupedIonAbunSummary(:,3));
                                    for g=GridNumber:-1:1
                                        if GroupedIonAbunSummary(g,3)==HorizonNo
                                            HorizonAbun=GroupedIonAbunSummary(g,1);
                                        end
                                    end
                                    
                                    ThresholdAbun_Presented=HorizonAbun;
                                    clear ionSummary_Temp010
                                else
                                    ThresholdAbun_Presented=0;
                                end
                                
                                for z=1:size(ionSummary_Temp00,1)
                                    if ionSummary_Temp00(z,3)>=ThresholdAbun_Presented
                                        ion_count_table=ion_count_table+1;
                                        ionSummary_Temp1(ion_count_table,:)=ionSummary_Temp00(z,:);
                                    end
                                end
                                
                                
                                
                                if ion_count_table>0
                                    ion_count_table_row=ion_count_table_row+1;
                                    RetentionTime=sum(ionSummary_Temp1(:,2))/ion_count_table;
                                    IonInfor_Table(ion_count_table_row,1)=d3;
                                    IonInfor_Table(ion_count_table_row,2)=RetentionTime;
                                    for z=1:ion_count_table
                                        IonInfor_Table(ion_count_table_row,2+5*z-4)=ionSummary_Temp1(z,1);
                                        IonInfor_Table(ion_count_table_row,2+5*z-3)=ionSummary_Temp1(z,3);
                                        IonInfor_Table(ion_count_table_row,2+5*z-2)=ionSummary_Temp1(z,5);
                                        IonInfor_Table(ion_count_table_row,2+5*z-1)=ionSummary_Temp1(z,6);
                                        IonInfor_Table(ion_count_table_row,2+5*z)=ionSummary_Temp1(z,7);
                                    end
                                    
                                    GroupPeak_Vis_Mark=1;
                                    
                                end
                            end
                        end
                        clear ionSummary_Temp0 ionSummary_Temp00 RepNosIon ionSummary_Temp ionSummary_Temp1 ...
                            ionSummary_Temp2 ionSummary_Temp3 ionSummary_Temp4 GroupedIonAbunSummary
                    end
                    
                    
                    if ion_count_table_row>0
                        IonInfor_Table0=unique(IonInfor_Table,'rows');
                        T0Length=size(IonInfor_Table0,1);
                        T0Width=size(IonInfor_Table0,2);
                        IonInfor_Table_Short0(1:T0Length,1:T0Width,con_count)=IonInfor_Table0(1:T0Length,1:T0Width);
                        clear IonInfor_Table0 IonInfor_Table
                    end
                    
                    
                end
                
                
                if GroupPeak_Vis_Mark==1
                    ionConNoMax=0;
                    TableIndex=size(IonInfor_Table_Short0);
                    if size(TableIndex,2)<3
                        TableIndex(1,3)=1;
                    end
                    
                    GEC=0;ISEC=0;
                    for d3=1:TableIndex(1,3)
                        GEC1=0;
                        TTT(1:TableIndex(1,1),1:TableIndex(1,2))=IonInfor_Table_Short0(1:TableIndex(1,1),1:TableIndex(1,2),d3);
                        for k=1:TableIndex(1,1)
                            iTTT=0;
                            if TTT(k,1)>0
                                for u=3:5:TableIndex(1,2)
                                    if TTT(k,u)>0
                                        iTTT=iTTT+1;
                                        TTT2(iTTT,1:2)=TTT(k,u:u+1);
                                    end
                                end
                                TTT3=unique(TTT2,'rows');
                                iTT=size(TTT3,1);
                                IonInfor_Table_Short_Derep(k,1:2,d3)=IonInfor_Table_Short0(k,1:2,d3);
                                for u=1:iTT
                                    IonInfor_Table_Short_Derep(k,u*2+1:u*2+2,d3)=TTT3(u,1:2);
                                    GEC1=1;
                                end
                            end
                            clear TTT2 TTT3
                        end
                        clear TTT
                        
                        if GEC1>0
                            TableIndex_Derep=size(IonInfor_Table_Short_Derep);
                            if size(TableIndex_Derep,2)<3
                                TableIndex_Derep(1,3)=1;
                            end
                            
                            
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableIndex_Derep(1,1)
                                if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            
                            if groupNo>0
                                str= sprintf('%s%s%s%s%s%s','GINFSam', num2str(SamID),'Con',num2str(d3),'N','.txt');
                                fid=fopen(str,'w');
                                IonIntNo=0;
                                for d1=1:TableIndex_Derep(1,1)
                                    if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                        for d2=3:2:TableIndex_Derep(1,2)
                                            if IonInfor_Table_Short_Derep(d1,d2,d3)>0
                                                Code=Sample_Feature(IonInfor_Table_Short_Derep(d1,1,d3),1);
                                                FeatureWriteHere(1,1:3)=GroupFeatureRecord(Code,1:3);
                                                fprintf(fid,'%d %.1f ',d1,IonInfor_Table_Short_Derep(d1,2,d3));
                                                for z=1:3
                                                    fprintf(fid,'%.4f ',FeatureWriteHere(1,z));
                                                end
                                                ionConNo=ionConNo+1;
                                                ionSummary001(ionConNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                                IonIntNo=IonIntNo+1;
                                                ionSummary0001(IonIntNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                                fprintf(fid,'%.1f %.4f ',IonInfor_Table_Short_Derep(d1,d2,d3),IonInfor_Table_Short_Derep(d1,d2+1,d3));
                                                fprintf(fid,'\n');
                                            end
                                        end
                                        
                                        if IonIntNo>0
                                            maxIonInt=max(ionSummary0001(:,2));
                                            maxIon(1,4)=0;
                                            for z=1:IonIntNo
                                                if maxIonInt==ionSummary0001(z,2)
                                                    maxIon(1,3)=ionSummary0001(z,1);
                                                end
                                                maxIon(1,4)=maxIon(1,4)+ionSummary0001(z,2);
                                            end
                                            GroupIntSum(d1,1:2,d3)=IonInfor_Table_Short_Derep(d1,1:2,d3);
                                            GroupIntSum(d1,3:4,d3)=maxIon(1,3:4);
                                            GEC=1;
                                        end
                                        clear ionSummary0001 maxIon
                                    end
                                end
                                fclose(fid);
                                clear IonInfor_Table_Short_Derep
                            end
                            if ionConNo>0
                                ionSummary002=unique(ionSummary001,'rows');
                                ionSummary002=sortrows(ionSummary002,1);
                                ionSummary(1:size(ionSummary002,1),d3)=ionSummary002(:,1);
                                ISEC=1;
                            end
                            clear ionSummary001 ionSummary002 ionSummary003
                            if ionConNo>ionConNoMax
                                ionConNoMax=ionConNo;
                            end
                        end
                    end
                    clear TableIndex
                    
                    if GEC>0
                        TableIndex=size(GroupIntSum);
                        if size(TableIndex)==2
                            TableIndex(1,3)=1;
                        end
                        
                        str= sprintf('%s%s%s','GREPSam',num2str(SamID),'N.txt');
                        fid=fopen(str,'w');
                        for d3=1:TableIndex(1,3)
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableIndex(1,1)
                                if GroupIntSum(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            if groupNo>0
                                fprintf(fid,'%s%s%s%s','Totally ',num2str(groupNo),' groups apparently visible under condition G',num2str(d3));
                                fprintf(fid,'\n');
                                for d1=1:TableIndex(1,1)
                                    if GroupIntSum(d1,1,d3)>0
                                        fprintf(fid,'%d %d ',d1,GroupIntSum(d1,1,d3));
                                        fprintf(fid,'%.1f ',GroupIntSum(d1,2,d3));
                                        fprintf(fid,'%.1f %.4f ',GroupIntSum(d1,3:4,d3));
                                        fprintf(fid,'\n');
                                    end
                                end
                            end
                            fprintf(fid,'\n');
                        end
                        fclose(fid);
                        clear GroupIntSum
                    end
                    clear IonInfor_Table_Short ionSummary001 ionSummary002
                    
                    if ISEC>0
                        DCLength=size(ionSummary,1);
                        DCWidth=size(ionSummary,2);
                    end
                    
                    if ionConNoMax>0
                        for ConID=1:DCWidth
                            XICSNLength=0;
                            for iMat=1:nOfMats
                                if strcmp( Mats(iMat).name(1:3),'Sam')
                                    MaSuMa(1,1)=0;
                                    MaSuMa(1,1)=0;
                                    if SamID<10 && ConID<10
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                                && (strcmp(Mats(iMat).name(9),'N'))...
                                                && strcmp(Mats(iMat).name(10),'.')
                                            MaSuMa(1,1)=1;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID<10
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'N'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=2;
                                        end
                                    end
                                    if SamID>=100 && ConID<10
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'N'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=3;
                                        end
                                    end
                                    if SamID<10 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'N'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=4;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'N'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=5;
                                        end
                                    end
                                    if SamID>=100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'N'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=6;
                                        end
                                    end
                                    if SamID<10 && ConID>=100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'N'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=7;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'N'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=8;
                                        end
                                    end
                                    if SamID>=100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                                && (strcmp(Mats(iMat).name(13),'N'))...
                                                && strcmp(Mats(iMat).name(14),'.')
                                            MaSuMa(1,1)=9;
                                        end
                                    end
                                    if MaSuMa(1,1)>0
                                        data = load(Mats(iMat).name);
                                        Scans=data.Scans;
                                        dataWidth=size(Scans,2);
                                        MergeMass=data.Masses;
                                        dataLength=size(MergeMass,1);
                                        MergeData=data.Data;
                                        Timerange=TIRA(ConID,2);
                                        
                                        FixedWidth=162;
                                        AcualWidth=dataWidth;
                                        Ratio=round(AcualWidth/FixedWidth);
                                        if Ratio>=1
                                            iCol=0;
                                            for k=1:Ratio:AcualWidth-Ratio
                                                iCol=iCol+1;
                                                dataTemp(1:dataLength,1:Ratio)=MergeData(1:dataLength,k:k+Ratio-1);
                                                for o=1:dataLength
                                                    Data_New(o,iCol)=sum(dataTemp(o,1:Ratio));
                                                end
                                                MergeTime(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+Ratio-1))/Scans(1,dataWidth)*Timerange;
                                            end
                                        else
                                            Ratio2=Round(FixedWidth/AcualWidth);
                                            iCol=Ratio2*AcualWidth;
                                            for o=1:dataWidth
                                                MergeTime(1,o*Ratio2-Ratio2+1:o*Ratio2)=Scans(1,o)/Scans(1,dataWidth)*Timerange;
                                                for k=1:dataLength
                                                    Data_New(k,o*Ratio2-Ratio2+1:o*Ratio2)=MergeData(k,o);
                                                end
                                            end
                                        end
                                        dataWidth=iCol;
                                        
                                        XIC=zeros(dataWidth,2);
                                        
                                        nCount=0;
                                        for r=1:DCLength
                                            if ionSummary(r,ConID)>0
                                                nCount=nCount+1;
                                                MassInfor(1,nCount)=ionSummary(r,ConID);
                                                for h=1:dataLength
                                                    if abs(ionSummary(r,ConID)-MergeMass(h,1))<IMI
                                                        for j=1:dataWidth
                                                            XIC(j,1)=MergeTime(1,j);
                                                            XIC(j,2)=sum(Data_New(h,j));
                                                        end
                                                        
                                                        
                                                        XICSN=XIC;
                                                        HighPoint=max(XICSN(:,2));
                                                        LowPoint=min(XICSN(:,2));
                                                        sectionNo=100;
                                                        Incre=(HighPoint-LowPoint)/sectionNo;
                                                        section=zeros(sectionNo,3);
                                                        
                                                        for i=1:sectionNo
                                                            section(i,1)=Incre*(i-1)+LowPoint;
                                                            section(i,2)=Incre*i+LowPoint;
                                                            section(i,3)=0;
                                                        end
                                                        XICSNLength=size(XICSN,1);
                                                        for j=1:XICSNLength
                                                            for u=1:sectionNo
                                                                if XICSN(j,2)>=section(u,1) && XICSN(j,2)<section(u,2)
                                                                    section(u,3)=section(u,3)+1;
                                                                end
                                                            end
                                                        end
                                                        chooseSection=max(section(:,3));
                                                        for i=1:sectionNo
                                                            if section(i,3)==chooseSection
                                                                baselineLow=section(i,1);
                                                                baselineHigh=section(i,2);
                                                            end
                                                        end
                                                        BaseLineValue=0;
                                                        count=0;
                                                        for i=1:XICSNLength
                                                            if XICSN(i,2)>=baselineLow && XICSN(i,2)<baselineHigh
                                                                BaseLineValue=BaseLineValue+XICSN(i,2);
                                                                count=count+1;
                                                            end
                                                        end
                                                        BaseLineValue=BaseLineValue/count;
                                                        
                                                        for i=1:XICSNLength
                                                            XICSN(i,2)=XICSN(i,2)-BaseLineValue;
                                                        end
                                                        
                                                        for j=1:dataWidth
                                                            XICSNSummary(j,1)=XICSN(j,1);
                                                            XICSNSummary(j,nCount+1)=XICSN(j,2);
                                                        end
                                                    end
                                                end
                                                clear XIC XICSN section
                                            end
                                        end
                                        
                                        if XICSNLength>0
                                            TICAppear=zeros(dataWidth,3);
                                            for i=1:dataWidth
                                                TICAppear(i,1)=XICSNSummary(i,1);
                                                TICAppear(i,2)=sum(XICSNSummary(i,2:nCount+1));
                                                TICAppear(i,3)=sum(Data_New(:,i));
                                            end
                                            
                                            str= sprintf('%s%s%s%s%s','TICSSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                            fid=fopen(str,'w');
                                            for u=1:dataWidth
                                                for v=1:3
                                                    fprintf(fid,'%.1f ',TICAppear(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','MassSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                            fid=fopen(str,'w');
                                            for v=1:nCount
                                                fprintf(fid,'%.1f ',MassInfor(1,v));
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','XICSSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                            fid=fopen(str,'w');
                                            for u=1:dataWidth
                                                for v=1:nCount+1
                                                    fprintf(fid,'%.1f ',XICSNSummary(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            clear TICAppear XICSNSummary MassInfor
                                        end
                                    end
                                end
                            end
                        end
                        
                        
                        clear ionSummary
                        
                    end
                end
            end
            clearvars -except ConID ConNo GroupDifferRatioControl IMI ITD IRT ...
                IntensityThreshold MB MBLength MA MassDifferTor Mats ...
                MR ML IMI RedundantIons SamID SamNoEn SamNoSt TIRALength ...
                TimeDifferTor TimeVariance files iFile nOfFiles nOfMats ...
                GroupFeatureRecord nGroup Sample_Feature nFeature Refdata DRLength t00
        end
        clearvars -except ConID ConNo GroupDifferRatioControl IMI ITD IRT ...
            IntensityThreshold MB MBLength MA MassDifferTor Mats ...
            MR ML IMI RedundantIons SamID SamNoEn SamNoSt TIRALength ...
            TimeDifferTor TimeVariance files iFile nOfFiles nOfMats t00
        
        t01 = cputime-t00;
        disp(['Calculation time = ',num2str(t01), 'Sam', num2str(SamID) ]);
    end
    t01=cputime-t00;
    disp(['Step3 = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    
    for SamID=SamNoSt:SamNoEn
        TIRALength=0;
        for iFile=1:nOfFiles
            for ConID=1:ConNo
                if (strcmp(files(iFile).name(1:3),'Sam'))
                    MaSuUV(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                                && strcmp(files(iFile).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                                && strcmp(files(iFile).name(13),'.')
                            MaSuUV(1,1)=9;
                        end
                    end
                    
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iFile).name);
                        UVTempLS=size(UVTemp,1);
                        TIRA(ConID,1)=ConID;
                        TIRA(ConID,2) =UVTemp(UVTempLS,1);
                        TIRALength=size(TIRA,1);
                    end
                end;
            end;
        end;
        if TIRALength>0
            nGroup=0;nFeature=0;DRLength=0;
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'GRFR')
                    MaSuGF(1,1)=0;
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'P'))
                            MaSuGF(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'P'))
                            MaSuGF(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'P'))
                            MaSuGF(1,1)=3;
                        end
                    end
                    
                    if MaSuGF(1,1)>0
                        GroupFeatureRecord=load(files(iFile).name);
                        nGroup=size(GroupFeatureRecord,1);
                    end
                end
            end
            
            
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'SAFE')
                    MaSuSF(1,1)=0;
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'P'))
                            MaSuSF(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'P'))
                            MaSuSF(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'P'))
                            MaSuSF(1,1)=3;
                        end
                    end
                    
                    if MaSuSF(1,1)>0
                        Sample_Feature=load(files(iFile).name);
                        nFeature=size(Sample_Feature,1);
                    end
                end
            end
            
            for iMatRef=1:nOfMats
                GroupPeak_Vis_Mark=0;
                if strcmp( Mats(iMatRef).name(1:4),'TDAN')
                    MaSuMa(1,1)=0;
                    if SamID<10
                        if str2double(Mats(iMatRef).name(8))==SamID ...
                                && (strcmp(Mats(iMatRef).name(9),'P'))
                            MaSuMa(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100
                        if str2double(Mats(iMatRef).name(8:9))==SamID ...
                                && (strcmp(Mats(iMatRef).name(10),'P'))
                            MaSuMa(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(Mats(iMatRef).name(8:10))==SamID ...
                                && (strcmp(Mats(iMatRef).name(11),'P'))
                            MaSuMa(1,1)=3;
                        end
                    end
                    if MaSuMa(1,1)>0
                        dataRef = load(Mats(iMatRef).name);
                        Refdata=dataRef.TapdanceGroupBYAbun;
                        DRLength=size(Refdata);
                        if size(DRLength,2)==2
                            DRLength(1,3)=1;
                        end
                    end
                end
            end
            if nGroup*nFeature*DRLength(1,1)~=0
                GroupPeak_Vis_Mark=0;
                con_count=0;
                for d2=1:4:DRLength(1,2)-3
                    
                    con_count=con_count+1;
                    ion_count_present=0;
                    ion_count_table_row=0;
                    
                    for d3=1:DRLength(1,3)
                        ion_count=0;
                        ion_count_table=0;
                        
                        for d1=1:DRLength(1,1)
                            if Refdata(d1,d2,d3)>0
                                ion_count=ion_count+1;
                                ionSummary_Temp(ion_count,1:4)=Refdata(d1,d2:d2+3,d3);
                                ionSummary_Temp(ion_count,5:7)=Refdata(d1,ConNo*4+1:ConNo*4+3,d3);
                                ionSummary_Temp(ion_count,8)=d3;
                            end
                            
                        end
                        
                        if ion_count>1
                            ionSummary_Temp00=unique(ionSummary_Temp,'rows');
                            clear ionSummary_Temp
                            ionSummary_Temp00=sortrows(ionSummary_Temp00,1);
                            iTemp=1;
                            ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(1,:);
                            for u=2:size(ionSummary_Temp00,1)
                                vot=0;
                                if ionSummary_Temp00(u,1)-ionSummary_Temp0(iTemp,1)>=IMI && vot==0
                                    iTemp=iTemp+1;
                                    ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(u,:);
                                end
                            end
                            
                            
                            if iTemp>=MA
                                clear ionSummary_Temp0
                                if iTemp>RedundantIons
                                    ionSummary_Temp0(:,1:3)=ionSummary_Temp00(:,1:3);
                                    ionSummary_Temp010=unique(ionSummary_Temp0,'rows');
                                    GridNumber=size(ionSummary_Temp010,1);
                                    ISTHigh=max(ionSummary_Temp010(:,3));
                                    ISTLow=min(ionSummary_Temp010(:,3));
                                    
                                    Interval_UL=(ISTHigh-ISTLow)/GridNumber;
                                    GroupedIonAbunSummary=zeros(GridNumber,3);
                                    
                                    for g=1:GridNumber
                                        GroupedIonAbunSummary(g,1)=ISTLow+Interval_UL*(g-1);
                                        GroupedIonAbunSummary(g,2)=ISTLow+Interval_UL*g;
                                    end
                                    
                                    for g=1:GridNumber
                                        for z=1:size(ionSummary_Temp010,1)
                                            if ionSummary_Temp010(z,3)<=GroupedIonAbunSummary(g,2) ...
                                                    && ionSummary_Temp010(z,3)>=GroupedIonAbunSummary(g,1)
                                                GroupedIonAbunSummary(g,3)=GroupedIonAbunSummary(g,3)+1;
                                            end
                                        end
                                    end
                                    HorizonNo=max(GroupedIonAbunSummary(:,3));
                                    for g=GridNumber:-1:1
                                        if GroupedIonAbunSummary(g,3)==HorizonNo
                                            HorizonAbun=GroupedIonAbunSummary(g,1);
                                        end
                                    end
                                    
                                    ThresholdAbun_Presented=HorizonAbun;
                                    clear ionSummary_Temp010
                                else
                                    ThresholdAbun_Presented=0;
                                end
                                
                                for z=1:size(ionSummary_Temp00,1)
                                    if ionSummary_Temp00(z,3)>=ThresholdAbun_Presented
                                        ion_count_table=ion_count_table+1;
                                        ionSummary_Temp1(ion_count_table,:)=ionSummary_Temp00(z,:);
                                    end
                                end
                                
                                
                                if ion_count_table>0
                                    ion_count_table_row=ion_count_table_row+1;
                                    RetentionTime=sum(ionSummary_Temp1(:,2))/ion_count_table;
                                    IonInfor_Table(ion_count_table_row,1)=d3;
                                    IonInfor_Table(ion_count_table_row,2)=RetentionTime;
                                    for z=1:ion_count_table
                                        IonInfor_Table(ion_count_table_row,2+5*z-4)=ionSummary_Temp1(z,1);
                                        IonInfor_Table(ion_count_table_row,2+5*z-3)=ionSummary_Temp1(z,3);
                                        IonInfor_Table(ion_count_table_row,2+5*z-2)=ionSummary_Temp1(z,5);
                                        IonInfor_Table(ion_count_table_row,2+5*z-1)=ionSummary_Temp1(z,6);
                                        IonInfor_Table(ion_count_table_row,2+5*z)=ionSummary_Temp1(z,7);
                                    end
                                    
                                    GroupPeak_Vis_Mark=1;
                                    
                                end
                            end
                        end
                        clear ionSummary_Temp0 ionSummary_Temp00 RepNosIon ionSummary_Temp ionSummary_Temp1 ...
                            ionSummary_Temp2 ionSummary_Temp3 ionSummary_Temp4 GroupedIonAbunSummary
                    end
                    if ion_count_table_row>0
                        IonInfor_Table0=unique(IonInfor_Table,'rows');
                        T0Length=size(IonInfor_Table0,1);
                        T0Width=size(IonInfor_Table0,2);
                        IonInfor_Table_Short0(1:T0Length,1:T0Width,con_count)=IonInfor_Table0(1:T0Length,1:T0Width);
                        clear IonInfor_Table0 IonInfor_Table
                    end
                end
                
                if GroupPeak_Vis_Mark==1
                    ionConNoMax=0;
                    TableIndex=size(IonInfor_Table_Short0);
                    if size(TableIndex,2)<3
                        TableIndex(1,3)=1;
                    end
                    
                    GEC=0;ISEC=0;
                    for d3=1:TableIndex(1,3)
                        GEC1=0;
                        TTT(1:TableIndex(1,1),1:TableIndex(1,2))=IonInfor_Table_Short0(1:TableIndex(1,1),1:TableIndex(1,2),d3);
                        for k=1:TableIndex(1,1)
                            iTTT=0;
                            if TTT(k,1)>0
                                for u=3:5:TableIndex(1,2)
                                    if TTT(k,u)>0
                                        iTTT=iTTT+1;
                                        TTT2(iTTT,1:2)=TTT(k,u:u+1);
                                    end
                                end
                                TTT3=unique(TTT2,'rows');
                                iTT=size(TTT3,1);
                                IonInfor_Table_Short_Derep(k,1:2,d3)=IonInfor_Table_Short0(k,1:2,d3);
                                GEC1=1;
                                for u=1:iTT
                                    IonInfor_Table_Short_Derep(k,u*2+1:u*2+2,d3)=TTT3(u,1:2);
                                end
                            end
                            clear TTT2 TTT3
                        end
                        clear TTT
                        
                        if GEC1>0
                            TableIndex_Derep=size(IonInfor_Table_Short_Derep);
                            if size(TableIndex_Derep,2)<3
                                TableIndex_Derep(1,3)=1;
                            end
                            
                            
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableIndex_Derep(1,1)
                                if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            
                            if groupNo>0
                                str= sprintf('%s%s%s%s%s%s','GINFSam', num2str(SamID),'Con',num2str(d3),'P','.txt');
                                fid=fopen(str,'w');
                                IonIntNo=0;
                                for d1=1:TableIndex_Derep(1,1)
                                    if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                        for d2=3:2:TableIndex_Derep(1,2)
                                            if IonInfor_Table_Short_Derep(d1,d2,d3)>0
                                                Code=Sample_Feature(IonInfor_Table_Short_Derep(d1,1,d3),1);
                                                FeatureWriteHere(1,1:3)=GroupFeatureRecord(Code,1:3);
                                                fprintf(fid,'%d %.1f ',d1,IonInfor_Table_Short_Derep(d1,2,d3));
                                                for z=1:3
                                                    fprintf(fid,'%.4f ',FeatureWriteHere(1,z));
                                                end
                                                ionConNo=ionConNo+1;
                                                ionSummary001(ionConNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                                IonIntNo=IonIntNo+1;
                                                ionSummary0001(IonIntNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                                fprintf(fid,'%.1f %.4f ',IonInfor_Table_Short_Derep(d1,d2,d3),IonInfor_Table_Short_Derep(d1,d2+1,d3));
                                                fprintf(fid,'\n');
                                            end
                                        end
                                        
                                        if IonIntNo>0
                                            maxIonInt=max(ionSummary0001(:,2));
                                            maxIon(1,4)=0;
                                            for z=1:IonIntNo
                                                if maxIonInt==ionSummary0001(z,2)
                                                    maxIon(1,3)=ionSummary0001(z,1);
                                                end
                                                maxIon(1,4)=maxIon(1,4)+ionSummary0001(z,2);
                                            end
                                            GroupIntSum(d1,1:2,d3)=IonInfor_Table_Short_Derep(d1,1:2,d3);
                                            GroupIntSum(d1,3:4,d3)=maxIon(1,3:4);
                                            GEC=1;
                                        end
                                        
                                        clear ionSummary0001 maxIon
                                    end
                                end
                                fclose(fid);
                                clear IonInfor_Table_Short_Derep
                            end
                            if ionConNo>0
                                ionSummary002=unique(ionSummary001,'rows');
                                ionSummary002=sortrows(ionSummary002,1);
                                ionSummary(1:size(ionSummary002,1),d3)=ionSummary002(:,1);
                                ISEC=1;
                            end
                            clear ionSummary001 ionSummary002 ionSummary003
                            
                            if ionConNo>ionConNoMax
                                ionConNoMax=ionConNo;
                            end
                        end
                    end
                    clear TableIndex
                    
                    if GEC>0
                        TableIndex=size(GroupIntSum);
                        if size(TableIndex)==2
                            TableIndex(1,3)=1;
                        end
                        
                        str= sprintf('%s%s%s','GREPSam',num2str(SamID),'P.txt');
                        fid=fopen(str,'w');
                        for d3=1:TableIndex(1,3)
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableIndex(1,1)
                                if GroupIntSum(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            if groupNo>0
                                fprintf(fid,'%s%s%s%s','Totally ',num2str(groupNo),' groups apparently visible under condition G',num2str(d3));
                                fprintf(fid,'\n');
                                for d1=1:TableIndex(1,1)
                                    if GroupIntSum(d1,1,d3)>0
                                        fprintf(fid,'%d %d ',d1,GroupIntSum(d1,1,d3));
                                        fprintf(fid,'%.1f ',GroupIntSum(d1,2,d3));
                                        fprintf(fid,'%.1f %.4f ',GroupIntSum(d1,3:4,d3));
                                        fprintf(fid,'\n');
                                    end
                                end
                            end
                            fprintf(fid,'\n');
                        end
                        fclose(fid);
                        clear GroupIntSum
                    end
                    clear IonInfor_Table_Short ionSummary001 ionSummary002
                    
                    if ISEC>0
                        DCLength=size(ionSummary,1);
                        DCWidth=size(ionSummary,2);
                    end
                    
                    if ionConNoMax>0
                        for ConID=1:DCWidth
                            XICSNLength=0;
                            for iMat=1:nOfMats
                                if strcmp( Mats(iMat).name(1:3),'Sam')
                                    MaSuMa(1,1)=0;
                                    MaSuMa(1,1)=0;
                                    if SamID<10 && ConID<10
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                                && (strcmp(Mats(iMat).name(9),'P'))...
                                                && strcmp(Mats(iMat).name(10),'.')
                                            MaSuMa(1,1)=1;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID<10
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'P'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=2;
                                        end
                                    end
                                    if SamID>=100 && ConID<10
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'P'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=3;
                                        end
                                    end
                                    if SamID<10 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'P'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=4;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'P'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=5;
                                        end
                                    end
                                    if SamID>=100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'P'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=6;
                                        end
                                    end
                                    if SamID<10 && ConID>=100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'P'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=7;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'P'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=8;
                                        end
                                    end
                                    if SamID>=100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                                && (strcmp(Mats(iMat).name(13),'P'))...
                                                && strcmp(Mats(iMat).name(14),'.')
                                            MaSuMa(1,1)=9;
                                        end
                                    end
                                    
                                    if MaSuMa(1,1)>0
                                        data = load(Mats(iMat).name);
                                        Scans=data.Scans;
                                        dataWidth=size(Scans,2);
                                        MergeMass=data.Masses;
                                        dataLength=size(MergeMass,1);
                                        MergeData=data.Data;
                                        Timerange=TIRA(ConID,2);
                                        
                                        FixedWidth=162;
                                        AcualWidth=dataWidth;
                                        Ratio=round(AcualWidth/FixedWidth);
                                        if Ratio>=1
                                            iCol=0;
                                            for k=1:Ratio:AcualWidth-Ratio
                                                iCol=iCol+1;
                                                dataTemp(1:dataLength,1:Ratio)=MergeData(1:dataLength,k:k+Ratio-1);
                                                for o=1:dataLength
                                                    Data_New(o,iCol)=sum(dataTemp(o,1:Ratio));
                                                end
                                                MergeTime(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+Ratio-1))/Scans(1,dataWidth)*Timerange;
                                            end
                                        else
                                            Ratio2=Round(FixedWidth/AcualWidth);
                                            iCol=Ratio2*AcualWidth;
                                            for o=1:dataWidth
                                                MergeTime(1,o*Ratio2-Ratio2+1:o*Ratio2)=Scans(1,o)/Scans(1,dataWidth)*Timerange;
                                                for k=1:dataLength
                                                    Data_New(k,o*Ratio2-Ratio2+1:o*Ratio2)=MergeData(k,o);
                                                end
                                            end
                                        end
                                        dataWidth=iCol;
                                        
                                        XIC=zeros(dataWidth,2);
                                        
                                        nCount=0;
                                        for r=1:DCLength
                                            if ionSummary(r,ConID)>0
                                                nCount=nCount+1;
                                                MassInfor(1,nCount)=ionSummary(r,ConID);
                                                for h=1:dataLength
                                                    if abs(ionSummary(r,ConID)-MergeMass(h,1))<IMI
                                                        for j=1:dataWidth
                                                            XIC(j,1)=MergeTime(1,j);
                                                            XIC(j,2)=sum(Data_New(h,j));
                                                        end
                                                        
                                                        
                                                        XICSN=XIC;
                                                        HighPoint=max(XICSN(:,2));
                                                        LowPoint=min(XICSN(:,2));
                                                        sectionNo=100;
                                                        Incre=(HighPoint-LowPoint)/sectionNo;
                                                        section=zeros(sectionNo,3);
                                                        
                                                        for i=1:sectionNo
                                                            section(i,1)=Incre*(i-1)+LowPoint;
                                                            section(i,2)=Incre*i+LowPoint;
                                                            section(i,3)=0;
                                                        end
                                                        XICSNLength=size(XICSN,1);
                                                        for j=1:XICSNLength
                                                            for u=1:sectionNo
                                                                if XICSN(j,2)>=section(u,1) && XICSN(j,2)<section(u,2)
                                                                    section(u,3)=section(u,3)+1;
                                                                end
                                                            end
                                                        end
                                                        chooseSection=max(section(:,3));
                                                        for i=1:sectionNo
                                                            if section(i,3)==chooseSection
                                                                baselineLow=section(i,1);
                                                                baselineHigh=section(i,2);
                                                            end
                                                        end
                                                        BaseLineValue=0;
                                                        count=0;
                                                        for i=1:XICSNLength
                                                            if XICSN(i,2)>=baselineLow && XICSN(i,2)<baselineHigh
                                                                BaseLineValue=BaseLineValue+XICSN(i,2);
                                                                count=count+1;
                                                            end
                                                        end
                                                        BaseLineValue=BaseLineValue/count;
                                                        
                                                        for i=1:XICSNLength
                                                            XICSN(i,2)=XICSN(i,2)-BaseLineValue;
                                                        end
                                                        
                                                        for j=1:dataWidth
                                                            XICSNSummary(j,1)=XICSN(j,1);
                                                            XICSNSummary(j,nCount+1)=XICSN(j,2);
                                                        end
                                                    end
                                                end
                                                clear XIC XICSN section
                                            end
                                        end
                                        
                                        if XICSNLength>0
                                            TICAppear=zeros(dataWidth,3);
                                            for i=1:dataWidth
                                                TICAppear(i,1)=XICSNSummary(i,1);
                                                TICAppear(i,2)=sum(XICSNSummary(i,2:nCount+1));
                                                TICAppear(i,3)=sum(Data_New(:,i));
                                            end
                                            
                                            str= sprintf('%s%s%s%s%s','TICSSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                            fid=fopen(str,'w');
                                            for u=1:dataWidth
                                                for v=1:3
                                                    fprintf(fid,'%.1f ',TICAppear(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','MassSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                            fid=fopen(str,'w');
                                            for v=1:nCount
                                                fprintf(fid,'%.1f ',MassInfor(1,v));
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','XICSSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                            fid=fopen(str,'w');
                                            for u=1:dataWidth
                                                for v=1:nCount+1
                                                    fprintf(fid,'%.1f ',XICSNSummary(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            clear TICAppear XICSNSummary MassInfor
                                        end
                                    end
                                end
                            end
                        end
                        clear ionSummary
                    end
                end
            end
            clearvars -except ConID ConNo GroupDifferRatioControl IMI ITD IRT ...
                IntensityThreshold MB MBLength MA MassDifferTor Mats ...
                MR ML IMI RedundantIons SamID SamNoEn SamNoSt TIRALength ...
                TimeDifferTor TimeVariance files iFile nOfFiles nOfMats ...
                GroupFeatureRecord nGroup Sample_Feature nFeature Refdata DRLength t00
        end
        clearvars -except ConID ConNo GroupDifferRatioControl IMI ITD IRT ...
            IntensityThreshold MB MBLength MA MassDifferTor Mats ...
            MR ML IMI RedundantIons SamID SamNoEn SamNoSt TIRALength ...
            TimeDifferTor TimeVariance files iFile nOfFiles nOfMats t00
        
        t01 = cputime-t00;
        disp(['Calculation time = ',num2str(t01), 'Sam', num2str(SamID) ]);
    end
    t01=cputime-t00;
    disp(['Step3 = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    
    SDT=0.05;
    IDT=0.1;
    ITV=0.2;
    MIR=0.95;
    
    files = dir(fullfile('.', '*.txt'));
    [nOfFiles,~] = size(files);
    
    for SamID=SamNoSt:SamNoEn
        new_folder=['IDC_HILIC_Sam',num2str(SamID)];
        mkdir(new_folder)
        AddedLength=0;
        for ConID=1:ConNo
            GINFCode=0;
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:4),'GINF'))
                    MaSuGI(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'N')
                            MaSuGI(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuGI(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuGI(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuGI(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuGI(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuGI(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuGI(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuGI(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'N')
                            MaSuGI(1,1)=9;
                        end
                    end
                    
                    if MaSuGI(1,1)>0
                        GISumTemp=load(files(iFile).name);
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),1)=ConID;
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),2:size(GISumTemp,2)+1)=GISumTemp;
                        GINFCode=1;
                    end
                end
            end
            if GINFCode==1
                for iFile=1:nOfFiles
                    if (strcmp(files(iFile).name(1:4),'DENO'))
                        MaSuDN(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                    && strcmp(files(iFile).name(13),'N')
                                MaSuDN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                    && strcmp(files(iFile).name(14),'N')
                                MaSuDN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=3;
                            end
                        end
                        if SamID<10 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                    && strcmp(files(iFile).name(14),'N')
                                MaSuDN(1,1)=4;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=5;
                            end
                        end
                        if SamID>=100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                    && strcmp(files(iFile).name(16),'N')
                                MaSuDN(1,1)=6;
                            end
                        end
                        if SamID<10 && ConID>=100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=7;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                    && strcmp(files(iFile).name(16),'N')
                                MaSuDN(1,1)=8;
                            end
                        end
                        if SamID>=100 && ConID>=100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                    && strcmp(files(iFile).name(17),'N')
                                MaSuDN(1,1)=9;
                            end
                        end
                        
                        if MaSuDN(1,1)>0
                            IntSumTemp=load(files(iFile).name);
                            for z=1:size(IntSumTemp,1)
                                for u=AddedLength+1:AddedLength+size(GISumTemp,1)
                                    if abs(GISumTemp2(u,7)-IntSumTemp(z,1))<IMI
                                        GISumTemp2(u,8)=IntSumTemp(z,11);
                                    end
                                end
                            end
                            AddedLength=AddedLength+size(GISumTemp,1);
                            clear GISumTemp
                        end
                    end
                end
            end
        end
        if AddedLength>0
            
            RetentionBehavior=GISumTemp2(:,4:6);
            ShortBehavior=unique(RetentionBehavior,'rows');
            ShortBehavior=sortrows(ShortBehavior,3);
            nDSBehavior=1;
            SP=0;
            WidthCode=zeros(size(ShortBehavior,1),1);
            for z=1:size(ShortBehavior,1)
                if ShortBehavior(z,3)>=ML-0.05 && SP==0
                    DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                    z1=z;
                    SP=1;
                    WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                end
            end
            
            for z=z1+1:size(ShortBehavior,1)
                if ShortBehavior(z,3)>=ML-0.05
                    Rep=0;
                    for u=1:nDSBehavior
                        for v=1:3:WidthCode(u,1)-1
                            if abs(ShortBehavior(z,1)-DSBehavior(u,v))<SDT ...
                                    && abs(ShortBehavior(z,2)-DSBehavior(u,v+1))<IDT...
                                    && Rep==0
                                
                                
                                DSBehavior(u,WidthCode(u,1)+1:WidthCode(u,1)+3)=ShortBehavior(z,1:3);
                                WidthCode(u,1)=WidthCode(u,1)+3;
                                Rep=1;
                            end
                        end
                    end
                    if Rep==0
                        nDSBehavior=nDSBehavior+1;
                        DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                        WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                    end
                end
            end
            
            nIons=0;
            if nDSBehavior>1
                IonNumber=zeros(nDSBehavior,1);
                for p=1:nDSBehavior
                    for v=1:3:size(DSBehavior,2)
                        for q=1:size(GISumTemp2,1)
                            if GISumTemp2(q,4:6)==DSBehavior(p,v:v+2)
                                IonNumber(p,1)=IonNumber(p,1)+1;
                                IonSummary(IonNumber(p,1),:,p)=GISumTemp2(q,:);
                            end
                        end
                    end
                end
                clear IonNumber
                
                nIonSummaryShort=0;
                for z=1:nDSBehavior
                    ConTemp=IonSummary(:,1,z);
                    ConTempShort=unique(ConTemp,'rows');
                    nConCount=0;
                    for k=1:size(ConTempShort,1)
                        if ConTempShort(k,1)>0
                            nConCount=nConCount+1;
                        end
                    end
                    if nConCount>=MR
                        nIonSummaryShort=nIonSummaryShort+1;
                        IonSummaryShort(:,:,nIonSummaryShort)=IonSummary(:,:,z);
                    end
                    clear ConTemp ConTempShort
                end
                
                if nIonSummaryShort>0
                    IonNumber=zeros(nIonSummaryShort,1);
                    for z=1:nIonSummaryShort
                        for u=1:size(IonSummaryShort,1)
                            IonTemp(1,:)=IonSummaryShort(u,:,z);
                            nRepCount=1;
                            for v=1:size(IonSummaryShort,1)
                                if abs(IonSummaryShort(v,7,z)-IonSummaryShort(u,7,z))<=MassDifferTor
                                    nRepCount=nRepCount+1;
                                    IonTemp(nRepCount,:)=IonSummaryShort(v,:,z);
                                end
                            end
                            ConTemp=IonTemp(:,1);
                            ConTempShort=unique(ConTemp,'rows');
                            if size(ConTempShort,1)>=MR
                                IonNumber(z,1)=IonNumber(z,1)+1;
                                IonSummaryDS(IonNumber(z,1),:,z)=IonSummaryShort(u,:,z);
                                
                                conditionNo=1;
                                load Mobile_Phase.txt
                                MB=Mobile_Phase;
                                MBLength=size(MB,1);
                                tR_Assume=0.1:0.1:100;
                                tR_Assume=tR_Assume';
                                
                                
                                solutionCount=0;
                                for o=1:size(tR_Assume,1)
                                    tR=tR_Assume(o,1);
                                    for u=2:MBLength
                                        if tR>MB(u-1,1) && tR<MB(u,1)
                                            RatioH2O=(tR-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                            u0=u;
                                            volH2O=0;
                                            for u1=1:u0-1
                                                volH2O=volH2O+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                            end
                                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-tR);
                                            volH2O=volH2O/100;
                                            volMeOH(1,conditionNo)=tR-volH2O;
                                            RatioStrong=log10(volH2O/tR);
                                        end
                                    end
                                    
                                    tR0=10^((RatioStrong-IonSummaryDS(IonNumber(z,1),5,z))/IonSummaryDS(IonNumber(z,1),4,z));
                                    if abs(tR-tR0)<TimeDifferTor*4
                                        solutionCount=solutionCount+1;
                                        solutionSet(solutionCount,1)=tR;
                                        solutionSet(solutionCount,3)=abs(tR-tR0);
                                        solutionSet(solutionCount,2)=RatioStrong;
                                    end
                                end
                                for o=1:solutionCount
                                    if solutionSet(o,3)==min(solutionSet(:,3))
                                        IonSummaryDS(IonNumber(z,1),3,z)=solutionSet(o,1);
                                    end
                                end
                                clear solutionSet
                            end
                            clear ConTemp ConTempShort IonTemp
                        end
                    end
                    clear IonNumber
                    
                    
                    nIonSummaryTS=0;
                    for z=1:nIonSummaryShort
                        if IonSummaryDS(1,1,z)>0
                            IonSummaryTemp(1,:,z)=IonSummaryDS(1,:,z);
                            ITST=1;
                            for u=2:size(IonSummaryDS,1)
                                Rep=0;
                                for v=1:ITST
                                    if abs(IonSummaryDS(u,7,z)-IonSummaryTemp(v,7,z))<=MassDifferTor
                                        Rep=1;
                                        if IonSummaryDS(u,8,z)>IonSummaryTemp(v,8,z)
                                            IonSummaryTemp(v,:,z)=IonSummaryDS(u,:,z);
                                        end
                                    end
                                end
                                if Rep==0
                                    ITST=ITST+1;
                                    IonSummaryTemp(ITST,:,z)=IonSummaryDS(u,:,z);
                                end
                            end
                            nIonSummaryTS=nIonSummaryTS+1;
                            IonSummaryTS(1:ITST,:,nIonSummaryTS)=IonSummaryTemp(1:ITST,:,z);
                            clear IonSummaryTemp
                        end
                    end
                    
                    if nIonSummaryTS>0
                        nIonSummarySS=0;
                        for z=1:nIonSummaryTS
                            for u=1:size(IonSummaryTS,1)
                                if IonSummaryTS(u,1,z)>0
                                    nIonSummarySS=nIonSummarySS+1;
                                    IonSummarySS(nIonSummarySS,1:6)=IonSummaryTS(u,3:8,z);
                                end
                            end
                        end
                        IonSummaryS3=unique(IonSummarySS,'rows');
                        nIons=size(IonSummaryS3,1);
                        
                    end
                end
            end
            
            
            if nIons>0
                IonSummaryS3(:,7)=0;
                for ConID=1:ConNo
                    
                    for iFile=1:nOfFiles
                        if (strcmp(files(iFile).name(1:4),'DENO'))
                            MaSuDN(1,1)=0;
                            if SamID<10 && ConID<10
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                        && strcmp(files(iFile).name(13),'N')
                                    MaSuDN(1,1)=1;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID<10
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                        && strcmp(files(iFile).name(14),'N')
                                    MaSuDN(1,1)=2;
                                end
                            end
                            if SamID>=100 && ConID<10
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                        && strcmp(files(iFile).name(15),'N')
                                    MaSuDN(1,1)=3;
                                end
                            end
                            if SamID<10 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                        && strcmp(files(iFile).name(14),'N')
                                    MaSuDN(1,1)=4;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                        && strcmp(files(iFile).name(15),'N')
                                    MaSuDN(1,1)=5;
                                end
                            end
                            if SamID>=100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                        && strcmp(files(iFile).name(16),'N')
                                    MaSuDN(1,1)=6;
                                end
                            end
                            if SamID<10 && ConID>=100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                        && strcmp(files(iFile).name(15),'N')
                                    MaSuDN(1,1)=7;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                        && strcmp(files(iFile).name(16),'N')
                                    MaSuDN(1,1)=8;
                                end
                            end
                            if SamID>=100 && ConID>=100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                        && strcmp(files(iFile).name(17),'N')
                                    MaSuDN(1,1)=9;
                                end
                            end
                            
                            if MaSuDN(1,1)>0
                                IntSumTemp=load(files(iFile).name);
                                for r=1:nIons
                                    if IonSummaryS3(r,7)==0
                                        DiF=IonSummaryS3(r,5);
                                        TiF=IonSummaryS3(r,1);
                                        for z=1:size(IntSumTemp,1)
                                            if abs(IntSumTemp(z,1)-IonSummaryS3(r,5))<DiF
                                                
                                                conditionNo=ConID;
                                                load Mobile_Phase.txt
                                                MB=Mobile_Phase;
                                                MBLength=size(MB,1);
                                                tR_Assume=0.1:0.1:100;
                                                tR_Assume=tR_Assume';
                                                
                                                
                                                solutionCount=0;
                                                for o=1:size(tR_Assume,1)
                                                    tR=tR_Assume(o,1);
                                                    for u=2:MBLength
                                                        if tR>MB(u-1,1) && tR<MB(u,1)
                                                            RatioH2O=(tR-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                                            u0=u;
                                                            volH2O=0;
                                                            for u1=1:u0-1
                                                                volH2O=volH2O+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                                            end
                                                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-tR);
                                                            volH2O=volH2O/100;
                                                            volMeOH(1,conditionNo)=tR-volH2O;
                                                            RatioStrong=log10(volH2O/tR);
                                                        end
                                                    end
                                                    
                                                    tR0=10^((RatioStrong-IonSummaryS3(r,3))/IonSummaryS3(r,2));
                                                    if abs(tR-tR0)<TimeDifferTor*4
                                                        solutionCount=solutionCount+1;
                                                        solutionSet(solutionCount,1)=tR;
                                                        solutionSet(solutionCount,3)=abs(tR-tR0);
                                                        solutionSet(solutionCount,2)=RatioStrong;
                                                    end
                                                end
                                                for o=1:solutionCount
                                                    if solutionSet(o,3)==min(solutionSet(:,3))
                                                        tFound=solutionSet(o,1);
                                                    end
                                                end
                                                clear solutionSet
                                                
                                                
                                                if abs(IntSumTemp(z,2)-tFound)<4*TimeDifferTor
                                                    DiF=abs(IntSumTemp(z,1)-IonSummaryS3(r,5));
                                                    IonSummaryS3(r,7)=IntSumTemp(z,12);
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                
                nIntSum=1;
                IntSummary(nIntSum,1:4)=IonSummaryS3(1,1:4);
                IntSummary(nIntSum,5)=IonSummaryS3(1,6);
                IntSummary(nIntSum,6)=1;
                for z=2:size(IonSummaryS3,1)
                    if IonSummaryS3(z,1:4)==IntSummary(nIntSum,1:4)
                        if IntSummary(nIntSum,5)<IonSummaryS3(z,6)
                            IntSummary(nIntSum,5)=IonSummaryS3(z,6);
                        end
                        IntSummary(nIntSum,6)=IntSummary(nIntSum,6)+1;
                    else
                        nIntSum=nIntSum+1;
                        IntSummary(nIntSum,1:4)=IonSummaryS3(z,1:4);
                        IntSummary(nIntSum,5)=IonSummaryS3(z,6);
                        IntSummary(nIntSum,6)=1;
                    end
                end
                
                
                NonOne=0;
                for z=1:nIntSum
                    if IntSummary(z,6)>1 && NonOne==0
                        nIntSumShort=1;
                        IntSummaryShort(nIntSumShort,:)=IntSummary(z,:);
                        z1=z;
                        NonOne=1;
                    end
                end
                
                for z=z1:nIntSum
                    if abs(IntSummaryShort(nIntSumShort,2)-IntSummary(z,2))<SDT ...
                            && abs(IntSummaryShort(nIntSumShort,3)-IntSummary(z,3))<IDT
                        if IntSummaryShort(nIntSumShort,5)<IntSummary(z,5)
                            IntSummaryShort(nIntSumShort,1:5)=IntSummary(z,1:5);
                        end
                        IntSummaryShort(nIntSumShort,6)=IntSummary(z,6)+IntSummaryShort(nIntSumShort,6);
                    else if IntSummary(z,6)>1
                            nIntSumShort=nIntSumShort+1;
                            IntSummaryShort(nIntSumShort,:)=IntSummary(z,:);
                        end
                    end
                end
                
                nIsoSummary=0;
                for z=1:nIntSumShort
                    nIsoTemp=0;
                    for u=1:size(IonSummaryS3,1)
                        if abs(IonSummaryS3(u,2)-IntSummaryShort(z,2))<SDT ...
                                && abs(IonSummaryS3(u,3)-IntSummaryShort(z,3))<IDT
                            nIsoTemp=nIsoTemp+1;
                            IsoTemp(nIsoTemp,:)=IonSummaryS3(u,:);
                        end
                    end
                    nIsoSummary=nIsoSummary+1;
                    IsoSummary(nIsoSummary,1:3)=IntSummaryShort(z,2:4);
                    IsoSummary(nIsoSummary,4)=IntSummaryShort(z,1);
                    IsoSummary(nIsoSummary,5)=IntSummaryShort(z,5);
                    IsoTemp=sortrows(IsoTemp,-6);
                    IsoSummary(nIsoSummary,6)=IsoTemp(1,7);
                    nCount=1;
                    nCountRem=0;
                    IsoSummary(nIsoSummary,6+nCount)=IsoTemp(1,5);
                    for p=2:nIsoTemp
                        if abs(IsoSummary(nIsoSummary,6)-IsoTemp(p,7))<0.2
                            nCount=nCount+1;
                            IsoSummary(nIsoSummary,6+nCount)=IsoTemp(p,5);
                        else
                            nCountRem=nCountRem+1;
                            IsoTempRem(nCountRem,:)=IsoTemp(p,:);
                        end
                    end
                    if nCountRem>0
                        nIsoSummary=nIsoSummary+1;
                        IsoSummary(nIsoSummary,6)=mean(IsoTempRem(:,7));
                        for q=1:nCountRem
                            IsoSummary(nIsoSummary,6+q)=IsoTempRem(q,5);
                        end
                    end
                    clear IsoTemp IsoTempRem
                    
                    
                end
                str= sprintf('%s/%s%s%s%s',new_folder,'IDCS','Sam',num2str(SamID),'N.txt');
                fid=fopen(str,'w');
                for u=1:nIsoSummary
                    fprintf(fid,'%.4f ',IsoSummary(u,1));
                    fprintf(fid,'%.4f ',IsoSummary(u,2));
                    if IsoSummary(u,3)<ML && IsoSummary(u,2)~=0
                        IsoSummary(u,3)=ML;
                    end
                    fprintf(fid,'%.4f ',IsoSummary(u,3));
                    fprintf(fid,'%d ',IsoSummary(u,4));
                    fprintf(fid,'%.3f ',IsoSummary(u,5));
                    fprintf(fid,'%.3f ',IsoSummary(u,6));
                    
                    for v=7:size(IsoSummary,2)
                        fprintf(fid,'%.1f ',IsoSummary(u,v));
                    end
                    fprintf(fid,'\n');
                end
                fclose(fid);
                clear IsoSummary
            end
        end
        clearvars -except AddedLength ConNo GroupDifferRatioControl IMI IDT ITV...
            MB MBLength MA MassDifferTor Mats MIR ML MR IMI ...
            SamID SamNoEn SamNoSt SDT TimeDifferTor TimeVariance files iFile nOfFiles nOfMats ...
            new_folder t00
        t01=cputime-t00;
        disp(['Step4 = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    end
    
    
    for SamID=SamNoSt:SamNoEn
        new_folder=['IDC_HILIC_Sam',num2str(SamID)];
        mkdir(new_folder)
        AddedLength=0;
        for ConID=1:ConNo
            GINFCode=0;
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:4),'GINF'))
                    MaSuGI(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'P')
                            MaSuGI(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuGI(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuGI(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuGI(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuGI(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuGI(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuGI(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuGI(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'P')
                            MaSuGI(1,1)=9;
                        end
                    end
                    
                    if MaSuGI(1,1)>0
                        GISumTemp=load(files(iFile).name);
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),1)=ConID;
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),2:size(GISumTemp,2)+1)=GISumTemp;
                        GINFCode=1;
                    end
                end
            end
            if GINFCode==1
                for iFile=1:nOfFiles
                    if (strcmp(files(iFile).name(1:4),'DENO'))
                        MaSuDN(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                    && strcmp(files(iFile).name(13),'P')
                                MaSuDN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                    && strcmp(files(iFile).name(14),'P')
                                MaSuDN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=3;
                            end
                        end
                        if SamID<10 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                    && strcmp(files(iFile).name(14),'P')
                                MaSuDN(1,1)=4;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=5;
                            end
                        end
                        if SamID>=100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                    && strcmp(files(iFile).name(16),'P')
                                MaSuDN(1,1)=6;
                            end
                        end
                        if SamID<10 && ConID>=100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=7;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                    && strcmp(files(iFile).name(16),'P')
                                MaSuDN(1,1)=8;
                            end
                        end
                        if SamID>=100 && ConID>=100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                    && strcmp(files(iFile).name(17),'P')
                                MaSuDN(1,1)=9;
                            end
                        end
                        
                        if MaSuDN(1,1)>0
                            IntSumTemp=load(files(iFile).name);
                            for z=1:size(IntSumTemp,1)
                                for u=AddedLength+1:AddedLength+size(GISumTemp,1)
                                    if abs(GISumTemp2(u,7)-IntSumTemp(z,1))<IMI
                                        GISumTemp2(u,8)=IntSumTemp(z,11);
                                    end
                                end
                            end
                            AddedLength=AddedLength+size(GISumTemp,1);
                            clear GISumTemp
                        end
                    end
                end
            end
        end
        if AddedLength>0
            
            RetentionBehavior=GISumTemp2(:,4:6);
            ShortBehavior=unique(RetentionBehavior,'rows');
            ShortBehavior=sortrows(ShortBehavior,3);
            nDSBehavior=1;
            SP=0;
            WidthCode=zeros(size(ShortBehavior,1),1);
            for z=1:size(ShortBehavior,1)
                if ShortBehavior(z,3)>=ML-0.05 && SP==0
                    DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                    z1=z;
                    SP=1;
                    WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                end
            end
            
            for z=z1+1:size(ShortBehavior,1)
                if ShortBehavior(z,3)>=ML-0.05
                    Rep=0;
                    for u=1:nDSBehavior
                        for v=1:3:WidthCode(u,1)-1
                            if abs(ShortBehavior(z,1)-DSBehavior(u,v))<SDT ...
                                    && abs(ShortBehavior(z,2)-DSBehavior(u,v+1))<IDT...
                                    && Rep==0
                                
                                
                                DSBehavior(u,WidthCode(u,1)+1:WidthCode(u,1)+3)=ShortBehavior(z,1:3);
                                WidthCode(u,1)=WidthCode(u,1)+3;
                                Rep=1;
                            end
                        end
                    end
                    if Rep==0
                        nDSBehavior=nDSBehavior+1;
                        DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                        WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                    end
                end
            end
            
            nIons=0;
            if nDSBehavior>1
                IonNumber=zeros(nDSBehavior,1);
                for p=1:nDSBehavior
                    for v=1:3:size(DSBehavior,2)
                        for q=1:size(GISumTemp2,1)
                            if GISumTemp2(q,4:6)==DSBehavior(p,v:v+2)
                                IonNumber(p,1)=IonNumber(p,1)+1;
                                IonSummary(IonNumber(p,1),:,p)=GISumTemp2(q,:);
                            end
                        end
                    end
                end
                clear IonNumber
                
                nIonSummaryShort=0;
                for z=1:nDSBehavior
                    ConTemp=IonSummary(:,1,z);
                    ConTempShort=unique(ConTemp,'rows');
                    nConCount=0;
                    for k=1:size(ConTempShort,1)
                        if ConTempShort(k,1)>0
                            nConCount=nConCount+1;
                        end
                    end
                    if nConCount>=MR
                        nIonSummaryShort=nIonSummaryShort+1;
                        IonSummaryShort(:,:,nIonSummaryShort)=IonSummary(:,:,z);
                    end
                    clear ConTemp ConTempShort
                end
                
                if nIonSummaryShort>0
                    IonNumber=zeros(nIonSummaryShort,1);
                    for z=1:nIonSummaryShort
                        for u=1:size(IonSummaryShort,1)
                            IonTemp(1,:)=IonSummaryShort(u,:,z);
                            nRepCount=1;
                            for v=1:size(IonSummaryShort,1)
                                if abs(IonSummaryShort(v,7,z)-IonSummaryShort(u,7,z))<=MassDifferTor
                                    nRepCount=nRepCount+1;
                                    IonTemp(nRepCount,:)=IonSummaryShort(v,:,z);
                                end
                            end
                            ConTemp=IonTemp(:,1);
                            ConTempShort=unique(ConTemp,'rows');
                            if size(ConTempShort,1)>=MR
                                IonNumber(z,1)=IonNumber(z,1)+1;
                                IonSummaryDS(IonNumber(z,1),:,z)=IonSummaryShort(u,:,z);
                                
                                conditionNo=1;
                                load Mobile_Phase.txt
                                MB=Mobile_Phase;
                                MBLength=size(MB,1);
                                tR_Assume=0.1:0.1:100;
                                tR_Assume=tR_Assume';
                                
                                
                                solutionCount=0;
                                for o=1:size(tR_Assume,1)
                                    tR=tR_Assume(o,1);
                                    for u=2:MBLength
                                        if tR>MB(u-1,1) && tR<MB(u,1)
                                            RatioH2O=(tR-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                            u0=u;
                                            volH2O=0;
                                            for u1=1:u0-1
                                                volH2O=volH2O+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                            end
                                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-tR);
                                            volH2O=volH2O/100;
                                            volMeOH(1,conditionNo)=tR-volH2O;
                                            RatioStrong=log10(volH2O/tR);
                                        end
                                    end
                                    
                                    tR0=10^((RatioStrong-IonSummaryDS(IonNumber(z,1),5,z))/IonSummaryDS(IonNumber(z,1),4,z));
                                    if abs(tR-tR0)<TimeDifferTor*4
                                        solutionCount=solutionCount+1;
                                        solutionSet(solutionCount,1)=tR;
                                        solutionSet(solutionCount,3)=abs(tR-tR0);
                                        solutionSet(solutionCount,2)=RatioStrong;
                                    end
                                end
                                for o=1:solutionCount
                                    if solutionSet(o,3)==min(solutionSet(:,3))
                                        IonSummaryDS(IonNumber(z,1),3,z)=solutionSet(o,1);
                                    end
                                end
                                clear solutionSet
                            end
                            clear ConTemp ConTempShort IonTemp
                        end
                    end
                    clear IonNumber
                    
                    
                    nIonSummaryTS=0;
                    for z=1:nIonSummaryShort
                        if IonSummaryDS(1,1,z)>0
                            IonSummaryTemp(1,:,z)=IonSummaryDS(1,:,z);
                            ITST=1;
                            for u=2:size(IonSummaryDS,1)
                                Rep=0;
                                for v=1:ITST
                                    if abs(IonSummaryDS(u,7,z)-IonSummaryTemp(v,7,z))<=MassDifferTor
                                        Rep=1;
                                        if IonSummaryDS(u,8,z)>IonSummaryTemp(v,8,z)
                                            IonSummaryTemp(v,:,z)=IonSummaryDS(u,:,z);
                                        end
                                    end
                                end
                                if Rep==0
                                    ITST=ITST+1;
                                    IonSummaryTemp(ITST,:,z)=IonSummaryDS(u,:,z);
                                end
                            end
                            nIonSummaryTS=nIonSummaryTS+1;
                            IonSummaryTS(1:ITST,:,nIonSummaryTS)=IonSummaryTemp(1:ITST,:,z);
                            clear IonSummaryTemp
                        end
                    end
                    
                    if nIonSummaryTS>0
                        nIonSummarySS=0;
                        for z=1:nIonSummaryTS
                            for u=1:size(IonSummaryTS,1)
                                if IonSummaryTS(u,1,z)>0
                                    nIonSummarySS=nIonSummarySS+1;
                                    IonSummarySS(nIonSummarySS,1:6)=IonSummaryTS(u,3:8,z);
                                end
                            end
                        end
                        IonSummaryS3=unique(IonSummarySS,'rows');
                        nIons=size(IonSummaryS3,1);
                        
                    end
                end
            end
            
            
            if nIons>0
                IonSummaryS3(:,7)=0;
                for ConID=1:ConNo
                    
                    for iFile=1:nOfFiles
                        if (strcmp(files(iFile).name(1:4),'DENO'))
                            MaSuDN(1,1)=0;
                            if SamID<10 && ConID<10
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                        && strcmp(files(iFile).name(13),'P')
                                    MaSuDN(1,1)=1;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID<10
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                        && strcmp(files(iFile).name(14),'P')
                                    MaSuDN(1,1)=2;
                                end
                            end
                            if SamID>=100 && ConID<10
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                        && strcmp(files(iFile).name(15),'P')
                                    MaSuDN(1,1)=3;
                                end
                            end
                            if SamID<10 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                        && strcmp(files(iFile).name(14),'P')
                                    MaSuDN(1,1)=4;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                        && strcmp(files(iFile).name(15),'P')
                                    MaSuDN(1,1)=5;
                                end
                            end
                            if SamID>=100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                        && strcmp(files(iFile).name(16),'P')
                                    MaSuDN(1,1)=6;
                                end
                            end
                            if SamID<10 && ConID>=100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                        && strcmp(files(iFile).name(15),'P')
                                    MaSuDN(1,1)=7;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                        && strcmp(files(iFile).name(16),'P')
                                    MaSuDN(1,1)=8;
                                end
                            end
                            if SamID>=100 && ConID>=100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                        && strcmp(files(iFile).name(17),'P')
                                    MaSuDN(1,1)=9;
                                end
                            end
                            
                            if MaSuDN(1,1)>0
                                IntSumTemp=load(files(iFile).name);
                                for r=1:nIons
                                    if IonSummaryS3(r,7)==0
                                        DiF=IonSummaryS3(r,5);
                                        TiF=IonSummaryS3(r,1);
                                        for z=1:size(IntSumTemp,1)
                                            if abs(IntSumTemp(z,1)-IonSummaryS3(r,5))<DiF
                                                
                                                conditionNo=ConID;
                                                load Mobile_Phase.txt
                                                MB=Mobile_Phase;
                                                MBLength=size(MB,1);
                                                tR_Assume=0.1:0.1:100;
                                                tR_Assume=tR_Assume';
                                                
                                                
                                                solutionCount=0;
                                                for o=1:size(tR_Assume,1)
                                                    tR=tR_Assume(o,1);
                                                    for u=2:MBLength
                                                        if tR>MB(u-1,1) && tR<MB(u,1)
                                                            RatioH2O=(tR-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                                            u0=u;
                                                            volH2O=0;
                                                            for u1=1:u0-1
                                                                volH2O=volH2O+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                                            end
                                                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-tR);
                                                            volH2O=volH2O/100;
                                                            volMeOH(1,conditionNo)=tR-volH2O;
                                                            RatioStrong=log10(volH2O/tR);
                                                        end
                                                    end
                                                    
                                                    tR0=10^((RatioStrong-IonSummaryS3(r,3))/IonSummaryS3(r,2));
                                                    if abs(tR-tR0)<TimeDifferTor*4
                                                        solutionCount=solutionCount+1;
                                                        solutionSet(solutionCount,1)=tR;
                                                        solutionSet(solutionCount,3)=abs(tR-tR0);
                                                        solutionSet(solutionCount,2)=RatioStrong;
                                                    end
                                                end
                                                for o=1:solutionCount
                                                    if solutionSet(o,3)==min(solutionSet(:,3))
                                                        tFound=solutionSet(o,1);
                                                    end
                                                end
                                                clear solutionSet
                                                
                                                
                                                if abs(IntSumTemp(z,2)-tFound)<4*TimeDifferTor
                                                    DiF=abs(IntSumTemp(z,1)-IonSummaryS3(r,5));
                                                    IonSummaryS3(r,7)=IntSumTemp(z,12);
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                
                nIntSum=1;
                IntSummary(nIntSum,1:4)=IonSummaryS3(1,1:4);
                IntSummary(nIntSum,5)=IonSummaryS3(1,6);
                IntSummary(nIntSum,6)=1;
                for z=2:size(IonSummaryS3,1)
                    if IonSummaryS3(z,1:4)==IntSummary(nIntSum,1:4)
                        if IntSummary(nIntSum,5)<IonSummaryS3(z,6)
                            IntSummary(nIntSum,5)=IonSummaryS3(z,6);
                        end
                        IntSummary(nIntSum,6)=IntSummary(nIntSum,6)+1;
                    else
                        nIntSum=nIntSum+1;
                        IntSummary(nIntSum,1:4)=IonSummaryS3(z,1:4);
                        IntSummary(nIntSum,5)=IonSummaryS3(z,6);
                        IntSummary(nIntSum,6)=1;
                    end
                end
                
                
                NonOne=0;
                for z=1:nIntSum
                    if IntSummary(z,6)>1 && NonOne==0
                        nIntSumShort=1;
                        IntSummaryShort(nIntSumShort,:)=IntSummary(z,:);
                        z1=z;
                        NonOne=1;
                    end
                end
                
                for z=z1:nIntSum
                    if abs(IntSummaryShort(nIntSumShort,2)-IntSummary(z,2))<SDT ...
                            && abs(IntSummaryShort(nIntSumShort,3)-IntSummary(z,3))<IDT
                        if IntSummaryShort(nIntSumShort,5)<IntSummary(z,5)
                            IntSummaryShort(nIntSumShort,1:5)=IntSummary(z,1:5);
                        end
                        IntSummaryShort(nIntSumShort,6)=IntSummary(z,6)+IntSummaryShort(nIntSumShort,6);
                    else if IntSummary(z,6)>1
                            nIntSumShort=nIntSumShort+1;
                            IntSummaryShort(nIntSumShort,:)=IntSummary(z,:);
                        end
                    end
                end
                
                nIsoSummary=0;
                for z=1:nIntSumShort
                    nIsoTemp=0;
                    for u=1:size(IonSummaryS3,1)
                        if abs(IonSummaryS3(u,2)-IntSummaryShort(z,2))<SDT ...
                                && abs(IonSummaryS3(u,3)-IntSummaryShort(z,3))<IDT
                            nIsoTemp=nIsoTemp+1;
                            IsoTemp(nIsoTemp,:)=IonSummaryS3(u,:);
                        end
                    end
                    nIsoSummary=nIsoSummary+1;
                    IsoSummary(nIsoSummary,1:3)=IntSummaryShort(z,2:4);
                    IsoSummary(nIsoSummary,4)=IntSummaryShort(z,1);
                    IsoSummary(nIsoSummary,5)=IntSummaryShort(z,5);
                    IsoTemp=sortrows(IsoTemp,-6);
                    IsoSummary(nIsoSummary,6)=IsoTemp(1,7);
                    nCount=1;
                    nCountRem=0;
                    IsoSummary(nIsoSummary,6+nCount)=IsoTemp(1,5);
                    for p=2:nIsoTemp
                        if abs(IsoSummary(nIsoSummary,6)-IsoTemp(p,7))<0.2
                            nCount=nCount+1;
                            IsoSummary(nIsoSummary,6+nCount)=IsoTemp(p,5);
                        else
                            nCountRem=nCountRem+1;
                            IsoTempRem(nCountRem,:)=IsoTemp(p,:);
                        end
                    end
                    if nCountRem>0
                        nIsoSummary=nIsoSummary+1;
                        IsoSummary(nIsoSummary,6)=mean(IsoTempRem(:,7));
                        for q=1:nCountRem
                            IsoSummary(nIsoSummary,6+q)=IsoTempRem(q,5);
                        end
                    end
                    clear IsoTemp IsoTempRem
                    
                    
                end
                str= sprintf('%s/%s%s%s%s',new_folder,'IDCS','Sam',num2str(SamID),'P.txt');
                fid=fopen(str,'w');
                for u=1:nIsoSummary
                    fprintf(fid,'%.4f ',IsoSummary(u,1));
                    fprintf(fid,'%.4f ',IsoSummary(u,2));
                    if IsoSummary(u,3)<ML && IsoSummary(u,2)~=0
                        IsoSummary(u,3)=ML;
                    end
                    fprintf(fid,'%.4f ',IsoSummary(u,3));
                    fprintf(fid,'%d ',IsoSummary(u,4));
                    fprintf(fid,'%.3f ',IsoSummary(u,5));
                    fprintf(fid,'%.3f ',IsoSummary(u,6));
                    
                    for v=7:size(IsoSummary,2)
                        fprintf(fid,'%.1f ',IsoSummary(u,v));
                    end
                    fprintf(fid,'\n');
                end
                fclose(fid);
                clear IsoSummary
            end
        end
        clearvars -except AddedLength ConNo GroupDifferRatioControl IMI IDT ITV...
            MB MBLength MA MassDifferTor Mats MIR ML MR IMI ...
            SamID SamNoEn SamNoSt SDT TimeDifferTor TimeVariance files iFile nOfFiles nOfMats ...
            new_folder t00
        t01=cputime-t00;
        disp(['Step4 = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    end
    t01=cputime-t00;
    disp(['Step4 = ',num2str(t01), ' seconds ']);
    
end




