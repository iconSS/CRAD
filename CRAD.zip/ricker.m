
function [rick]=ricker(nt, fr, dt, timeshift)
np = floor(timeshift/(fr*dt) + 0.5)*2 + 1;
tshift = timeshift/fr;
pi2 = sqrt(pi)/2.0;
b   = sqrt(6.0)/(pi*fr);
const = 2.0*sqrt(6.0)/b;

smax = 0.0;
rick = zeros([nt 1]);

for it=1:np
    tim1 = real(it-1)*dt;
    tim2 = tim1 - tshift;
    u = const*tim2;
    amp = ((u*u)/4.0-0.5)*pi2*(exp(-u*u/4.0));
    rick(it) = -amp;
    if (smax < abs(amp))
        smax = abs(amp);
    end;
end;
rick = rick/max(abs(rick(:)));
return;
