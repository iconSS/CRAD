%Make Ricker using shifted wavelet(pi: e.g. half a wavelength) in time domain 
function [rick]=ricker(nt, fr, dt, timeshift)
%Make Ricker using shifted wavelet(pi: e.g. half a wavelength) in time domain 

% npt   = np*dt;
% t     = (-npt/2):dt:npt/2;
% rick1 = ( 1-t .*t * fr^2 *pi^2  ) .*exp(- t.^2 * pi^2 * fr^2 ) ;
% rick  = rick1(round(np/2)-round(1/fr/dt)-ntshift+1 : np);
% l     = length(rick);
% 
% rick = [rick zeros([1 np-l])];
% % disp('length rick = '); disp(size(rick));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
np = floor(timeshift/(fr*dt) + 0.5)*2 + 1;
tshift = timeshift/fr;
pi2 = sqrt(pi)/2.0;
b   = sqrt(6.0)/(pi*fr);
const = 2.0*sqrt(6.0)/b;

smax = 0.0;
rick = zeros([nt 1]);

for it=1:np
    tim1 = real(it-1)*dt;
    tim2 = tim1 - tshift;
    u = const*tim2;
    amp = ((u*u)/4.0-0.5)*pi2*(exp(-u*u/4.0));
    rick(it) = -amp;
    if (smax < abs(amp))
        smax = abs(amp);
    end;
end;
rick = rick/max(abs(rick(:)));


% figure; 
% plot([0:length(rick)-1]*dt,rick); 
% xlabel('Time (s)','Color','k','FontSize',14, 'fontn', 'Times');
% ylabel('Amplitude','Color','k','FontSize',14, 'fontn', 'Times');
% title([num2str(fr),' Hz Ricker Wavelet'], 'Color', 'k', ...
%          'FontSize', 14, 'fontn', 'Times');

% set( gca, 'xtick', [floor(np/4) floor(np/2) floor(np*3/4) floor(np)] ); 
% set( gca, 'xticklabel', dt*[floor(np/4) floor(np/2) floor(np*3/4) floor(np)], ... 
%      'XColor', 'k', 'FontSize', 10, 'fontn', 'Times','linewidth', 1.5 ); 
% set(gca, 'ytick', []); 
% set(gca, 'yticklabel', 0.001*[200 400 600 800],'YColor','k', 'fontn', 'Times'); 

return;
