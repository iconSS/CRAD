%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CRAD: for peak picking and denoising before the origin, application, or composition of a sample are known
%%% Copyright (C) <2016>  Wang Renqi
%%% This program is free software: you can redistribute it and/or modify
%%% it under the terms of the GNU General Public License as published by
%%% the Free Software FDMXation, either version 3 of the License, or
%%% any later version.


%%% This program is distributed in the hope that it will be useful,
%%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%%% GNU General Public License for more details.

%%% For details of the GNU General Public License, please see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SamNoSt = 1; %Sample number Start spot
SamNoEn = 2;%Sample number End spot
ConNo = 5;  %Total CoLD No
MassResolution=0.05; %Resolution of MS analysis data
t0=2.5; %dead time of the HPLC column


PXSet =10;
RelArea = 0.2;
IntensityThreshold_Positive = 1.25*10^4;
IntensityThreshold_Negative = 1.25*10^2;

for CRAD=1:1
    IRT = 0.01;
    TimeDIFFTor = 0.5;
    MassDIFFTor = 0.5;
    t00=cputime;
    IMI = MassDIFFTor*MassResolution/5.5;
    MassRange=round(MassDIFFTor/MassResolution)-1;
    files = dir(fullfile('.', '*.txt'));
    [nOfFiles,~] = size(files);
    Mats = dir(fullfile('.', '*.mat'));
    [nOfMats,~]=size(Mats);
    for SamID=SamNoSt:SamNoEn
        for ConID=1:ConNo
            IMI = IMI*2;
            MassRange=round(MassDIFFTor/MassResolution/2)-1;
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:3),'Sam'))
                    MaSuUV(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                                && strcmp(files(iFile).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                                && strcmp(files(iFile).name(13),'.')
                            MaSuUV(1,1)=9;
                        end
                    end
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iFile).name);
                        UVTempLS=size(UVTemp,1);
                        TIRA =UVTemp(UVTempLS,1);
                        
                        UVSPOR = load(files(iFile).name);
                        UVLS  = size(UVSPOR,1);
                        UVSP(1:UVLS, 1:2) = UVSPOR(1:UVLS, 1:2);
                        HighPoint = max(UVSP(:,2));
                        LowPoint  = min(UVSP(:,2));
                        SETINo = 100;
                        Incre     = (HighPoint-LowPoint)/SETINo;
                        SETI   = zeros(SETINo,3);
                        
                        for i=1:SETINo
                            SETI(i,1) = Incre*(i-1)+LowPoint;
                            SETI(i,2) = Incre*i+LowPoint;
                            SETI(i,3) = 0;
                        end;
                        
                        for j=1:UVLS
                            for u=1:SETINo
                                if (UVSP(j,2)>=SETI(u,1) && ...
                                        UVSP(j,2)<SETI(u,2) )
                                    SETI(u,3)=SETI(u,3)+1;
                                end;
                            end;
                        end;
                        chooseSETI=max(SETI(:,3));
                        
                        for i=1:SETINo
                            if SETI(i,3)==chooseSETI
                                BASLL=SETI(i,1);
                                BASLH=SETI(i,2);
                            end;
                        end;
                        
                        BASLV=0;
                        count=0;
                        
                        for i=1:UVLS
                            if (UVSP(i,2)>=BASLL && ...
                                    UVSP(i,2)<BASLH)
                                BASLV=BASLV+UVSP(i,2);
                                count=count+1;
                            end;
                        end;
                        BASLV=BASLV/count;
                        
                        UVSP(:,2) = UVSP(:,2)-BASLV;
                    end;
                    
                    if MaSuUV(1,1)>0
                        MMPN=PXSet;
                        MPTS=RelArea;
                        for iMat=1:nOfMats
                            if strcmp( Mats(iMat).name(1:3),'Sam')
                                nPISGS=0;
                                
                                MaSuMa(1,1)=0;
                                if SamID<10 && ConID<10
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                            && (strcmp(Mats(iMat).name(9),'N') || strcmp(Mats(iMat).name(9),'P'))...
                                            && strcmp(Mats(iMat).name(10),'.')
                                        MaSuMa(1,1)=1;
                                        if strcmp(Mats(iMat).name(9),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID<10
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'N') || strcmp(Mats(iMat).name(10),'P'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=2;
                                        if strcmp(Mats(iMat).name(10),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID>=100 && ConID<10
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=3;
                                        if strcmp(Mats(iMat).name(11),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID<10 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'N') || strcmp(Mats(iMat).name(10),'P'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=4;
                                        if strcmp(Mats(iMat).name(10),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=5;
                                        if strcmp(Mats(iMat).name(11),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID>=100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'N') || strcmp(Mats(iMat).name(12),'P'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=6;
                                        if strcmp(Mats(iMat).name(12),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID<10 && ConID>=100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=7;
                                        if strcmp(Mats(iMat).name(11),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'N') || strcmp(Mats(iMat).name(12),'P'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=8;
                                        if strcmp(Mats(iMat).name(12),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if SamID>=100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                            && (strcmp(Mats(iMat).name(13),'N') || strcmp(Mats(iMat).name(13),'P'))...
                                            && strcmp(Mats(iMat).name(14),'.')
                                        MaSuMa(1,1)=9;
                                        if strcmp(Mats(iMat).name(13),'N')
                                            ionMode=1;
                                        else
                                            ionMode=2;
                                        end
                                    end
                                end
                                if MaSuMa(1,1)>0
                                    data = load(Mats(iMat).name);
                                    Scans=data.Scans;
                                    SDWI=size(Scans,2);
                                    MergeMass=data.Masses;
                                    dataLength=size(MergeMass,1);
                                    MergeData=data.Data;
                                    FDTH=round(TIRA*2.5*log10(SDWI));
                                    AWTH=SDWI;
                                    TIOR=round(AWTH/FDTH);
                                    if TIOR>=1
                                        iCol=0;
                                        for k=1:TIOR:AWTH-TIOR
                                            iCol=iCol+1;
                                            dataTemp(1:dataLength,1:TIOR)=MergeData(1:dataLength,k:k+TIOR-1);
                                            for o=1:dataLength
                                                DANW(o,iCol)=sum(dataTemp(o,1:TIOR));
                                            end
                                            METI(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+TIOR-1))/Scans(1,SDWI)*TIRA;
                                        end
                                    else
                                        TIOR2=round(FDTH/AWTH);
                                        iCol=TIOR2*AWTH;
                                        for o=1:SDWI
                                            METI(1,o*TIOR2-TIOR2+1:o*TIOR2)=Scans(1,o)/Scans(1,SDWI)*TIRA;
                                            for k=1:dataLength
                                                DANW(k,o*TIOR2-TIOR2+1:o*TIOR2)=MergeData(k,o);
                                            end
                                        end
                                    end
                                    SDWI=iCol;
                                    
                                    XIC=zeros(SDWI,2);
                                    nPISGS=0;
                                    
                                    fr = FDTH/16;
                                    dt = (16/FDTH)^2;
                                    rick = ricker(FDTH,fr,dt,20);
                                    rick_smooth = getSmoothRicker(rick);
                                    
                                    for h=MassRange+1:dataLength-MassRange
                                        for j=1:SDWI
                                            XIC(j,1)=METI(1,j);
                                            XIC(j,2)=sum(DANW(h-MassRange:h+MassRange,j));
                                        end
                                        SXIC0  = conv( rick_smooth(:,1),XIC(:,2) );
                                        SXIC(:,1)=XIC(:,1);
                                        SXIC(:,2)=SXIC0( round(length(rick_smooth)/2)+1:length(XIC(:,2))+round(length(rick_smooth)/2));
                                        SXICLength=size(SXIC,1);
                                        
                                        PTSD=0.01;
                                        PPGSN=0;
                                        HighPoint=max(SXIC(:,2));
                                        for i=2:SXICLength-1
                                            if SXIC(i,2)>=SXIC(i-1,2) && SXIC(i,2)>=SXIC(i+1,2) && SXIC(i,2)> HighPoint*PTSD && (SXIC(i,2)-SXIC(i-1,2))+(SXIC(i,2)-SXIC(i+1,2))~=0
                                                PPGSN=PPGSN+1;
                                                PPGS(PPGSN,1) = SXIC(i,1);
                                                PPGS(PPGSN,2) = SXIC(i,2);
                                            end;
                                        end;
                                        
                                        BASLT=0.01;
                                        NPIR=0;
                                        
                                        if PPGSN>0
                                            for m=1:PPGSN
                                                PTI=PPGS(m,1);
                                                PHT=PPGS(m,2);
                                                PPSN(1,1)=PPGS(m,1);
                                                PPSN(1,2)=PPGS(m,2);
                                                halfPH=PHT/2;
                                                
                                                for z=1:SXICLength
                                                    if SXIC(z,1)==PTI
                                                        PP=z;
                                                    end;
                                                end;
                                                
                                                vbv1=0;
                                                for z=PP:-1:2
                                                    if SXIC(z,2)>=0 && SXIC(z-1,2)<=0 && vbv1==0
                                                        CZTL=SXIC(z,1);
                                                        LeftID=z;
                                                        vbv1=1;
                                                    end;
                                                end;
                                                
                                                if vbv1==0
                                                    CZTL=0;
                                                    LeftID=1;
                                                end;
                                                
                                                vbv2=0;
                                                for z=PP:SXICLength-1
                                                    if SXIC(z,2)>=0 && SXIC(z+1,2)<=0 && vbv2==0
                                                        CZTR=SXIC(z,1);
                                                        RightID=z;
                                                        vbv2=1;
                                                    end;
                                                end;
                                                
                                                if vbv2==0
                                                    CZTR=SXIC(SXICLength,1);
                                                    RightID=SXICLength;
                                                end;
                                                
                                                PPGS(m,3)=CZTL;
                                                PPGS(m,4)=CZTR;
                                                PPGS(m,5)=(CZTR-CZTL)/TIRA;
                                                PPGS(m,6)=PHT/HighPoint;
                                                PPGS(m,7)=PPGS(m,6)/PPGS(m,5);
                                                
                                                
                                                if LeftID>1 && RightID<SXICLength
                                                    PPGS(m,8)=0;
                                                    for z=LeftID:RightID
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                if LeftID==1 && RightID<SXICLength
                                                    PPGS(m,8)=(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                    for z=2:RightID
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                if LeftID>1 && RightID==SXICLength
                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                    for z=LeftID:RightID-1
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                
                                                if LeftID==1 && RightID==SXICLength
                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                    PPGS(m,8)=PPGS(m,8)+(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                    for z=2:SXICLength-1
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                            end;
                                            
                                            PPGSST(1,:)=PPGS(1,:);
                                            nPPShort=1;
                                            for z=1:PPGSN
                                                if PPGS(z,1)-PPGSST(nPPShort,1)<TimeDIFFTor
                                                    if PPGS(z,2)>PPGSST(nPPShort,2)
                                                        PPGSST(nPPShort,1)=PPGS(z,1);
                                                        PPGSST(nPPShort,2)=PPGS(z,2);
                                                    end;
                                                    if PPGS(z,3)>PPGSST(nPPShort,3)
                                                        PPGSST(nPPShort,3)=PPGS(z,3);
                                                    end;
                                                    if PPGS(z,4)<PPGSST(nPPShort,4)
                                                        PPGSST(nPPShort,4)=PPGS(z,4);
                                                    end;
                                                    PPGSST(nPPShort,5)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))/TIRA;
                                                    PPGSST(nPPShort,6)=PPGSST(nPPShort,2)/HighPoint;
                                                    PPGSST(nPPShort,7)=PPGSST(nPPShort,6)/PPGSST(nPPShort,5);
                                                    PPGSST(nPPShort,8)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))*PPGSST(nPPShort,2)/2;
                                                else
                                                    nPPShort=nPPShort+1;
                                                    PPGSST(nPPShort,:)=PPGS(z,:);
                                                end;
                                            end;
                                            
                                            LargestPeak=max(PPGSST(:,8));
                                            
                                            PPGSST(:,9)=PPGSST(:,8)/LargestPeak;
                                            
                                            if nPPShort>0
                                                PPGSST=sortrows(PPGSST,-9);
                                                CNMR=0;
                                                for z=1:nPPShort
                                                    if (PPGSST(z,9)>MPTS &&...
                                                            PPGSST(z,1)>t0)
                                                        CNMR=CNMR+1;
                                                    end;
                                                end;
                                                if CNMR<=MMPN
                                                    for z=1:nPPShort
                                                        if (PPGSST(z,9)>MPTS && ...
                                                                PPGSST(z,7)>MPTS/PPGSST(z,5) && ...
                                                                PPGSST(z,1)>t0 && PPGSST(z,4)<TIRA-1)
                                                            nPISGS=nPISGS+1;
                                                            PISGS(nPISGS,1)=MergeMass(h,1);
                                                            PISGS(nPISGS,2:10)=PPGSST(z,1:9);
                                                        end;
                                                    end;
                                                end
                                            end;
                                            clear PPGS PPGSST ...
                                                width PPSN;
                                        end;
                                        clear XIC SXIC SETI;
                                    end;
                                    t01=cputime-t00;
                                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                                        'Con',num2str(ConID),'hold on...']);
                                end
                                
                                
                                
                                
                                if nPISGS>0
                                    if ionMode==1
                                        IntensityThreshold=IntensityThreshold_Negative;
                                    else
                                        IntensityThreshold=IntensityThreshold_Positive;
                                    end
                                    
                                    PIG=PISGS(:,1);
                                    PIGS=unique(PIG,'rows');
                                    
                                    PISGSLength = size(PISGS,1);
                                    PeakAreaMax=max(PISGS(:,9));
                                    PISGSTemp=zeros(PISGSLength,11);
                                    PISGSTemp(1:PISGSLength,1:10) = PISGS(1:PISGSLength,1:10);
                                    PISGSTemp(1:PISGSLength,11)   = PISGSTemp(1:PISGSLength,9)/PeakAreaMax;
                                    
                                    
                                    t01=cputime-t00;
                                    disp(['squezzing time1 = ',num2str(t01), ' seconds' ]);
                                    
                                    PISGS2=zeros(PISGSLength,13);
                                    nPISGS2=0;
                                    for i=1:PISGSLength
                                        if PISGSTemp(i,9)>IntensityThreshold
                                            for j=1:PISGSLength
                                                hit=0;
                                                hot=0;
                                                if PISGSTemp(j,9)>IntensityThreshold
                                                    if PISGSTemp(i,1)-(PISGSTemp(j,1))<-1/3+IMI &&...
                                                            PISGSTemp(i,1)-(PISGSTemp(j,1))>=-1-IMI && ...
                                                            abs(PISGSTemp(i,2)-(PISGSTemp(j,2)))<TimeDIFFTor &&...
                                                            PISGSTemp(j,11)/PISGSTemp(i,11)<1 && ...
                                                            PISGSTemp(j,11)/PISGSTemp(i,11)>=IRT
                                                        IsotopeTIOR=PISGSTemp(j,11)/PISGSTemp(i,11);
                                                        hit=1;
                                                        hot=1;
                                                    end
                                                    if PISGSTemp(j,1)-(PISGSTemp(i,1))<-1/3+IMI &&...
                                                            PISGSTemp(j,1)-(PISGSTemp(i,1))>=-1-IMI && ...
                                                            abs(PISGSTemp(i,2)-(PISGSTemp(j,2)))<TimeDIFFTor &&...
                                                            PISGSTemp(i,11)/PISGSTemp(j,11)<1 && ...
                                                            PISGSTemp(i,11)/PISGSTemp(j,11)>=IRT
                                                        IsotopeTIOR=PISGSTemp(i,11)/PISGSTemp(j,11);
                                                        hit=1;
                                                    end
                                                end
                                                if hit==1
                                                    nPISGS2=nPISGS2+1;
                                                    PISGS2(nPISGS2,1:11)=PISGSTemp(i,1:11);
                                                    if hot==1
                                                        PISGS2(nPISGS2,12)=IsotopeTIOR;
                                                    else
                                                        PISGS2(nPISGS2,13)=IsotopeTIOR;
                                                    end
                                                end
                                            end
                                        end
                                    end
                                    
                                    PISGS2T=PISGS2(1:nPISGS2,1:13);
                                    clear PISGS2
                                    PISGS2=PISGS2T;
                                    clear PISGS2T
                                    
                                    
                                    if size(PISGS2,1)>0
                                        t02=cputime-t00;
                                        disp(['squezzing time2 = ',num2str(t02), ' seconds' ]);
                                        
                                        nPISGS3=0;
                                        for i=1:nPISGS2
                                            if PISGS2(i,12)>0
                                                nPISGS3=nPISGS3+1;
                                                PISGS3(nPISGS3,1:12)=PISGS2(i,1:12);
                                            end
                                        end
                                        
                                        if nPISGS3>0
                                            for i=1:nPISGS3
                                                Temp=PISGS3(i,:);
                                                for j=1:nPISGS3
                                                    if abs(PISGS3(i,1)-PISGS3(j,1))<1 && ...
                                                            abs(PISGS3(i,2)-PISGS3(j,2))<0.1 && ...
                                                            PISGS3(j,11)>=Temp(1,11)
                                                        Temp=PISGS3(j,:);
                                                    end
                                                end
                                                PISGS4(i,:)=Temp;
                                                clear Temp
                                            end
                                            
                                            
                                            t03=cputime-t00;
                                            disp(['squezzing time3 = ',num2str(t03), ' seconds' ]);
                                            
                                            if size(PISGS4,1)>0
                                                PISGS5=unique(PISGS4,'rows');
                                                nPISGS5=size(PISGS5,1);
                                                
                                                PIG5=PISGS5(:,1);
                                                PIG5S=unique(PIG5,'rows');
                                                
                                                clear PISGSTemp;
                                                
                                                t04=cputime-t00;
                                                disp(['squezzing time4 = ',num2str(t04), ' seconds' ]);
                                                MPTS=round(MPTS*1000)/1000;
                                                dataOutputShort=PISGS5(1:nPISGS5, 1:12);
                                                [~, outputFile0] = fileparts( Mats(iMat).name );
                                                outputFilename = strcat( 'DENO',outputFile0,'.txt' );
                                                save(outputFilename,'dataOutputShort','-ascii');
                                                clearvars -except IntensityThreshold_Positive IntensityThreshold_Negative ionMode PXSet RelArea...
                                                    MassRange MassResolution ConID ConNo IMI IRT IntensityThreshold MPTS INTDIFF...
                                                    MassDIFFTor Mats MMPN PXSet RelArea SamID SamNoEn SamNoSt TimeDIFFTor ...
                                                    dt files fr iFile iMat nOfFiles nOfMats DPT DeadTime TIRA rick rick_smooth t0 t00
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                clearvars -except IntensityThreshold_Positive IntensityThreshold_Negative ionMode ...
                    PXSet RelArea MassRange MassResolution ConID ConNo IMI IRT IntensityThreshold ...
                    MassDIFFTor Mats PXSet RelArea SamID SamNoEn SamNoSt ...
                    TimeDIFFTor files iFile nOfFiles nOfMats INTDIFF t0 t00
            end
        end
        t01=cputime-t00;
        disp(['hold on... calculation time',num2str(t01), ' seconds ', 'Sam', num2str(SamID),'Con',num2str(ConID)]);
    end
    t01=cputime-t00;
    disp(['hold on... calculation time',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    IMI = MassDIFFTor*MassResolution/5.5;
    MassRange=round(MassDIFFTor/MassResolution)-1;
    INTDIFF=0.05;
    TimeShortLong=t0*2;
end

MiMLinearity=0.8;

for CRAD=1:1
    MIMAssocIons=2;
    load Mobile_Phase.txt
    MB=Mobile_Phase;
    MBLength=size(MB,1);
    files = dir(fullfile('.', '*.txt'));
    [nOfFiles,~] = size(files);
    for SamID=SamNoSt:SamNoEn
        LTRF=0;
        LTRFMiR=0;
        for ConID=1:ConNo
            for iFile=1:nOfFiles
                if (strcmp( files(iFile).name(1:4),'DENO'))
                    MaSuDN(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'N')
                            MaSuDN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuDN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuDN(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuDN(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuDN(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'N')
                            MaSuDN(1,1)=9;
                        end
                    end
                    if MaSuDN(1,1)>0
                        dataTemp=load(files(iFile).name);
                        LengthTemp=size(dataTemp,1);
                        DTSM(1:LengthTemp,1,ConID)=dataTemp(1:LengthTemp,1);
                        DTSM(1:LengthTemp,2,ConID)=dataTemp(1:LengthTemp,2);
                        DTSM(1:LengthTemp,3,ConID)=dataTemp(1:LengthTemp,7);
                        DTSM(1:LengthTemp,4,ConID)=dataTemp(1:LengthTemp,12);
                        LTSM(ConID,1)=ConID;
                        LTSM(ConID,2)=LengthTemp;
                        Ref(LTRF+1:LTRF+LengthTemp,1:4)=DTSM(1:LengthTemp,1:4,ConID);
                        LTRF=LTRF+LengthTemp;
                        
                        clear dataTemp;
                    end
                end
            end
        end
        t01=cputime-t00;
        disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
            'Con',num2str(ConID),'hold on ...']);
        
        if LTRF>0
            Ref=sortrows(Ref,1);
            nMultiply=0;
            for i=1:LTRF
                nFDMX=0;
                for w=1:size(LTSM,1)
                    for z=1:LTSM(w,2)
                        if abs(DTSM(z,1,w)-Ref(i,1))<MassDIFFTor &&...
                                abs(DTSM(z,4,w)-Ref(i,4))<1 &&...
                                abs(DTSM(z,3,w)-Ref(i,3))<INTDIFF
                            
                            nFDMX=nFDMX+1;
                            FDMX(nFDMX,1:4)=DTSM(z,1:4,w);
                            FDMX(nFDMX,5)=w;
                        end
                    end
                end
                if max(FDMX(1:nFDMX,2))>TimeShortLong
                    MiMRep=3;
                    TimeDIFF=TimeDIFFTor;
                else
                    MiMRep=3;
                    TimeDIFF=TimeDIFFTor/2;
                end
                
                if nFDMX>=MiMRep
                    nTMGMT=0;
                    for z=1:nFDMX
                        nSet=1;
                        SetU(nSet,:)=FDMX(z,:);
                        for z1=1:nFDMX
                            vot=0;
                            for z2=1:nSet
                                if SetU(z2,5)==FDMX(z1,5)
                                    vot=1;
                                end
                            end
                            if vot==0
                                nSet=nSet+1;
                                SetU(nSet,:)=FDMX(z1,:);
                            end
                        end
                        for z1=1:nSet
                            nTMRMT=1;
                            RefU(nTMRMT,:)=SetU(z1,:);
                            for z2=1:nSet
                                if RefU(nTMRMT,5)<SetU(z2,5) && RefU(nTMRMT,2)-SetU(z2,2)>TimeDIFF
                                    nTMRMT=nTMRMT+1;
                                    RefU(nTMRMT,:)=SetU(z2,:);
                                end
                            end
                            
                            if max(RefU(1:nTMRMT,2))>TimeShortLong
                                MiMRep=3;
                            else
                                MiMRep=3;
                            end
                            
                            if nTMRMT>=MiMRep && max(SetU(:,2))-min(SetU(:,2))>2*TimeDIFF
                                nTMGMT=nTMGMT+1;
                                for z3=1:nTMRMT
                                    TempU(nTMGMT,RefU(z3,5)*4-3:RefU(z3,5)*4)=RefU(z3,1:4);
                                end
                            end
                            clear RefU
                        end
                    end
                    clear SetU
                    if nTMGMT>0
                        nTMRMTS=1;
                        TMGMTWdith=size(TempU,2);
                        TMRMTS(nTMRMTS,:)=TempU(1,:);
                        for v=2:nTMGMT
                            vot=0;
                            vbt=0;
                            for v1=1:nTMRMTS
                                vpt=1;
                                for v2=4:4:TMGMTWdith
                                    if TMRMTS(v1,v2-3)*TempU(v,v2-3)~=0
                                        if TMRMTS(v1,v2-3)==TempU(v,v2-3) && TMRMTS(v1,v2-2)==TempU(v,v2-2) && ...
                                                TMRMTS(v1,v2-1)==TempU(v,v2-1) && TMRMTS(v1,v2)==TempU(v,v2)
                                            vpt=vpt*2;
                                        else
                                            vpt=vpt*0;
                                        end
                                    end
                                end
                                if vpt>1
                                    for v3=4:4:TMGMTWdith
                                        if TMRMTS(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                            vbt=1;
                                        end
                                    end
                                    if vbt==0
                                        for v3=4:4:TMGMTWdith
                                            if TMRMTS(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                                TMRMTS(v1,v3-3:v3)=TempU(v,v3-3:v3);
                                            end
                                        end
                                    end
                                    vot=1;
                                end
                            end
                            if vot==0
                                nTMRMTS=nTMRMTS+1;
                                TMRMTS(nTMRMTS,:)=TempU(v,:);
                            end
                        end
                        TGSWidth=size(TMRMTS,2);
                        clear TempU;
                        
                        for v=1:nTMRMTS
                            Multiply0(nMultiply+v,1:TGSWidth)=TMRMTS(v,1:TGSWidth);
                        end
                        nMultiply=nMultiply+nTMRMTS;
                        clear TMRMTS;
                        
                    end
                end
            end
            t01=cputime-t00;
            disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                'Con',num2str(ConID),'hold on ...']);
            
            if nMultiply>0
                Multiply1=unique(Multiply0,'rows');
                MultiplyLength=size(Multiply1,1);
                MultiplyWidth=size(Multiply1,2);
                nMultiply_Short=0;
                for w=1:MultiplyLength
                    for z=2:4:MultiplyWidth
                        if Multiply1(w,z)>0
                            CoLDNo=(z+2)/4;
                            for u=2:MBLength
                                if Multiply1(w,z)>MB(u-1,1) && Multiply1(w,z)<=MB(u,1)
                                    RatioH2O=(Multiply1(w,z)-MB(u-1,1))*((MB(u,CoLDNo+1)-MB(u-1,CoLDNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,CoLDNo+1);
                                    u0=u;
                                    volH2O(1,CoLDNo)=0;
                                    for u1=1:u0-1
                                        volH2O(1,CoLDNo)=volH2O(1,CoLDNo)+MB(u1+1,CoLDNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,CoLDNo+1)-MB(u1,CoLDNo+1))*(MB(u1+1,1)-MB(u1,1));
                                    end
                                    volH2O(1,CoLDNo)=volH2O(1,CoLDNo)-(MB(u0,1)-Multiply1(w,z))*MB(u0,CoLDNo+1)+(MB(u0,CoLDNo+1)-RatioH2O)*(MB(u0,1)-Multiply1(w,z));
                                    volH2O(1,CoLDNo)=volH2O(1,CoLDNo)/100;
                                    volMeOH(1,CoLDNo)=Multiply1(w,z)-volH2O(1,CoLDNo);
                                    RatioStrong(1,CoLDNo)=log10(volH2O(1,CoLDNo)/Multiply1(w,z));
                                    lnTime(1,CoLDNo)=log10(Multiply1(w,z));
                                end
                            end
                        end
                    end
                    
                    countNo=0;
                    for u=1:CoLDNo
                        if lnTime(1,u)~=0
                            countNo=countNo+1;
                            RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                            lnTime_PSS(1,countNo)=lnTime(1,u);
                        end
                    end
                    
                    vot=0;
                    for z=1:4:MultiplyWidth
                        if Multiply1(w,z)>0 && vot==0
                            pSS(w,1)=Multiply1(w,z);
                            vot=1;
                        end
                    end
                    pSS(w,2:3)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                    
                    for z=1:countNo
                        RatioStrongfit2(1,z)=pSS(w,2)*lnTime_PSS(1,z)+pSS(w,3);
                    end
                    
                    R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                    pSS(w,4)=R2;
                    
                    if R2>MiMLinearity
                        nMultiply_Short=nMultiply_Short+1;
                        p2(nMultiply_Short,:)=pSS(w,:);
                        Multiply(nMultiply_Short,:)=Multiply1(w,:);
                    end
                    
                    clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on ...']);
                if nMultiply_Short>0
                    MultiplyTemp=Multiply;
                    clear Multiply;
                    nMultiply=0;
                    BMM=0.6;
                    for z=1:nMultiply_Short
                        MoM=0;
                        for v=3:4:size(MultiplyTemp,2)
                            if MultiplyTemp(z,v)>=BMM
                                MoM=1;
                            end
                        end
                        if MoM==0
                            nMultiply=nMultiply+1;
                            Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                        else
                            oMo=0;
                            NoMass=0;
                            AveMass=0;
                            for v=1:4:size(MultiplyTemp,2)
                                if MultiplyTemp(z,v)>0
                                    AveMass=AveMass+MultiplyTemp(z,v);
                                    NoMass=NoMass+1;
                                end
                            end
                            AveMass=AveMass/NoMass;
                            
                            for u=1:size(MultiplyTemp,1)
                                if oMo==0
                                    for v=1:4:size(MultiplyTemp,2)
                                        if abs(AveMass-MultiplyTemp(u,v))<MassDIFFTor && MultiplyTemp(u,v+2)==1
                                            oMo=1;
                                        end
                                    end
                                end
                            end
                            
                            if oMo==1
                                nMultiply=nMultiply+1;
                                Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                            end
                        end
                    end
                    nMultiply=size(Multiply,1);
                    CWidth=size(Multiply,2);
                    NGP=1;
                    CoLD=0;
                    for i=2:4:CWidth
                        CoLD=CoLD+1;
                        GRFRS(NGP,CoLD)=Multiply(1,i);
                    end
                    for i=2:nMultiply
                        CoLD=0;
                        for j=2:4:CWidth
                            CoLD=CoLD+1;
                            Temp(1,CoLD)=Multiply(i,j);
                        end
                        Temp2=Temp';
                        if min(Temp2)<2*t0
                            TimeDIFF=TimeDIFFTor/2;
                        else
                            TimeDIFF=TimeDIFFTor;
                        end
                        vot=0;
                        vbt=0;
                        
                        for z=1:NGP
                            vmt=0;
                            vpt=1;
                            for u=1:CoLD
                                if Temp(1,u)*GRFRS(z,u)~=0
                                    if abs(Temp(1,u)-GRFRS(z,u))<TimeDIFF
                                        vpt=vpt*2;
                                    else
                                        vpt=vpt*0;
                                    end
                                end
                                if abs(Temp(1,u)-GRFRS(z,u))>=TimeDIFF
                                    vmt=1;
                                end
                            end
                            if vmt==0
                                vot=1;
                            end
                            if vpt>1 && vmt==1
                                for u=1:CoLD
                                    if Temp(1,u)~=0 && GRFRS(z,u)==0
                                        if (u==1 && Temp(1,u)-GRFRS(z,u+1)>TimeDIFF && GRFRS(z,u+1)~=0)||...
                                                (u==CoLD && GRFRS(z,u-1)-Temp(1,u)>TimeDIFF) ||...
                                                (u<CoLD && u>1 && GRFRS(z,u-1)-Temp(1,u)>TimeDIFF...
                                                && Temp(1,u)-GRFRS(z,u+1)>TimeDIFF && GRFRS(z,u+1)~=0)
                                            GRFRS(z,u)=Temp(1,u);
                                            vot=1;
                                        end
                                    end
                                end
                            end
                        end
                        if vot==0
                            NGP=NGP+1;
                            CoLD=0;
                            for v=2:4:CWidth
                                CoLD=CoLD+1;
                                GRFRS(NGP,CoLD)=Multiply(i,v);
                            end
                        end
                        clear Temp Temp2
                    end
                    GRFRS_Short=unique(GRFRS,'rows');
                    clear GRFRS
                    GRFRS=GRFRS_Short;
                    NGP=size(GRFRS,1);
                    
                    for w=1:NGP
                        for z=1:size(GRFRS,2)
                            if GRFRS(w,z)>0
                                CoLDNo=z;
                                for u=2:MBLength
                                    if GRFRS(w,z)>MB(u-1,1) && GRFRS(w,z)<=MB(u,1)
                                        RatioH2O=(GRFRS(w,z)-MB(u-1,1))*((MB(u,CoLDNo+1)-MB(u-1,CoLDNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,CoLDNo+1);
                                        u0=u;
                                        volH2O(1,CoLDNo)=0;
                                        for u1=1:u0-1
                                            volH2O(1,CoLDNo)=volH2O(1,CoLDNo)+MB(u1+1,CoLDNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,CoLDNo+1)-MB(u1,CoLDNo+1))*(MB(u1+1,1)-MB(u1,1));
                                        end
                                        volH2O(1,CoLDNo)=volH2O(1,CoLDNo)-(MB(u0,1)-GRFRS(w,z))*MB(u0,CoLDNo+1)+(MB(u0,CoLDNo+1)-RatioH2O)*(MB(u0,1)-GRFRS(w,z));
                                        volH2O(1,CoLDNo)=volH2O(1,CoLDNo)/100;
                                        volMeOH(1,CoLDNo)=GRFRS(w,z)-volH2O(1,CoLDNo);
                                        RatioStrong(1,CoLDNo)=log10(volH2O(1,CoLDNo)/GRFRS(w,z));
                                        lnTime(1,CoLDNo)=log10(GRFRS(w,z));
                                    end
                                end
                            end
                        end
                        
                        countNo=0;
                        for u=1:CoLDNo
                            if lnTime(1,u)~=0
                                countNo=countNo+1;
                                RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                                lnTime_PSS(1,countNo)=lnTime(1,u);
                            end
                        end
                        
                        
                        pSS(w,1:2)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                        
                        for z=1:countNo
                            RatioStrongfit2(1,z)=pSS(w,1)*lnTime_PSS(1,z)+pSS(w,2);
                        end
                        
                        R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                        pSS(w,3)=R2;
                        
                        GRFRSRecorded(w,:)=pSS(w,:);
                        
                        clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                    end
                    t01=cputime-t00;
                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                        'Con',num2str(ConID),'hold on ...']);
                    GroupNum=zeros(NGP,2);
                    for g=1:NGP
                        for i=1:nMultiply
                            CoLD=0;
                            vht=0;
                            for j=2:4:CWidth
                                CoLD=CoLD+1;
                                if abs(Multiply(i,j)-GRFRS(g,CoLD))>TimeDIFFTor && Multiply(i,j)*GRFRS(g,CoLD)~=0
                                    vht=1;
                                end
                                if Multiply(i,j)~=0 && GRFRS(g,CoLD)==0
                                    if (CoLD==1 && Multiply(i,j)-GRFRS(g,CoLD+1)<=TimeDIFFTor && GRFRS(g,CoLD+1)~=0)||...
                                            (CoLD==CWidth/4 && GRFRS(g,CoLD-1)-Multiply(i,j)<=TimeDIFFTor && GRFRS(g,CoLD-1)~=0)||...
                                            (CoLD<CWidth/4 && CoLD>1 && ((GRFRS(g,CoLD-1)-Multiply(i,j)<=TimeDIFFTor && ...
                                            GRFRS(g,CoLD-1)~=0) ||...
                                            Multiply(i,j)-GRFRS(g,CoLD+1)<=TimeDIFFTor) && GRFRS(g,CoLD+1)~=0)
                                        vht=1;
                                    end
                                end
                                if Multiply(i,j)==0 && GRFRS(g,CoLD)~=0
                                    if (CoLD==1 && GRFRS(g,CoLD)-Multiply(i,j+4)<=TimeDIFFTor && Multiply(i,j+4)~=0)||...
                                            (CoLD==CWidth/4 && Multiply(i,j-4)-GRFRS(g,CoLD)<=TimeDIFFTor && Multiply(i,j-4)~=0)||...
                                            (CoLD<CWidth/4 && CoLD>1 && ((Multiply(i,j-4)-GRFRS(g,CoLD)<=TimeDIFFTor && ...
                                            Multiply(i,j-4)~=0)||...
                                            GRFRS(g,CoLD)-Multiply(i,j+4)<=TimeDIFFTor) && Multiply(i,j+4)~=0)
                                        vht=1;
                                    end
                                end
                            end
                            if vht==0;
                                GroupNum(g,1)=GroupNum(g,1)+1;
                                GPABNTemp=0;
                                countMP=0;
                                for u=4:4:CWidth
                                    GPABNTemp=GPABNTemp+Multiply(i,u);
                                    if Multiply(i,u)>0
                                        countMP=countMP+1;
                                    end
                                end
                                GPABNTemp=GPABNTemp/countMP;
                                if GPABNTemp>GroupNum(g,2)
                                    GroupNum(g,2)=GPABNTemp;
                                end
                                ISGP(GroupNum(g,1),1:CWidth,g)=Multiply(i,1:CWidth);
                                ISGP(GroupNum(g,1),ConNo*4+1:ConNo*4+3,g)=GRFRSRecorded(g,1:3);
                            end
                        end
                    end
                    t01=cputime-t00;
                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                        'Con',num2str(ConID),'hold on ...']);
                    
                    nTDAN=0;
                    nVIGP=0;
                    GPABN_P=max(GroupNum(:,2));
                    GPABN_Q=min(GroupNum(:,2));
                    NMG=NGP;
                    IPQ=(GPABN_P-GPABN_Q)/NMG;
                    GPABNS=zeros(NMG,3);
                    for g=1:NMG
                        GPABNS(g,1)=GPABN_Q+IPQ*(g-1);
                        GPABNS(g,2)=GPABN_Q+IPQ*g;
                    end
                    for g=1:NMG
                        for z=1:NGP
                            if GroupNum(z,2)<=GPABNS(g,2) && GroupNum(z,2)>=GPABNS(g,1)
                                GPABNS(g,3)=GPABNS(g,3)+1;
                            end
                        end
                    end
                    if NGP>1
                        HNO=max(GPABNS(1:NGP-1,3));
                        for g=NMG:-1:1
                            if GPABNS(g,3)==HNO
                                HABN=GPABNS(g,1);
                            end
                        end
                    else
                        HABN=GPABNS(NGP,1);
                    end
                    
                    GIL=size(ISGP,1);
                    GIW=size(ISGP,2);
                    nTDAN=0;
                    for g=1:NGP
                        vht=0;
                        if GroupNum(g,2)>=HABN || GroupNum(g,2)>=0.1
                            INDIF=0;
                            INTempNo=0;
                            for p=1:GIL
                                for q=1:4:GIW-3
                                    if ISGP(p,q,g)>0
                                        if INTempNo==0
                                            INTempNo=INTempNo+1;
                                            IonNumberTemp(INTempNo,1)=ISGP(p,q,g);
                                            IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                        else
                                            vot=0;
                                            for s=1:INTempNo
                                                if abs(IonNumberTemp(INTempNo,1)-ISGP(p,q,g))<MassDIFFTor
                                                    vot=1;
                                                    IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                                end
                                            end
                                            if vot==0
                                                INTempNo=INTempNo+1;
                                                IonNumberTemp(INTempNo,1)=ISGP(p,q,g);
                                                IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                            end
                                        end
                                    end
                                end
                            end
                            
                            if INTempNo>MIMAssocIons
                                for p=1:INTempNo-1
                                    nTempDIFF=1;
                                    INT_TempDIFF(nTempDIFF,1:size(IonNumberTemp,2))=IonNumberTemp(p,1:size(IonNumberTemp,2));
                                    for v=p+1:INTempNo
                                        RepTime=0;
                                        for s=2:size(IonNumberTemp,2);
                                            if INT_TempDIFF(1,s)*IonNumberTemp(v,s)==1
                                                RepTime=RepTime+1;
                                            end
                                        end
                                        if RepTime>=MiMRep
                                            nTempDIFF=nTempDIFF+1;
                                            INT_TempDIFF(nTempDIFF,1:size(IonNumberTemp,2))=IonNumberTemp(v,1:size(IonNumberTemp,2));
                                        end
                                    end
                                    INT_TempDIFFS=unique(INT_TempDIFF,'rows');
                                    INT_TempDIFFS=sortrows(INT_TempDIFFS);
                                    INTS=size(INT_TempDIFFS,1);
                                    if INTS>MIMAssocIons
                                        INT_TempDIFFS1(1,1)=INT_TempDIFFS(1,1);
                                        INDIF=1;
                                        for k=2:INTS
                                            if INT_TempDIFFS(k,1)-INT_TempDIFFS1(INDIF,1)>3*MassDIFFTor
                                                INDIF=INDIF+1;
                                                INT_TempDIFFS1(INDIF,1)=INT_TempDIFFS(k,1);
                                            end
                                        end
                                        if INDIF>=MIMAssocIons
                                            vht=1;
                                        end
                                    end
                                    clear INT_TempDIFF INT_TempDIFFS INT_TempDIFFS1
                                end
                            end
                            clear IonNumberTemp
                        end
                        if vht==1
                            nTDAN=nTDAN+1;
                            TDANBYAbun(:,:,nTDAN)=ISGP(:,:,g);
                            SAFED(nTDAN,1)=g;
                            SAFED(nTDAN,2)=GroupNum(g,2);
                        end
                        clear IonNumberTemp IonNumberTempS IonNumberTempS1
                    end
                    t01=cputime-t00;
                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                        'Con',num2str(ConID),'hold on ...']);
                    if nTDAN>0
                        LengthTDBA=size(TDANBYAbun,1);
                        WidthTDBA=size(TDANBYAbun,2);
                        NoTDBA=size(TDANBYAbun,3);
                        SFLength=size(SAFED,1);
                        dataOutputFull1=SAFED(1:SFLength, 1:2);
                        save(sprintf('%s%s%s','SAFESam',num2str(SamID),'N.txt'),'dataOutputFull1','-ascii');
                        save(sprintf('%s%s%s','TDANSam',num2str(SamID),'N.mat'),'TDANBYAbun');
                    end
                end
            end
            
            clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo IMI INTDIFF IRT IntensityThreshold MB MBLength MIMAssocIons ...
                MassDIFFTor Mats MiMLinearity TimeShortLong SamID SamNoEn SamNoSt TimeDIFFTor files iFile ...
                nOfFiles nOfMats t0 t00
            
            t01=cputime-t00;
            disp(['Calculation time = ',num2str(t01), ' seconds', 'Sam',num2str(SamID),'N']);
        end
        
        LTRF=0;
        LTRFMiR=0;
        for ConID=1:ConNo
            for iFile=1:nOfFiles
                if (strcmp( files(iFile).name(1:4),'DENO'))
                    MaSuDN(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'P')
                            MaSuDN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuDN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuDN(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuDN(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuDN(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'P')
                            MaSuDN(1,1)=9;
                        end
                    end
                    if MaSuDN(1,1)>0
                        dataTemp=load(files(iFile).name);
                        LengthTemp=size(dataTemp,1);
                        DTSM(1:LengthTemp,1,ConID)=dataTemp(1:LengthTemp,1);
                        DTSM(1:LengthTemp,2,ConID)=dataTemp(1:LengthTemp,2);
                        DTSM(1:LengthTemp,3,ConID)=dataTemp(1:LengthTemp,7);
                        DTSM(1:LengthTemp,4,ConID)=dataTemp(1:LengthTemp,12);
                        LTSM(ConID,1)=ConID;
                        LTSM(ConID,2)=LengthTemp;
                        Ref(LTRF+1:LTRF+LengthTemp,1:4)=DTSM(1:LengthTemp,1:4,ConID);
                        LTRF=LTRF+LengthTemp;
                        
                        clear dataTemp;
                    end
                end
            end
        end
        t01=cputime-t00;
        disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
            'Con',num2str(ConID),'hold on ...']);
        
        if LTRF>0
            Ref=sortrows(Ref,1);
            nMultiply=0;
            for i=1:LTRF
                nFDMX=0;
                for w=1:size(LTSM,1)
                    for z=1:LTSM(w,2)
                        if abs(DTSM(z,1,w)-Ref(i,1))<MassDIFFTor &&...
                                abs(DTSM(z,4,w)-Ref(i,4))<1 &&...
                                abs(DTSM(z,3,w)-Ref(i,3))<INTDIFF
                            
                            nFDMX=nFDMX+1;
                            FDMX(nFDMX,1:4)=DTSM(z,1:4,w);
                            FDMX(nFDMX,5)=w;
                        end
                    end
                end
                if max(FDMX(1:nFDMX,2))>TimeShortLong
                    MiMRep=3;
                    TimeDIFF=TimeDIFFTor;
                else
                    MiMRep=3;
                    TimeDIFF=TimeDIFFTor/2;
                end
                
                if nFDMX>=MiMRep
                    nTMGMT=0;
                    for z=1:nFDMX
                        nSet=1;
                        SetU(nSet,:)=FDMX(z,:);
                        for z1=1:nFDMX
                            vot=0;
                            for z2=1:nSet
                                if SetU(z2,5)==FDMX(z1,5)
                                    vot=1;
                                end
                            end
                            if vot==0
                                nSet=nSet+1;
                                SetU(nSet,:)=FDMX(z1,:);
                            end
                        end
                        for z1=1:nSet
                            nTMRMT=1;
                            RefU(nTMRMT,:)=SetU(z1,:);
                            for z2=1:nSet
                                if RefU(nTMRMT,5)<SetU(z2,5) && RefU(nTMRMT,2)-SetU(z2,2)>TimeDIFF
                                    nTMRMT=nTMRMT+1;
                                    RefU(nTMRMT,:)=SetU(z2,:);
                                end
                            end
                            
                            if max(RefU(1:nTMRMT,2))>TimeShortLong
                                MiMRep=3;
                            else
                                MiMRep=3;
                            end
                            
                            if nTMRMT>=MiMRep && max(SetU(:,2))-min(SetU(:,2))>2*TimeDIFF
                                nTMGMT=nTMGMT+1;
                                for z3=1:nTMRMT
                                    TempU(nTMGMT,RefU(z3,5)*4-3:RefU(z3,5)*4)=RefU(z3,1:4);
                                end
                            end
                            clear RefU
                        end
                    end
                    clear SetU
                    if nTMGMT>0
                        nTMRMTS=1;
                        TMGMTWdith=size(TempU,2);
                        TMRMTS(nTMRMTS,:)=TempU(1,:);
                        for v=2:nTMGMT
                            vot=0;
                            vbt=0;
                            for v1=1:nTMRMTS
                                vpt=1;
                                for v2=4:4:TMGMTWdith
                                    if TMRMTS(v1,v2-3)*TempU(v,v2-3)~=0
                                        if TMRMTS(v1,v2-3)==TempU(v,v2-3) && TMRMTS(v1,v2-2)==TempU(v,v2-2) && ...
                                                TMRMTS(v1,v2-1)==TempU(v,v2-1) && TMRMTS(v1,v2)==TempU(v,v2)
                                            vpt=vpt*2;
                                        else
                                            vpt=vpt*0;
                                        end
                                    end
                                end
                                if vpt>1
                                    for v3=4:4:TMGMTWdith
                                        if TMRMTS(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                            vbt=1;
                                        end
                                    end
                                    if vbt==0
                                        for v3=4:4:TMGMTWdith
                                            if TMRMTS(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                                TMRMTS(v1,v3-3:v3)=TempU(v,v3-3:v3);
                                            end
                                        end
                                    end
                                    vot=1;
                                end
                            end
                            if vot==0
                                nTMRMTS=nTMRMTS+1;
                                TMRMTS(nTMRMTS,:)=TempU(v,:);
                            end
                        end
                        TGSWidth=size(TMRMTS,2);
                        clear TempU;
                        
                        for v=1:nTMRMTS
                            Multiply0(nMultiply+v,1:TGSWidth)=TMRMTS(v,1:TGSWidth);
                        end
                        nMultiply=nMultiply+nTMRMTS;
                        clear TMRMTS;
                        
                    end
                end
            end
            t01=cputime-t00;
            disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                'Con',num2str(ConID),'hold on ...']);
            
            if nMultiply>0
                Multiply1=unique(Multiply0,'rows');
                MultiplyLength=size(Multiply1,1);
                MultiplyWidth=size(Multiply1,2);
                nMultiply_Short=0;
                for w=1:MultiplyLength
                    for z=2:4:MultiplyWidth
                        if Multiply1(w,z)>0
                            CoLDNo=(z+2)/4;
                            for u=2:MBLength
                                if Multiply1(w,z)>MB(u-1,1) && Multiply1(w,z)<=MB(u,1)
                                    RatioH2O=(Multiply1(w,z)-MB(u-1,1))*((MB(u,CoLDNo+1)-MB(u-1,CoLDNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,CoLDNo+1);
                                    u0=u;
                                    volH2O(1,CoLDNo)=0;
                                    for u1=1:u0-1
                                        volH2O(1,CoLDNo)=volH2O(1,CoLDNo)+MB(u1+1,CoLDNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,CoLDNo+1)-MB(u1,CoLDNo+1))*(MB(u1+1,1)-MB(u1,1));
                                    end
                                    volH2O(1,CoLDNo)=volH2O(1,CoLDNo)-(MB(u0,1)-Multiply1(w,z))*MB(u0,CoLDNo+1)+(MB(u0,CoLDNo+1)-RatioH2O)*(MB(u0,1)-Multiply1(w,z));
                                    volH2O(1,CoLDNo)=volH2O(1,CoLDNo)/100;
                                    volMeOH(1,CoLDNo)=Multiply1(w,z)-volH2O(1,CoLDNo);
                                    RatioStrong(1,CoLDNo)=log10(volH2O(1,CoLDNo)/Multiply1(w,z));
                                    lnTime(1,CoLDNo)=log10(Multiply1(w,z));
                                end
                            end
                        end
                    end
                    
                    countNo=0;
                    for u=1:CoLDNo
                        if lnTime(1,u)~=0
                            countNo=countNo+1;
                            RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                            lnTime_PSS(1,countNo)=lnTime(1,u);
                        end
                    end
                    
                    vot=0;
                    for z=1:4:MultiplyWidth
                        if Multiply1(w,z)>0 && vot==0
                            pSS(w,1)=Multiply1(w,z);
                            vot=1;
                        end
                    end
                    pSS(w,2:3)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                    
                    for z=1:countNo
                        RatioStrongfit2(1,z)=pSS(w,2)*lnTime_PSS(1,z)+pSS(w,3);
                    end
                    
                    R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                    pSS(w,4)=R2;
                    
                    if R2>MiMLinearity
                        nMultiply_Short=nMultiply_Short+1;
                        p2(nMultiply_Short,:)=pSS(w,:);
                        Multiply(nMultiply_Short,:)=Multiply1(w,:);
                    end
                    
                    clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on ...']);
                
                
                if nMultiply_Short>0
                    MultiplyTemp=Multiply;
                    clear Multiply;
                    nMultiply=0;
                    BMM=0.6;
                    for z=1:nMultiply_Short
                        MoM=0;
                        for v=3:4:size(MultiplyTemp,2)
                            if MultiplyTemp(z,v)>=BMM
                                MoM=1;
                            end
                        end
                        if MoM==0
                            nMultiply=nMultiply+1;
                            Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                        else
                            oMo=0;
                            NoMass=0;
                            AveMass=0;
                            for v=1:4:size(MultiplyTemp,2)
                                if MultiplyTemp(z,v)>0
                                    AveMass=AveMass+MultiplyTemp(z,v);
                                    NoMass=NoMass+1;
                                end
                            end
                            AveMass=AveMass/NoMass;
                            
                            for u=1:size(MultiplyTemp,1)
                                if oMo==0
                                    for v=1:4:size(MultiplyTemp,2)
                                        if abs(AveMass-MultiplyTemp(u,v))<MassDIFFTor && MultiplyTemp(u,v+2)==1
                                            oMo=1;
                                        end
                                    end
                                end
                            end
                            
                            if oMo==1
                                nMultiply=nMultiply+1;
                                Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                            end
                        end
                    end
                    nMultiply=size(Multiply,1);
                    CWidth=size(Multiply,2);
                    NGP=1;
                    CoLD=0;
                    for i=2:4:CWidth
                        CoLD=CoLD+1;
                        GRFRS(NGP,CoLD)=Multiply(1,i);
                    end
                    for i=2:nMultiply
                        CoLD=0;
                        for j=2:4:CWidth
                            CoLD=CoLD+1;
                            Temp(1,CoLD)=Multiply(i,j);
                        end
                        Temp2=Temp';
                        if min(Temp2)<2*t0
                            TimeDIFF=TimeDIFFTor/2;
                        else
                            TimeDIFF=TimeDIFFTor;
                        end
                        vot=0;
                        vbt=0;
                        
                        for z=1:NGP
                            vmt=0;
                            vpt=1;
                            for u=1:CoLD
                                if Temp(1,u)*GRFRS(z,u)~=0
                                    if abs(Temp(1,u)-GRFRS(z,u))<TimeDIFF
                                        vpt=vpt*2;
                                    else
                                        vpt=vpt*0;
                                    end
                                end
                                if abs(Temp(1,u)-GRFRS(z,u))>=TimeDIFF
                                    vmt=1;
                                end
                            end
                            if vmt==0
                                vot=1;
                            end
                            if vpt>1 && vmt==1
                                for u=1:CoLD
                                    if Temp(1,u)~=0 && GRFRS(z,u)==0
                                        if (u==1 && Temp(1,u)-GRFRS(z,u+1)>TimeDIFF && GRFRS(z,u+1)~=0)||...
                                                (u==CoLD && GRFRS(z,u-1)-Temp(1,u)>TimeDIFF) ||...
                                                (u<CoLD && u>1 && GRFRS(z,u-1)-Temp(1,u)>TimeDIFF...
                                                && Temp(1,u)-GRFRS(z,u+1)>TimeDIFF && GRFRS(z,u+1)~=0)
                                            GRFRS(z,u)=Temp(1,u);
                                            vot=1;
                                        end
                                    end
                                end
                            end
                        end
                        if vot==0
                            NGP=NGP+1;
                            CoLD=0;
                            for v=2:4:CWidth
                                CoLD=CoLD+1;
                                GRFRS(NGP,CoLD)=Multiply(i,v);
                            end
                        end
                        clear Temp Temp2
                    end
                    GRFRS_Short=unique(GRFRS,'rows');
                    clear GRFRS
                    GRFRS=GRFRS_Short;
                    NGP=size(GRFRS,1);
                    
                    for w=1:NGP
                        for z=1:size(GRFRS,2)
                            if GRFRS(w,z)>0
                                CoLDNo=z;
                                for u=2:MBLength
                                    if GRFRS(w,z)>MB(u-1,1) && GRFRS(w,z)<=MB(u,1)
                                        RatioH2O=(GRFRS(w,z)-MB(u-1,1))*((MB(u,CoLDNo+1)-MB(u-1,CoLDNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,CoLDNo+1);
                                        u0=u;
                                        volH2O(1,CoLDNo)=0;
                                        for u1=1:u0-1
                                            volH2O(1,CoLDNo)=volH2O(1,CoLDNo)+MB(u1+1,CoLDNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,CoLDNo+1)-MB(u1,CoLDNo+1))*(MB(u1+1,1)-MB(u1,1));
                                        end
                                        volH2O(1,CoLDNo)=volH2O(1,CoLDNo)-(MB(u0,1)-GRFRS(w,z))*MB(u0,CoLDNo+1)+(MB(u0,CoLDNo+1)-RatioH2O)*(MB(u0,1)-GRFRS(w,z));
                                        volH2O(1,CoLDNo)=volH2O(1,CoLDNo)/100;
                                        volMeOH(1,CoLDNo)=GRFRS(w,z)-volH2O(1,CoLDNo);
                                        RatioStrong(1,CoLDNo)=log10(volH2O(1,CoLDNo)/GRFRS(w,z));
                                        lnTime(1,CoLDNo)=log10(GRFRS(w,z));
                                    end
                                end
                            end
                        end
                        
                        countNo=0;
                        for u=1:CoLDNo
                            if lnTime(1,u)~=0
                                countNo=countNo+1;
                                RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                                lnTime_PSS(1,countNo)=lnTime(1,u);
                            end
                        end
                        pSS(w,1:2)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                        for z=1:countNo
                            RatioStrongfit2(1,z)=pSS(w,1)*lnTime_PSS(1,z)+pSS(w,2);
                        end
                        R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                        pSS(w,3)=R2;
                        GRFRSRecorded(w,:)=pSS(w,:);
                        clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                    end
                    t01=cputime-t00;
                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                        'Con',num2str(ConID),'hold on ...']);
                    GroupNum=zeros(NGP,2);
                    for g=1:NGP
                        for i=1:nMultiply
                            CoLD=0;
                            vht=0;
                            for j=2:4:CWidth
                                CoLD=CoLD+1;
                                if abs(Multiply(i,j)-GRFRS(g,CoLD))>TimeDIFFTor && Multiply(i,j)*GRFRS(g,CoLD)~=0
                                    vht=1;
                                end
                                if Multiply(i,j)~=0 && GRFRS(g,CoLD)==0
                                    if (CoLD==1 && Multiply(i,j)-GRFRS(g,CoLD+1)<=TimeDIFFTor)||...
                                            (CoLD==CWidth/4 && GRFRS(g,CoLD-1)-Multiply(i,j)<=TimeDIFFTor)||...
                                            (CoLD<CWidth/4 && CoLD>1 && (GRFRS(g,CoLD-1)-Multiply(i,j)<=TimeDIFFTor ||...
                                            Multiply(i,j)-GRFRS(g,CoLD+1)<=TimeDIFFTor))
                                        vht=1;
                                    end
                                end
                                if Multiply(i,j)==0 && GRFRS(g,CoLD)~=0
                                    if (CoLD==1 && GRFRS(g,CoLD)-Multiply(i,j+4)<=TimeDIFFTor)||...
                                            (CoLD==CWidth/4 && Multiply(i,j-4)-GRFRS(g,CoLD)<=TimeDIFFTor)||...
                                            (CoLD<CWidth/4 && CoLD>1 && (Multiply(i,j-4)-GRFRS(g,CoLD)<=TimeDIFFTor ||...
                                            GRFRS(g,CoLD)-Multiply(i,j+4)<=TimeDIFFTor))
                                        vht=1;
                                    end
                                end
                            end
                            if vht==0;
                                GroupNum(g,1)=GroupNum(g,1)+1;
                                GPABNTemp=0;
                                countMP=0;
                                for u=4:4:CWidth
                                    GPABNTemp=GPABNTemp+Multiply(i,u);
                                    if Multiply(i,u)>0
                                        countMP=countMP+1;
                                    end
                                end
                                GPABNTemp=GPABNTemp/countMP;
                                if GPABNTemp>GroupNum(g,2)
                                    GroupNum(g,2)=GPABNTemp;
                                end
                                ISGP(GroupNum(g,1),1:CWidth,g)=Multiply(i,1:CWidth);
                                ISGP(GroupNum(g,1),ConNo*4+1:ConNo*4+3,g)=GRFRSRecorded(g,1:3);
                            end
                        end
                    end
                    t01=cputime-t00;
                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                        'Con',num2str(ConID),'hold on ...']);
                    
                    
                    nTDAN=0;
                    nVIGP=0;
                    GPABN_P=max(GroupNum(:,2));
                    GPABN_Q=min(GroupNum(:,2));
                    NMG=NGP;
                    IPQ=(GPABN_P-GPABN_Q)/NMG;
                    GPABNS=zeros(NMG,3);
                    for g=1:NMG
                        GPABNS(g,1)=GPABN_Q+IPQ*(g-1);
                        GPABNS(g,2)=GPABN_Q+IPQ*g;
                    end
                    for g=1:NMG
                        for z=1:NGP
                            if GroupNum(z,2)<=GPABNS(g,2) && GroupNum(z,2)>=GPABNS(g,1)
                                GPABNS(g,3)=GPABNS(g,3)+1;
                            end
                        end
                    end
                    if NGP>1
                        HNO=max(GPABNS(1:NGP-1,3));
                        for g=NMG:-1:1
                            if GPABNS(g,3)==HNO
                                HABN=GPABNS(g,1);
                            end
                        end
                    else
                        HABN=GPABNS(NGP,1);
                    end
                    
                    GIL=size(ISGP,1);
                    GIW=size(ISGP,2);
                    nTDAN=0;
                    for g=1:NGP
                        vht=0;
                        if GroupNum(g,2)>=HABN || GroupNum(g,2)>=0.1
                            INDIF=0;
                            INTempNo=0;
                            for p=1:GIL
                                for q=1:4:GIW-3
                                    if ISGP(p,q,g)>0
                                        if INTempNo==0
                                            INTempNo=INTempNo+1;
                                            IonNumberTemp(INTempNo,1)=ISGP(p,q,g);
                                            IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                        else
                                            vot=0;
                                            for s=1:INTempNo
                                                if abs(IonNumberTemp(INTempNo,1)-ISGP(p,q,g))<MassDIFFTor
                                                    vot=1;
                                                    IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                                end
                                            end
                                            if vot==0
                                                INTempNo=INTempNo+1;
                                                IonNumberTemp(INTempNo,1)=ISGP(p,q,g);
                                                IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                            end
                                        end
                                    end
                                end
                            end
                            
                            if INTempNo>MIMAssocIons
                                for p=1:INTempNo-1
                                    nTempDIFF=1;
                                    INT_TempDIFF(nTempDIFF,1:size(IonNumberTemp,2))=IonNumberTemp(p,1:size(IonNumberTemp,2));
                                    for v=p+1:INTempNo
                                        RepTime=0;
                                        for s=2:size(IonNumberTemp,2);
                                            if INT_TempDIFF(1,s)*IonNumberTemp(v,s)==1
                                                RepTime=RepTime+1;
                                            end
                                        end
                                        if RepTime>=MiMRep
                                            nTempDIFF=nTempDIFF+1;
                                            INT_TempDIFF(nTempDIFF,1:size(IonNumberTemp,2))=IonNumberTemp(v,1:size(IonNumberTemp,2));
                                        end
                                    end
                                    INT_TempDIFFS=unique(INT_TempDIFF,'rows');
                                    INT_TempDIFFS=sortrows(INT_TempDIFFS);
                                    INTS=size(INT_TempDIFFS,1);
                                    if INTS>MIMAssocIons
                                        INT_TempDIFFS1(1,1)=INT_TempDIFFS(1,1);
                                        INDIF=1;
                                        for k=2:INTS
                                            if INT_TempDIFFS(k,1)-INT_TempDIFFS1(INDIF,1)>3*MassDIFFTor
                                                INDIF=INDIF+1;
                                                INT_TempDIFFS1(INDIF,1)=INT_TempDIFFS(k,1);
                                            end
                                        end
                                        if INDIF>=MIMAssocIons
                                            vht=1;
                                        end
                                    end
                                    clear INT_TempDIFF INT_TempDIFFS INT_TempDIFFS1
                                end
                            end
                            clear IonNumberTemp
                        end
                        if vht==1
                            nTDAN=nTDAN+1;
                            TDANBYAbun(:,:,nTDAN)=ISGP(:,:,g);
                            SAFED(nTDAN,1)=g;
                            SAFED(nTDAN,2)=GroupNum(g,2);
                        end
                        clear IonNumberTemp IonNumberTempS IonNumberTempS1
                    end
                    t01=cputime-t00;
                    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                        'Con',num2str(ConID),'hold on ...']);
                    
                    
                    if nTDAN>0
                        
                        LengthTDBA=size(TDANBYAbun,1);
                        WidthTDBA=size(TDANBYAbun,2);
                        NoTDBA=size(TDANBYAbun,3);
                        SFLength=size(SAFED,1);
                        dataOutputFull1=SAFED(1:SFLength, 1:2);
                        save(sprintf('%s%s%s','SAFESam',num2str(SamID),'P.txt'),'dataOutputFull1','-ascii');
                        save(sprintf('%s%s%s','TDANSam',num2str(SamID),'P.mat'),'TDANBYAbun');
                        
                    end
                end
            end
            
            clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo IMI INTDIFF IRT IntensityThreshold MB MBLength MIMAssocIons ...
                MassDIFFTor Mats MiMLinearity TimeShortLong SamID SamNoEn SamNoSt TimeDIFFTor files iFile ...
                nOfFiles nOfMats t0 t00
            
            t01=cputime-t00;
            disp(['Calculation time = ',num2str(t01), ' seconds', 'Sam',num2str(SamID),'P']);
        end
    end
    t01=cputime-t00;
    disp(['hold on ... Calculation time =',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    RedundantIons=4;
    NosEliDIFF=IMI;
    TimeVariance=TimeDIFFTor/ConNo;
    GroupDIFFTIORControl=0.5;
    files = dir(fullfile('.', '*.txt'));
    [nOfFiles,~] = size(files);
    Mats = dir(fullfile('.', '*.mat'));
    [nOfMats,~]=size(Mats);
    for SamID=SamNoSt:SamNoEn
        TIRALength=0;
        for iFile=1:nOfFiles
            for ConID=1:ConNo
                if (strcmp(files(iFile).name(1:3),'Sam'))
                    MaSuUV(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                                && strcmp(files(iFile).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                                && strcmp(files(iFile).name(13),'.')
                            MaSuUV(1,1)=9;
                        end
                    end
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iFile).name);
                        UVTempLS=size(UVTemp,1);
                        TIRA(ConID,1)=ConID;
                        TIRA(ConID,2) =UVTemp(UVTempLS,1);
                        TIRALength=size(TIRA,1);
                    end
                end;
            end;
        end;
        if TIRALength>0
            NGP=0;nFeature=0;DRLength=0;
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'GRFR')
                    MaSuGF(1,1)=0;
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'N'))
                            MaSuGF(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'N'))
                            MaSuGF(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'N'))
                            MaSuGF(1,1)=3;
                        end
                    end
                    
                    if MaSuGF(1,1)>0
                        GRFRSRecord=load(files(iFile).name);
                        NGP=size(GRFRSRecord,1);
                    end
                end
            end
            
            
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'SAFE')
                    MaSuSF(1,1)=0;
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'N'))
                            MaSuSF(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'N'))
                            MaSuSF(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'N'))
                            MaSuSF(1,1)=3;
                        end
                    end
                    
                    if MaSuSF(1,1)>0
                        SAFED=load(files(iFile).name);
                        nFeature=size(SAFED,1);
                    end
                end
            end
            
            for iMatRef=1:nOfMats
                GroupPeak_Vis_Mark=0;
                if strcmp( Mats(iMatRef).name(1:4),'TDAN')
                    MaSuMa(1,1)=0;
                    if SamID<10
                        if str2double(Mats(iMatRef).name(8))==SamID ...
                                && (strcmp(Mats(iMatRef).name(9),'N'))
                            MaSuMa(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100
                        if str2double(Mats(iMatRef).name(8:9))==SamID ...
                                && (strcmp(Mats(iMatRef).name(10),'N'))
                            MaSuMa(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(Mats(iMatRef).name(8:10))==SamID ...
                                && (strcmp(Mats(iMatRef).name(11),'N'))
                            MaSuMa(1,1)=3;
                        end
                    end
                    if MaSuMa(1,1)>0
                        dataRef = load(Mats(iMatRef).name);
                        Refdata=dataRef.TDANBYAbun;
                        DRLength=size(Refdata);
                        if size(DRLength,2)==2
                            DRLength(1,3)=1;
                        end
                    end
                end
            end
            if NGP*nFeature*DRLength(1,1)~=0
                GroupPeak_Vis_Mark=0;
                con_count=0;
                for d2=1:4:DRLength(1,2)-3
                    
                    con_count=con_count+1;
                    ion_count_present=0;
                    ion_count_table_row=0;
                    
                    for d3=1:DRLength(1,3)
                        ion_count=0;
                        ion_count_table=0;
                        for d1=1:DRLength(1,1)
                            if Refdata(d1,d2,d3)>0
                                ion_count=ion_count+1;
                                INSM_Temp(ion_count,1:4)=Refdata(d1,d2:d2+3,d3);
                                INSM_Temp(ion_count,5:7)=Refdata(d1,ConNo*4+1:ConNo*4+3,d3);
                                INSM_Temp(ion_count,8)=d3;
                            end
                            
                        end
                        
                        if ion_count>1
                            INSM_Temp00=unique(INSM_Temp,'rows');
                            clear INSM_Temp
                            INSM_Temp00=sortrows(INSM_Temp00,1);
                            iTemp=1;
                            INSM_Temp0(iTemp,:)=INSM_Temp00(1,:);
                            for u=2:size(INSM_Temp00,1)
                                vot=0;
                                if INSM_Temp00(u,1)-INSM_Temp0(iTemp,1)>=IMI && vot==0
                                    iTemp=iTemp+1;
                                    INSM_Temp0(iTemp,:)=INSM_Temp00(u,:);
                                end
                            end
                            
                            
                            if iTemp>=MIMAssocIons
                                clear INSM_Temp0
                                if iTemp>RedundantIons
                                    INSM_Temp0(:,1:3)=INSM_Temp00(:,1:3);
                                    INSM_Temp010=unique(INSM_Temp0,'rows');
                                    NMG=size(INSM_Temp010,1);
                                    ISTHigh=max(INSM_Temp010(:,3));
                                    ISTLow=min(INSM_Temp010(:,3));
                                    
                                    IPQ=(ISTHigh-ISTLow)/NMG;
                                    GPABNS=zeros(NMG,3);
                                    
                                    for g=1:NMG
                                        GPABNS(g,1)=ISTLow+IPQ*(g-1);
                                        GPABNS(g,2)=ISTLow+IPQ*g;
                                    end
                                    
                                    for g=1:NMG
                                        for z=1:size(INSM_Temp010,1)
                                            if INSM_Temp010(z,3)<=GPABNS(g,2) ...
                                                    && INSM_Temp010(z,3)>=GPABNS(g,1)
                                                GPABNS(g,3)=GPABNS(g,3)+1;
                                            end
                                        end
                                    end
                                    HNO=max(GPABNS(:,3));
                                    for g=NMG:-1:1
                                        if GPABNS(g,3)==HNO
                                            HABN=GPABNS(g,1);
                                        end
                                    end
                                    
                                    ThresholdAbun_Presented=HABN;
                                    clear INSM_Temp010
                                else
                                    ThresholdAbun_Presented=0;
                                end
                                
                                for z=1:size(INSM_Temp00,1)
                                    if INSM_Temp00(z,3)>=ThresholdAbun_Presented
                                        ion_count_table=ion_count_table+1;
                                        INSM_Temp1(ion_count_table,:)=INSM_Temp00(z,:);
                                    end
                                end
                                
                                if ion_count_table>0
                                    ion_count_table_row=ion_count_table_row+1;
                                    RetentionTime=sum(INSM_Temp1(:,2))/ion_count_table;
                                    IITB(ion_count_table_row,1)=d3;
                                    IITB(ion_count_table_row,2)=RetentionTime;
                                    for z=1:ion_count_table
                                        IITB(ion_count_table_row,2+5*z-4)=INSM_Temp1(z,1);
                                        IITB(ion_count_table_row,2+5*z-3)=INSM_Temp1(z,3);
                                        IITB(ion_count_table_row,2+5*z-2)=INSM_Temp1(z,5);
                                        IITB(ion_count_table_row,2+5*z-1)=INSM_Temp1(z,6);
                                        IITB(ion_count_table_row,2+5*z)=INSM_Temp1(z,7);
                                    end
                                    GroupPeak_Vis_Mark=1;
                                    
                                end
                            end
                        end
                        clear INSM_Temp0 INSM_Temp00 RepNosIon INSM_Temp INSM_Temp1 ...
                            INSM_Temp2 INSM_Temp3 INSM_Temp4 GPABNS
                    end
                    if ion_count_table_row>0
                        IITB0=unique(IITB,'rows');
                        T0Length=size(IITB0,1);
                        T0Width=size(IITB0,2);
                        IITB_Short0(1:T0Length,1:T0Width,con_count)=IITB0(1:T0Length,1:T0Width);
                        clear IITB0 IITB
                    end
                end
                if GroupPeak_Vis_Mark==1
                    ionConNoMax=0;
                    TableID=size(IITB_Short0);
                    if size(TableID,2)<3
                        TableID(1,3)=1;
                    end
                    GEC=0;ISEC=0;
                    for d3=1:TableID(1,3)
                        GEC1=0;
                        TTT(1:TableID(1,1),1:TableID(1,2))=IITB_Short0(1:TableID(1,1),1:TableID(1,2),d3);
                        for k=1:TableID(1,1)
                            iTTT=0;
                            if TTT(k,1)>0
                                for u=3:5:TableID(1,2)
                                    if TTT(k,u)>0
                                        iTTT=iTTT+1;
                                        TTT2(iTTT,1:2)=TTT(k,u:u+1);
                                    end
                                end
                                TTT3=unique(TTT2,'rows');
                                iTT=size(TTT3,1);
                                IITB_Short_Derep(k,1:2,d3)=IITB_Short0(k,1:2,d3);
                                for u=1:iTT
                                    IITB_Short_Derep(k,u*2+1:u*2+2,d3)=TTT3(u,1:2);
                                    GEC1=1;
                                end
                            end
                            clear TTT2 TTT3
                        end
                        clear TTT
                        
                        if GEC1>0
                            TableID_Derep=size(IITB_Short_Derep);
                            if size(TableID_Derep,2)<3
                                TableID_Derep(1,3)=1;
                            end
                            
                            
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableID_Derep(1,1)
                                if IITB_Short_Derep(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            
                            if groupNo>0
                                str= sprintf('%s%s%s%s%s%s','GINFSam', num2str(SamID),'Con',num2str(d3),'N','.txt');
                                fid=fopen(str,'w');
                                IonIntNo=0;
                                for d1=1:TableID_Derep(1,1)
                                    if IITB_Short_Derep(d1,1,d3)>0
                                        for d2=3:2:TableID_Derep(1,2)
                                            if IITB_Short_Derep(d1,d2,d3)>0
                                                Code=SAFED(IITB_Short_Derep(d1,1,d3),1);
                                                FRWH(1,1:3)=GRFRSRecord(Code,1:3);
                                                fprintf(fid,'%d %.1f ',d1,IITB_Short_Derep(d1,2,d3));
                                                for z=1:3
                                                    fprintf(fid,'%.4f ',FRWH(1,z));
                                                end
                                                ionConNo=ionConNo+1;
                                                INSM001(ionConNo,1:2)=IITB_Short_Derep(d1,d2:d2+1,d3);
                                                IonIntNo=IonIntNo+1;
                                                INSM0001(IonIntNo,1:2)=IITB_Short_Derep(d1,d2:d2+1,d3);
                                                fprintf(fid,'%.1f %.4f ',IITB_Short_Derep(d1,d2,d3),IITB_Short_Derep(d1,d2+1,d3));
                                                fprintf(fid,'\n');
                                            end
                                        end
                                        
                                        if IonIntNo>0
                                            maxIonInt=max(INSM0001(:,2));
                                            maxIon(1,4)=0;
                                            for z=1:IonIntNo
                                                if maxIonInt==INSM0001(z,2)
                                                    maxIon(1,3)=INSM0001(z,1);
                                                end
                                                maxIon(1,4)=maxIon(1,4)+INSM0001(z,2);
                                            end
                                            GroupIntSum(d1,1:2,d3)=IITB_Short_Derep(d1,1:2,d3);
                                            GroupIntSum(d1,3:4,d3)=maxIon(1,3:4);
                                            GEC=1;
                                        end
                                        clear INSM0001 maxIon
                                    end
                                end
                                fclose(fid);
                                clear IITB_Short_Derep
                            end
                            if ionConNo>0
                                INSM002=unique(INSM001,'rows');
                                INSM002=sortrows(INSM002,1);
                                INSM(1:size(INSM002,1),d3)=INSM002(:,1);
                                ISEC=1;
                            end
                            clear INSM001 INSM002 INSM003
                            if ionConNo>ionConNoMax
                                ionConNoMax=ionConNo;
                            end
                        end
                    end
                    clear TableID
                    
                    if GEC>0
                        TableID=size(GroupIntSum);
                        if size(TableID)==2
                            TableID(1,3)=1;
                        end
                        
                        str= sprintf('%s%s%s','GREPSam',num2str(SamID),'N.txt');
                        fid=fopen(str,'w');
                        for d3=1:TableID(1,3)
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableID(1,1)
                                if GroupIntSum(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            if groupNo>0
                                fprintf(fid,'%s%s%s%s','Totally ',num2str(groupNo),' groups apparently visible under CoLD G',num2str(d3));
                                fprintf(fid,'\n');
                                for d1=1:TableID(1,1)
                                    if GroupIntSum(d1,1,d3)>0
                                        fprintf(fid,'%d %d ',d1,GroupIntSum(d1,1,d3));
                                        fprintf(fid,'%.1f ',GroupIntSum(d1,2,d3));
                                        fprintf(fid,'%.1f %.4f ',GroupIntSum(d1,3:4,d3));
                                        fprintf(fid,'\n');
                                    end
                                end
                            end
                            fprintf(fid,'\n');
                        end
                        fclose(fid);
                        clear GroupIntSum
                    end
                    clear IITB_Short INSM001 INSM002
                    
                    if ISEC>0
                        DCLength=size(INSM,1);
                        DCWidth=size(INSM,2);
                        nMerge=0;
                        for v=1:DCWidth
                            for u=1:DCLength
                                if INSM(u,v)>0
                                    nMerge=nMerge+1;
                                    MergedINSM(nMerge,1)=INSM(u,v);
                                end
                            end
                        end
                        MergedINSM_Short=unique(MergedINSM,'rows');
                        MergedINSM_Short=sortrows(MergedINSM_Short);
                        DCLength=size(MergedINSM_Short,1);
                        
                        clear INSM
                        for v=1:DCWidth
                            INSM(1:DCLength,v)=MergedINSM_Short;
                        end
                    end
                    if ionConNoMax>0
                        for ConID=1:DCWidth
                            XICSNLength=0;
                            for iMat=1:nOfMats
                                if strcmp( Mats(iMat).name(1:3),'Sam')
                                    MaSuMa(1,1)=0;
                                    if SamID<10 && ConID<10
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                                && (strcmp(Mats(iMat).name(9),'N'))...
                                                && strcmp(Mats(iMat).name(10),'.')
                                            MaSuMa(1,1)=1;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID<10
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'N'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=2;
                                        end
                                    end
                                    if SamID>=100 && ConID<10
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'N'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=3;
                                        end
                                    end
                                    if SamID<10 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'N'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=4;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'N'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=5;
                                        end
                                    end
                                    if SamID>=100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'N'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=6;
                                        end
                                    end
                                    if SamID<10 && ConID>=100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'N'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=7;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'N'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=8;
                                        end
                                    end
                                    if SamID>=100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                                && (strcmp(Mats(iMat).name(13),'N'))...
                                                && strcmp(Mats(iMat).name(14),'.')
                                            MaSuMa(1,1)=9;
                                        end
                                    end
                                    if MaSuMa(1,1)>0
                                        data = load(Mats(iMat).name);
                                        Scans=data.Scans;
                                        SDWI=size(Scans,2);
                                        MergeMass=data.Masses;
                                        dataLength=size(MergeMass,1);
                                        MergeData=data.Data;
                                        Timerange=TIRA(ConID,2);
                                        DANW=MergeData;
                                        XIC=zeros(SDWI,2);
                                        METI=Scans(1,:)*Timerange/Scans(1,size(Scans,2));
                                        nCount=0;
                                        for r=1:DCLength
                                            if INSM(r,ConID)>0
                                                for h=MassRange+1:dataLength-MassRange
                                                    if abs(INSM(r,ConID)-MergeMass(h,1))<IMI
                                                        for j=1:SDWI
                                                            XIC(j,1)=METI(1,j);
                                                            XIC(j,2)=sum(DANW(h-MassRange:h+MassRange,j));
                                                        end
                                                        XICSN=XIC;
                                                        HighPoint=max(XICSN(:,2));
                                                        LowPoint=min(XICSN(:,2));
                                                        SETINo=100;
                                                        Incre=(HighPoint-LowPoint)/SETINo;
                                                        SETI=zeros(SETINo,3);
                                                        
                                                        for i=1:SETINo
                                                            SETI(i,1)=Incre*(i-1)+LowPoint;
                                                            SETI(i,2)=Incre*i+LowPoint;
                                                            SETI(i,3)=0;
                                                        end
                                                        XICSNLength=size(XICSN,1);
                                                        for j=1:XICSNLength
                                                            for u=1:SETINo
                                                                if XICSN(j,2)>=SETI(u,1) && XICSN(j,2)<SETI(u,2)
                                                                    SETI(u,3)=SETI(u,3)+1;
                                                                end
                                                            end
                                                        end
                                                        chooseSETI=max(SETI(2:SETINo,3));
                                                        for i=2:SETINo
                                                            if SETI(i,3)==chooseSETI
                                                                BASLL=SETI(i,1);
                                                                BASLH=SETI(i,2);
                                                            end
                                                        end
                                                        BASLV=0;
                                                        count=0;
                                                        for i=1:XICSNLength
                                                            if XICSN(i,2)>=BASLL && XICSN(i,2)<BASLH
                                                                BASLV=BASLV+XICSN(i,2);
                                                                count=count+1;
                                                            end
                                                        end
                                                        BASLV=BASLV/count;
                                                        XICSN=XICSN';
                                                        FDTH=round(TIRA(ConID,2)*2.5*log10(SDWI));
                                                        AWTH=size(XICSN,2);
                                                        TIOR=round(AWTH/FDTH);
                                                        if TIOR>=1
                                                            iCol=0;
                                                            for k=1:TIOR:AWTH-TIOR
                                                                iCol=iCol+1;
                                                                XICSN_New(2,iCol)=sum(XICSN(2,k:k+TIOR-1));
                                                                XICSN_New(1,iCol)=0.5*(XICSN(1,k)+XICSN(1,k+TIOR-1));
                                                            end
                                                        else
                                                            TIOR2=round(FDTH/AWTH);
                                                            iCol=TIOR2*AWTH;
                                                            for o=1:SDWI
                                                                XICSN_New(1,o*TIOR2-TIOR2+1:o*TIOR2)=XICSN(1,o);
                                                                XICSN_New(2,o*TIOR2-TIOR2+1:o*TIOR2)=XICSN(2,o);
                                                            end
                                                        end
                                                        
                                                        XICSN_New=XICSN_New';
                                                        fr = FDTH/16;
                                                        dt = (16/FDTH)^2;
                                                        rick = ricker(FDTH,fr,dt,20);
                                                        rick_smooth = getSmoothRicker(rick);
                                                        SXIC0  = conv( rick_smooth(:,1),XICSN_New(:,2) );
                                                        SXIC(:,1)=XICSN_New(:,1);
                                                        SXIC(:,2)=SXIC0( round(length(rick_smooth)/2)+1:length(XICSN_New(:,2))+round(length(rick_smooth)/2));
                                                        SXICLength=size(SXIC,1);
                                                        
                                                        PTSD=0.01;
                                                        PPGSN=0;
                                                        HighPoint=max(SXIC(:,2));
                                                        for i=2:SXICLength-1
                                                            if SXIC(i,2)>=SXIC(i-1,2) && SXIC(i,2)>=SXIC(i+1,2) && SXIC(i,2)> HighPoint*PTSD && (SXIC(i,2)-SXIC(i-1,2))+(SXIC(i,2)-SXIC(i+1,2))~=0
                                                                PPGSN=PPGSN+1;
                                                                PPGS(PPGSN,1) = SXIC(i,1);
                                                                PPGS(PPGSN,2) = SXIC(i,2);
                                                            end;
                                                        end;
                                                        
                                                        BASLT=0.01;
                                                        NPIR=0;
                                                        
                                                        if PPGSN>0
                                                            for m=1:PPGSN
                                                                PTI=PPGS(m,1);
                                                                PHT=PPGS(m,2);
                                                                PPSN(1,1)=PPGS(m,1);
                                                                PPSN(1,2)=PPGS(m,2);
                                                                halfPH=PHT/2;
                                                                
                                                                for z=1:SXICLength
                                                                    if SXIC(z,1)==PTI
                                                                        PP=z;
                                                                    end;
                                                                end;
                                                                
                                                                vbv1=0;
                                                                for z=PP:-1:2
                                                                    if SXIC(z,2)>=0 && SXIC(z-1,2)<=0 && vbv1==0
                                                                        CZTL=SXIC(z,1);
                                                                        LeftID=z;
                                                                        vbv1=1;
                                                                    end;
                                                                end;
                                                                
                                                                if vbv1==0
                                                                    CZTL=0;
                                                                    LeftID=1;
                                                                end;
                                                                
                                                                vbv2=0;
                                                                for z=PP:SXICLength-1
                                                                    if SXIC(z,2)>=0 && SXIC(z+1,2)<=0 && vbv2==0
                                                                        CZTR=SXIC(z,1);
                                                                        RightID=z;
                                                                        vbv2=1;
                                                                    end;
                                                                end;
                                                                
                                                                if vbv2==0
                                                                    CZTR=SXIC(SXICLength,1);
                                                                    RightID=SXICLength;
                                                                end;
                                                                
                                                                PPGS(m,3)=CZTL;
                                                                PPGS(m,4)=CZTR;
                                                                PPGS(m,5)=(CZTR-CZTL)/TIRA(ConID,2);
                                                                PPGS(m,6)=PHT/HighPoint;
                                                                PPGS(m,7)=PPGS(m,6)/PPGS(m,5);
                                                                
                                                                
                                                                if LeftID>1 && RightID<SXICLength
                                                                    PPGS(m,8)=0;
                                                                    for z=LeftID:RightID
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                                if LeftID==1 && RightID<SXICLength
                                                                    PPGS(m,8)=(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                                    for z=2:RightID
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                                if LeftID>1 && RightID==SXICLength
                                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                                    for z=LeftID:RightID-1
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                                
                                                                if LeftID==1 && RightID==SXICLength
                                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                                    PPGS(m,8)=PPGS(m,8)+(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                                    for z=2:SXICLength-1
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                            end;
                                                            
                                                            PPGSST(1,:)=PPGS(1,:);
                                                            nPPShort=1;
                                                            for z=1:PPGSN
                                                                if PPGS(z,1)-PPGSST(nPPShort,1)<TimeDIFFTor
                                                                    if PPGS(z,2)>PPGSST(nPPShort,2)
                                                                        PPGSST(nPPShort,1)=PPGS(z,1);
                                                                        PPGSST(nPPShort,2)=PPGS(z,2);
                                                                    end;
                                                                    if PPGS(z,3)>PPGSST(nPPShort,3)
                                                                        PPGSST(nPPShort,3)=PPGS(z,3);
                                                                    end;
                                                                    if PPGS(z,4)<PPGSST(nPPShort,4)
                                                                        PPGSST(nPPShort,4)=PPGS(z,4);
                                                                    end;
                                                                    PPGSST(nPPShort,5)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))/TIRA(ConID,2);
                                                                    PPGSST(nPPShort,6)=PPGSST(nPPShort,2)/HighPoint;
                                                                    PPGSST(nPPShort,7)=PPGSST(nPPShort,6)/PPGSST(nPPShort,5);
                                                                    PPGSST(nPPShort,8)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))*PPGSST(nPPShort,2)/2;
                                                                else
                                                                    nPPShort=nPPShort+1;
                                                                    PPGSST(nPPShort,:)=PPGS(z,:);
                                                                end;
                                                            end;
                                                            
                                                            LargestPeak=max(PPGSST(:,8));
                                                            
                                                            PPGSST(:,9)=PPGSST(:,8)/LargestPeak;
                                                            
                                                            nPeakRange=0;
                                                            for z=1:nPPShort
                                                                if PPGSST(z,9)>RelArea
                                                                    nPeakRange=nPeakRange+1;
                                                                    PeakRange(nPeakRange,:)=PPGSST(z,:);
                                                                end
                                                            end
                                                            
                                                            clear PPGS PPGSST ...
                                                                width PPSN XICSN_New;
                                                        end;
                                                        clear XIC SXIC SETI;
                                                        
                                                        
                                                        if nPeakRange<PXSet
                                                            XICSN=XICSN';
                                                            
                                                            for i=1:XICSNLength
                                                                if XICSN(i,2)>BASLV
                                                                    AMP=abs(1/log10(XICSN(i,2)/BASLV))^0.2;
                                                                    XICSN(i,2)=XICSN(i,2)*AMP*(XICSN(i,2)/BASLV)-BASLV;
                                                                else
                                                                    XICSN(i,2)=0;
                                                                end
                                                            end
                                                            nCount=nCount+1;
                                                            MassInfor(1,nCount)=INSM(r,ConID);
                                                            
                                                            
                                                            for j=1:SDWI
                                                                XICSNSummary(j,1)=XICSN(j,1);
                                                                XICSNSummary(j,nCount+1)=XICSN(j,2);
                                                            end
                                                        end
                                                        clear PeakRange
                                                    end
                                                end
                                                clear XIC XICSN SETI
                                            end
                                        end
                                        
                                        if XICSNLength>0
                                            TICAppear=zeros(SDWI,3);
                                            for i=1:SDWI
                                                TICAppear(i,1)=XICSNSummary(i,1);
                                                TICAppear(i,2)=sum(XICSNSummary(i,2:nCount+1));
                                                TICAppear(i,3)=sum(DANW(:,i));
                                            end
                                            TICAppear_Rel(:,1)=TICAppear(:,1);
                                            TICAppear_Rel(:,2)=TICAppear(:,2)./max(TICAppear(:,2));
                                            TICAppear_Rel(:,3)=TICAppear(:,3)./max(TICAppear(:,3));
                                            
                                            str= sprintf('%s%s%s%s%s','TICSSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                            fid=fopen(str,'w');
                                            for u=1:SDWI
                                                for v=1:3
                                                    fprintf(fid,'%.4f ',TICAppear_Rel(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','MassSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                            fid=fopen(str,'w');
                                            for v=1:nCount
                                                fprintf(fid,'%.4f ',MassInfor(1,v));
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','XICSSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                            fid=fopen(str,'w');
                                            for u=1:SDWI
                                                for v=1:nCount+1
                                                    fprintf(fid,'%.4f ',XICSNSummary(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            clear TICAppear XICSNSummary MassInfor TICAppear_Rel
                                        end
                                    end
                                end
                            end
                        end
                        clear INSM
                    end
                end
            end
            clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo GroupDIFFTIORControl IMI INTDIFF IRT ...
                IntensityThreshold MB MBLength MIMAssocIons MassDIFF MassDIFFTor Mats ...
                MiMLinearity NosEliDIFF RedundantIons SamID SamNoEn SamNoSt TIRALength ...
                TimeDIFFTor TimeVariance files iFile nOfFiles nOfMats ...
                GRFRSRecord NGP SAFED nFeature Refdata DRLength t0 t00
        end
        clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo GroupDIFFTIORControl IMI INTDIFF IRT ...
            IntensityThreshold MB MBLength MIMAssocIons MassDIFF MassDIFFTor Mats ...
            MiMLinearity NosEliDIFF RedundantIons SamID SamNoEn SamNoSt TIRALength ...
            TimeDIFFTor TimeVariance files iFile nOfFiles nOfMats t0 t00
        
        t01 = cputime-t00;
        disp(['Calculation time = ',num2str(t01), 'Sam', num2str(SamID) ]);
    end
    t01=cputime-t00;
    disp(['hold on... Calculation time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    for SamID=SamNoSt:SamNoEn
        TIRALength=0;
        for iFile=1:nOfFiles
            for ConID=1:ConNo
                if (strcmp(files(iFile).name(1:3),'Sam'))
                    MaSuUV(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                                && strcmp(files(iFile).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                                && strcmp(files(iFile).name(10),'.')
                            MaSuUV(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                                && strcmp(files(iFile).name(11),'.')
                            MaSuUV(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                                && strcmp(files(iFile).name(12),'.')
                            MaSuUV(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                                && strcmp(files(iFile).name(13),'.')
                            MaSuUV(1,1)=9;
                        end
                    end
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iFile).name);
                        UVTempLS=size(UVTemp,1);
                        TIRA(ConID,1)=ConID;
                        TIRA(ConID,2) =UVTemp(UVTempLS,1);
                        TIRALength=size(TIRA,1);
                    end
                end;
            end;
        end;
        if TIRALength>0
            NGP=0;nFeature=0;DRLength=0;
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'GRFR')
                    MaSuGF(1,1)=0;
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'P'))
                            MaSuGF(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'P'))
                            MaSuGF(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'P'))
                            MaSuGF(1,1)=3;
                        end
                    end
                    if MaSuGF(1,1)>0
                        GRFRSRecord=load(files(iFile).name);
                        NGP=size(GRFRSRecord,1);
                    end
                end
            end
            
            
            for iFile=1:nOfFiles
                if strcmp( files(iFile).name(1:4),'SAFE')
                    MaSuSF(1,1)=0;
                    if SamID<10
                        if str2double(files(iFile).name(8))==SamID ...
                                && (strcmp(files(iFile).name(9),'P'))
                            MaSuSF(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID ...
                                && (strcmp(files(iFile).name(10),'P'))
                            MaSuSF(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iFile).name(8:10))==SamID ...
                                && (strcmp(files(iFile).name(11),'P'))
                            MaSuSF(1,1)=3;
                        end
                    end
                    
                    if MaSuSF(1,1)>0
                        SAFED=load(files(iFile).name);
                        nFeature=size(SAFED,1);
                    end
                end
            end
            
            for iMatRef=1:nOfMats
                GroupPeak_Vis_Mark=0;
                if strcmp( Mats(iMatRef).name(1:4),'TDAN')
                    MaSuMa(1,1)=0;
                    if SamID<10
                        if str2double(Mats(iMatRef).name(8))==SamID ...
                                && (strcmp(Mats(iMatRef).name(9),'P'))
                            MaSuMa(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100
                        if str2double(Mats(iMatRef).name(8:9))==SamID ...
                                && (strcmp(Mats(iMatRef).name(10),'P'))
                            MaSuMa(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(Mats(iMatRef).name(8:10))==SamID ...
                                && (strcmp(Mats(iMatRef).name(11),'P'))
                            MaSuMa(1,1)=3;
                        end
                    end
                    if MaSuMa(1,1)>0
                        dataRef = load(Mats(iMatRef).name);
                        Refdata=dataRef.TDANBYAbun;
                        DRLength=size(Refdata);
                        if size(DRLength,2)==2
                            DRLength(1,3)=1;
                        end
                    end
                end
            end
            if NGP*nFeature*DRLength(1,1)~=0
                GroupPeak_Vis_Mark=0;
                con_count=0;
                for d2=1:4:DRLength(1,2)-3
                    con_count=con_count+1;
                    ion_count_present=0;
                    ion_count_table_row=0;
                    
                    for d3=1:DRLength(1,3)
                        ion_count=0;
                        ion_count_table=0;
                        
                        for d1=1:DRLength(1,1)
                            if Refdata(d1,d2,d3)>0
                                ion_count=ion_count+1;
                                INSM_Temp(ion_count,1:4)=Refdata(d1,d2:d2+3,d3);
                                INSM_Temp(ion_count,5:7)=Refdata(d1,ConNo*4+1:ConNo*4+3,d3);
                                INSM_Temp(ion_count,8)=d3;
                            end
                            
                        end
                        
                        if ion_count>1
                            INSM_Temp00=unique(INSM_Temp,'rows');
                            clear INSM_Temp
                            INSM_Temp00=sortrows(INSM_Temp00,1);
                            iTemp=1;
                            INSM_Temp0(iTemp,:)=INSM_Temp00(1,:);
                            for u=2:size(INSM_Temp00,1)
                                vot=0;
                                if INSM_Temp00(u,1)-INSM_Temp0(iTemp,1)>=IMI && vot==0
                                    iTemp=iTemp+1;
                                    INSM_Temp0(iTemp,:)=INSM_Temp00(u,:);
                                end
                            end
                            
                            
                            if iTemp>=MIMAssocIons
                                clear INSM_Temp0
                                if iTemp>RedundantIons
                                    INSM_Temp0(:,1:3)=INSM_Temp00(:,1:3);
                                    INSM_Temp010=unique(INSM_Temp0,'rows');
                                    NMG=size(INSM_Temp010,1);
                                    ISTHigh=max(INSM_Temp010(:,3));
                                    ISTLow=min(INSM_Temp010(:,3));
                                    
                                    IPQ=(ISTHigh-ISTLow)/NMG;
                                    GPABNS=zeros(NMG,3);
                                    
                                    for g=1:NMG
                                        GPABNS(g,1)=ISTLow+IPQ*(g-1);
                                        GPABNS(g,2)=ISTLow+IPQ*g;
                                    end
                                    
                                    for g=1:NMG
                                        for z=1:size(INSM_Temp010,1)
                                            if INSM_Temp010(z,3)<=GPABNS(g,2) ...
                                                    && INSM_Temp010(z,3)>=GPABNS(g,1)
                                                GPABNS(g,3)=GPABNS(g,3)+1;
                                            end
                                        end
                                    end
                                    HNO=max(GPABNS(:,3));
                                    for g=NMG:-1:1
                                        if GPABNS(g,3)==HNO
                                            HABN=GPABNS(g,1);
                                        end
                                    end
                                    
                                    ThresholdAbun_Presented=HABN;
                                    clear INSM_Temp010
                                else
                                    ThresholdAbun_Presented=0;
                                end
                                
                                for z=1:size(INSM_Temp00,1)
                                    if INSM_Temp00(z,3)>=ThresholdAbun_Presented
                                        ion_count_table=ion_count_table+1;
                                        INSM_Temp1(ion_count_table,:)=INSM_Temp00(z,:);
                                    end
                                end
                                
                                
                                if ion_count_table>0
                                    ion_count_table_row=ion_count_table_row+1;
                                    RetentionTime=sum(INSM_Temp1(:,2))/ion_count_table;
                                    IITB(ion_count_table_row,1)=d3;
                                    IITB(ion_count_table_row,2)=RetentionTime;
                                    for z=1:ion_count_table
                                        IITB(ion_count_table_row,2+5*z-4)=INSM_Temp1(z,1);
                                        IITB(ion_count_table_row,2+5*z-3)=INSM_Temp1(z,3);
                                        IITB(ion_count_table_row,2+5*z-2)=INSM_Temp1(z,5);
                                        IITB(ion_count_table_row,2+5*z-1)=INSM_Temp1(z,6);
                                        IITB(ion_count_table_row,2+5*z)=INSM_Temp1(z,7);
                                    end
                                    GroupPeak_Vis_Mark=1;
                                    
                                end
                            end
                        end
                        clear INSM_Temp0 INSM_Temp00 RepNosIon INSM_Temp INSM_Temp1 ...
                            INSM_Temp2 INSM_Temp3 INSM_Temp4 GPABNS
                    end
                    if ion_count_table_row>0
                        IITB0=unique(IITB,'rows');
                        T0Length=size(IITB0,1);
                        T0Width=size(IITB0,2);
                        IITB_Short0(1:T0Length,1:T0Width,con_count)=IITB0(1:T0Length,1:T0Width);
                        clear IITB0 IITB
                    end
                end
                if GroupPeak_Vis_Mark==1
                    ionConNoMax=0;
                    TableID=size(IITB_Short0);
                    if size(TableID,2)<3
                        TableID(1,3)=1;
                    end
                    GEC=0;ISEC=0;
                    for d3=1:TableID(1,3)
                        GEC1=0;
                        TTT(1:TableID(1,1),1:TableID(1,2))=IITB_Short0(1:TableID(1,1),1:TableID(1,2),d3);
                        for k=1:TableID(1,1)
                            iTTT=0;
                            if TTT(k,1)>0
                                for u=3:5:TableID(1,2)
                                    if TTT(k,u)>0
                                        iTTT=iTTT+1;
                                        TTT2(iTTT,1:2)=TTT(k,u:u+1);
                                    end
                                end
                                TTT3=unique(TTT2,'rows');
                                iTT=size(TTT3,1);
                                IITB_Short_Derep(k,1:2,d3)=IITB_Short0(k,1:2,d3);
                                GEC1=1;
                                for u=1:iTT
                                    IITB_Short_Derep(k,u*2+1:u*2+2,d3)=TTT3(u,1:2);
                                end
                            end
                            clear TTT2 TTT3
                        end
                        clear TTT
                        
                        if GEC1>0
                            TableID_Derep=size(IITB_Short_Derep);
                            if size(TableID_Derep,2)<3
                                TableID_Derep(1,3)=1;
                            end
                            
                            
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableID_Derep(1,1)
                                if IITB_Short_Derep(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            
                            if groupNo>0
                                str= sprintf('%s%s%s%s%s%s','GINFSam', num2str(SamID),'Con',num2str(d3),'P','.txt');
                                fid=fopen(str,'w');
                                IonIntNo=0;
                                for d1=1:TableID_Derep(1,1)
                                    if IITB_Short_Derep(d1,1,d3)>0
                                        for d2=3:2:TableID_Derep(1,2)
                                            if IITB_Short_Derep(d1,d2,d3)>0
                                                Code=SAFED(IITB_Short_Derep(d1,1,d3),1);
                                                FRWH(1,1:3)=GRFRSRecord(Code,1:3);
                                                fprintf(fid,'%d %.1f ',d1,IITB_Short_Derep(d1,2,d3));
                                                for z=1:3
                                                    fprintf(fid,'%.4f ',FRWH(1,z));
                                                end
                                                ionConNo=ionConNo+1;
                                                INSM001(ionConNo,1:2)=IITB_Short_Derep(d1,d2:d2+1,d3);
                                                IonIntNo=IonIntNo+1;
                                                INSM0001(IonIntNo,1:2)=IITB_Short_Derep(d1,d2:d2+1,d3);
                                                fprintf(fid,'%.1f %.4f ',IITB_Short_Derep(d1,d2,d3),IITB_Short_Derep(d1,d2+1,d3));
                                                fprintf(fid,'\n');
                                            end
                                        end
                                        if IonIntNo>0
                                            maxIonInt=max(INSM0001(:,2));
                                            maxIon(1,4)=0;
                                            for z=1:IonIntNo
                                                if maxIonInt==INSM0001(z,2)
                                                    maxIon(1,3)=INSM0001(z,1);
                                                end
                                                maxIon(1,4)=maxIon(1,4)+INSM0001(z,2);
                                            end
                                            GroupIntSum(d1,1:2,d3)=IITB_Short_Derep(d1,1:2,d3);
                                            GroupIntSum(d1,3:4,d3)=maxIon(1,3:4);
                                            GEC=1;
                                        end
                                        clear INSM0001 maxIon
                                    end
                                end
                                fclose(fid);
                                clear IITB_Short_Derep
                            end
                            if ionConNo>0
                                INSM002=unique(INSM001,'rows');
                                INSM002=sortrows(INSM002,1);
                                INSM(1:size(INSM002,1),d3)=INSM002(:,1);
                                ISEC=1;
                            end
                            clear INSM001 INSM002 INSM003
                            if ionConNo>ionConNoMax
                                ionConNoMax=ionConNo;
                            end
                        end
                    end
                    clear TableID
                    
                    if GEC>0
                        TableID=size(GroupIntSum);
                        if size(TableID)==2
                            TableID(1,3)=1;
                        end
                        
                        str= sprintf('%s%s%s','GREPSam',num2str(SamID),'P.txt');
                        fid=fopen(str,'w');
                        for d3=1:TableID(1,3)
                            ionConNo=0;
                            groupNo=0;
                            for d1=1:TableID(1,1)
                                if GroupIntSum(d1,1,d3)>0
                                    groupNo=groupNo+1;
                                end
                            end
                            if groupNo>0
                                fprintf(fid,'%s%s%s%s','Totally ',num2str(groupNo),' groups apparently visible under CoLD G',num2str(d3));
                                fprintf(fid,'\n');
                                for d1=1:TableID(1,1)
                                    if GroupIntSum(d1,1,d3)>0
                                        fprintf(fid,'%d %d ',d1,GroupIntSum(d1,1,d3));
                                        fprintf(fid,'%.1f ',GroupIntSum(d1,2,d3));
                                        fprintf(fid,'%.1f %.4f ',GroupIntSum(d1,3:4,d3));
                                        fprintf(fid,'\n');
                                    end
                                end
                            end
                            fprintf(fid,'\n');
                        end
                        fclose(fid);
                        clear GroupIntSum
                    end
                    clear IITB_Short INSM001 INSM002
                    
                    if ISEC>0
                        DCLength=size(INSM,1);
                        DCWidth=size(INSM,2);
                    end
                    if ionConNoMax>0
                        for ConID=1:DCWidth
                            XICSNLength=0;
                            for iMat=1:nOfMats
                                if strcmp( Mats(iMat).name(1:3),'Sam')
                                    MaSuMa(1,1)=0;
                                    if SamID<10 && ConID<10
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                                && (strcmp(Mats(iMat).name(9),'P'))...
                                                && strcmp(Mats(iMat).name(10),'.')
                                            MaSuMa(1,1)=1;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID<10
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'P'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=2;
                                        end
                                    end
                                    if SamID>=100 && ConID<10
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'P'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=3;
                                        end
                                    end
                                    if SamID<10 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                                && (strcmp(Mats(iMat).name(10),'P'))...
                                                && strcmp(Mats(iMat).name(11),'.')
                                            MaSuMa(1,1)=4;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'P'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=5;
                                        end
                                    end
                                    if SamID>=100 && ConID>=10 && ConID<100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'P'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=6;
                                        end
                                    end
                                    if SamID<10 && ConID>=100
                                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                                && (strcmp(Mats(iMat).name(11),'P'))...
                                                && strcmp(Mats(iMat).name(12),'.')
                                            MaSuMa(1,1)=7;
                                        end
                                    end
                                    if SamID>=10 && SamID<100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                                && (strcmp(Mats(iMat).name(12),'P'))...
                                                && strcmp(Mats(iMat).name(13),'.')
                                            MaSuMa(1,1)=8;
                                        end
                                    end
                                    if SamID>=100 && ConID>=100
                                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                                && (strcmp(Mats(iMat).name(13),'P'))...
                                                && strcmp(Mats(iMat).name(14),'.')
                                            MaSuMa(1,1)=9;
                                        end
                                    end
                                    if MaSuMa(1,1)>0
                                        data = load(Mats(iMat).name);
                                        Scans=data.Scans;
                                        SDWI=size(Scans,2);
                                        MergeMass=data.Masses;
                                        dataLength=size(MergeMass,1);
                                        MergeData=data.Data;
                                        Timerange=TIRA(ConID,2);
                                        DANW=MergeData;
                                        XIC=zeros(SDWI,2);
                                        METI=Scans(1,:)*Timerange/Scans(1,size(Scans,2));
                                        nCount=0;
                                        for r=1:DCLength
                                            if INSM(r,ConID)>0
                                                for h=MassRange+1:dataLength-MassRange
                                                    if abs(INSM(r,ConID)-MergeMass(h,1))<IMI
                                                        for j=1:SDWI
                                                            XIC(j,1)=METI(1,j);
                                                            XIC(j,2)=sum(DANW(h-MassRange:h+MassRange,j));
                                                        end
                                                        XICSN=XIC;
                                                        HighPoint=max(XICSN(:,2));
                                                        LowPoint=min(XICSN(:,2));
                                                        SETINo=100;
                                                        Incre=(HighPoint-LowPoint)/SETINo;
                                                        SETI=zeros(SETINo,3);
                                                        
                                                        for i=1:SETINo
                                                            SETI(i,1)=Incre*(i-1)+LowPoint;
                                                            SETI(i,2)=Incre*i+LowPoint;
                                                            SETI(i,3)=0;
                                                        end
                                                        XICSNLength=size(XICSN,1);
                                                        for j=1:XICSNLength
                                                            for u=1:SETINo
                                                                if XICSN(j,2)>=SETI(u,1) && XICSN(j,2)<SETI(u,2)
                                                                    SETI(u,3)=SETI(u,3)+1;
                                                                end
                                                            end
                                                        end
                                                        chooseSETI=max(SETI(2:SETINo,3));
                                                        for i=2:SETINo
                                                            if SETI(i,3)==chooseSETI
                                                                BASLL=SETI(i,1);
                                                                BASLH=SETI(i,2);
                                                            end
                                                        end
                                                        BASLV=0;
                                                        count=0;
                                                        for i=1:XICSNLength
                                                            if XICSN(i,2)>=BASLL && XICSN(i,2)<BASLH
                                                                BASLV=BASLV+XICSN(i,2);
                                                                count=count+1;
                                                            end
                                                        end
                                                        BASLV=BASLV/count;
                                                        XICSN=XICSN';
                                                        FDTH=round(TIRA(ConID,2)*2.5*log10(SDWI));
                                                        AWTH=size(XICSN,2);
                                                        TIOR=round(AWTH/FDTH);
                                                        if TIOR>=1
                                                            iCol=0;
                                                            for k=1:TIOR:AWTH-TIOR
                                                                iCol=iCol+1;
                                                                XICSN_New(2,iCol)=sum(XICSN(2,k:k+TIOR-1));
                                                                XICSN_New(1,iCol)=0.5*(XICSN(1,k)+XICSN(1,k+TIOR-1));
                                                            end
                                                        else
                                                            TIOR2=round(FDTH/AWTH);
                                                            iCol=TIOR2*AWTH;
                                                            for o=1:SDWI
                                                                XICSN_New(1,o*TIOR2-TIOR2+1:o*TIOR2)=XICSN(1,o);
                                                                XICSN_New(2,o*TIOR2-TIOR2+1:o*TIOR2)=XICSN(2,o);
                                                            end
                                                        end
                                                        
                                                        XICSN_New=XICSN_New';
                                                        fr = FDTH/16;
                                                        dt = (16/FDTH)^2;
                                                        rick = ricker(FDTH,fr,dt,20);
                                                        rick_smooth = getSmoothRicker(rick);
                                                        SXIC0  = conv( rick_smooth(:,1),XICSN_New(:,2) );
                                                        SXIC(:,1)=XICSN_New(:,1);
                                                        SXIC(:,2)=SXIC0( round(length(rick_smooth)/2)+1:length(XICSN_New(:,2))+round(length(rick_smooth)/2));
                                                        SXICLength=size(SXIC,1);
                                                        PTSD=0.01;
                                                        PPGSN=0;
                                                        HighPoint=max(SXIC(:,2));
                                                        for i=2:SXICLength-1
                                                            if SXIC(i,2)>=SXIC(i-1,2) && SXIC(i,2)>=SXIC(i+1,2) && SXIC(i,2)> HighPoint*PTSD && (SXIC(i,2)-SXIC(i-1,2))+(SXIC(i,2)-SXIC(i+1,2))~=0
                                                                PPGSN=PPGSN+1;
                                                                PPGS(PPGSN,1) = SXIC(i,1);
                                                                PPGS(PPGSN,2) = SXIC(i,2);
                                                            end;
                                                        end;
                                                        
                                                        BASLT=0.01;
                                                        NPIR=0;
                                                        
                                                        if PPGSN>0
                                                            for m=1:PPGSN
                                                                PTI=PPGS(m,1);
                                                                PHT=PPGS(m,2);
                                                                PPSN(1,1)=PPGS(m,1);
                                                                PPSN(1,2)=PPGS(m,2);
                                                                halfPH=PHT/2;
                                                                
                                                                for z=1:SXICLength
                                                                    if SXIC(z,1)==PTI
                                                                        PP=z;
                                                                    end;
                                                                end;
                                                                
                                                                vbv1=0;
                                                                for z=PP:-1:2
                                                                    if SXIC(z,2)>=0 && SXIC(z-1,2)<=0 && vbv1==0
                                                                        CZTL=SXIC(z,1);
                                                                        LeftID=z;
                                                                        vbv1=1;
                                                                    end;
                                                                end;
                                                                
                                                                if vbv1==0
                                                                    CZTL=0;
                                                                    LeftID=1;
                                                                end;
                                                                
                                                                vbv2=0;
                                                                for z=PP:SXICLength-1
                                                                    if SXIC(z,2)>=0 && SXIC(z+1,2)<=0 && vbv2==0
                                                                        CZTR=SXIC(z,1);
                                                                        RightID=z;
                                                                        vbv2=1;
                                                                    end;
                                                                end;
                                                                
                                                                if vbv2==0
                                                                    CZTR=SXIC(SXICLength,1);
                                                                    RightID=SXICLength;
                                                                end;
                                                                
                                                                PPGS(m,3)=CZTL;
                                                                PPGS(m,4)=CZTR;
                                                                PPGS(m,5)=(CZTR-CZTL)/TIRA(ConID,2);
                                                                PPGS(m,6)=PHT/HighPoint;
                                                                PPGS(m,7)=PPGS(m,6)/PPGS(m,5);
                                                                
                                                                
                                                                if LeftID>1 && RightID<SXICLength
                                                                    PPGS(m,8)=0;
                                                                    for z=LeftID:RightID
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                                if LeftID==1 && RightID<SXICLength
                                                                    PPGS(m,8)=(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                                    for z=2:RightID
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                                if LeftID>1 && RightID==SXICLength
                                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                                    for z=LeftID:RightID-1
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                                
                                                                if LeftID==1 && RightID==SXICLength
                                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                                    PPGS(m,8)=PPGS(m,8)+(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                                    for z=2:SXICLength-1
                                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                                    end
                                                                end
                                                            end;
                                                            
                                                            PPGSST(1,:)=PPGS(1,:);
                                                            nPPShort=1;
                                                            for z=1:PPGSN
                                                                if PPGS(z,1)-PPGSST(nPPShort,1)<TimeDIFFTor
                                                                    if PPGS(z,2)>PPGSST(nPPShort,2)
                                                                        PPGSST(nPPShort,1)=PPGS(z,1);
                                                                        PPGSST(nPPShort,2)=PPGS(z,2);
                                                                    end;
                                                                    if PPGS(z,3)>PPGSST(nPPShort,3)
                                                                        PPGSST(nPPShort,3)=PPGS(z,3);
                                                                    end;
                                                                    if PPGS(z,4)<PPGSST(nPPShort,4)
                                                                        PPGSST(nPPShort,4)=PPGS(z,4);
                                                                    end;
                                                                    PPGSST(nPPShort,5)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))/TIRA(ConID,2);
                                                                    PPGSST(nPPShort,6)=PPGSST(nPPShort,2)/HighPoint;
                                                                    PPGSST(nPPShort,7)=PPGSST(nPPShort,6)/PPGSST(nPPShort,5);
                                                                    PPGSST(nPPShort,8)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))*PPGSST(nPPShort,2)/2;
                                                                else
                                                                    nPPShort=nPPShort+1;
                                                                    PPGSST(nPPShort,:)=PPGS(z,:);
                                                                end;
                                                            end;
                                                            
                                                            LargestPeak=max(PPGSST(:,8));
                                                            
                                                            PPGSST(:,9)=PPGSST(:,8)/LargestPeak;
                                                            
                                                            nPeakRange=0;
                                                            for z=1:nPPShort
                                                                if PPGSST(z,9)>RelArea
                                                                    nPeakRange=nPeakRange+1;
                                                                    PeakRange(nPeakRange,:)=PPGSST(z,:);
                                                                end
                                                            end
                                                            
                                                            clear PPGS PPGSST ...
                                                                width PPSN XICSN_New;
                                                        end;
                                                        clear XIC SXIC SETI;
                                                        
                                                        
                                                        if nPeakRange<PXSet
                                                            XICSN=XICSN';
                                                            
                                                            for i=1:XICSNLength
                                                                if XICSN(i,2)>BASLV
                                                                    AMP=abs(1/log10(XICSN(i,2)/BASLV))^0.2;
                                                                    XICSN(i,2)=XICSN(i,2)*AMP*(XICSN(i,2)/BASLV)-BASLV;
                                                                else
                                                                    XICSN(i,2)=0;
                                                                end
                                                            end
                                                            nCount=nCount+1;
                                                            MassInfor(1,nCount)=INSM(r,ConID);
                                                            
                                                            
                                                            for j=1:SDWI
                                                                XICSNSummary(j,1)=XICSN(j,1);
                                                                XICSNSummary(j,nCount+1)=XICSN(j,2);
                                                            end
                                                        end
                                                        clear PeakRange
                                                    end
                                                end
                                                clear XIC XICSN SETI
                                            end
                                        end
                                        
                                        if XICSNLength>0
                                            TICAppear=zeros(SDWI,3);
                                            for i=1:SDWI
                                                TICAppear(i,1)=XICSNSummary(i,1);
                                                TICAppear(i,2)=sum(XICSNSummary(i,2:nCount+1));
                                                TICAppear(i,3)=sum(DANW(:,i));
                                            end
                                            TICAppear_Rel(:,1)=TICAppear(:,1);
                                            TICAppear_Rel(:,2)=TICAppear(:,2)./max(TICAppear(:,2));
                                            TICAppear_Rel(:,3)=TICAppear(:,3)./max(TICAppear(:,3));
                                            
                                            str= sprintf('%s%s%s%s%s','TICSSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                            fid=fopen(str,'w');
                                            for u=1:SDWI
                                                for v=1:3
                                                    fprintf(fid,'%.4f ',TICAppear_Rel(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','MassSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                            fid=fopen(str,'w');
                                            for v=1:nCount
                                                fprintf(fid,'%.4f ',MassInfor(1,v));
                                            end
                                            fclose(fid);
                                            
                                            str= sprintf('%s%s%s%s%s','XICSSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                            fid=fopen(str,'w');
                                            for u=1:SDWI
                                                for v=1:nCount+1
                                                    fprintf(fid,'%.4f ',XICSNSummary(u,v));
                                                end
                                                fprintf(fid,'\n');
                                            end
                                            fclose(fid);
                                            
                                            clear TICAppear XICSNSummary MassInfor TICAppear_Rel
                                        end
                                    end
                                end
                            end
                        end
                        clear INSM
                    end
                end
            end
            clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo GroupDIFFTIORControl IMI INTDIFF IRT ...
                IntensityThreshold MB MBLength MIMAssocIons MassDIFF MassDIFFTor Mats ...
                MiMLinearity NosEliDIFF RedundantIons SamID SamNoEn SamNoSt TIRALength ...
                TimeDIFFTor TimeVariance files iFile nOfFiles nOfMats ...
                GRFRSRecord NGP SAFED nFeature Refdata DRLength t0 t00
        end
        clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo GroupDIFFTIORControl IMI INTDIFF IRT ...
            IntensityThreshold MB MBLength MIMAssocIons MassDIFF MassDIFFTor Mats ...
            MiMLinearity NosEliDIFF RedundantIons SamID SamNoEn SamNoSt TIRALength ...
            TimeDIFFTor TimeVariance files iFile nOfFiles nOfMats t0 t00
        
        t01 = cputime-t00;
        disp(['Calculation time = ',num2str(t01), 'Sam', num2str(SamID) ]);
    end
    t01=cputime-t00;
    disp(['hold on... Calculation time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    SlopeDIFFTolerance=0.05;
    IntersectDIFFTolerance=0.1;
    IsotopeVariance=0.2;
    MaxIsotopeTIOR=0.95;
    MiMRep=3;
    files = dir(fullfile('.', '*.txt'));
    [nOfFiles,~] = size(files);
    load Mobile_Phase.txt
    MB=Mobile_Phase;
    MBLength=size(MB,1);
    MBWidth=size(MB,2);
    ConsideredCoLDNo=ConNo-MiMRep+1;
    for u=2:MBWidth
        WTVOL=0;
        for u1=1:MBLength-1
            WTVOL=WTVOL+MB(u1+1,u)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,u)-MB(u1,u))*(MB(u1+1,1)-MB(u1,1));
        end
        WTVOLArrayTemp(u-1,1)=u-1;
        WTVOLArrayTemp(u-1,2)=WTVOL;
    end
    WTVOLArrayTemp=sortrows(WTVOLArrayTemp,2);
    SlowestID(1:ConsideredCoLDNo,1)=WTVOLArrayTemp(1:ConsideredCoLDNo,1);
    SlowestID=SlowestID';
    clear WTVOLArrayTemp
    for SamID=SamNoSt:SamNoEn
        new_folder=['IDP_HILIC_Sam',num2str(SamID)];
        mkdir(new_folder)
        
        AddedLength=0;
        
        for SlowestIDNo=1:ConsideredCoLDNo
            ConID=SlowestID(1,SlowestIDNo);
            GINFCode=0;
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:4),'GINF'))
                    MaSuGI(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'N')
                            MaSuGI(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuGI(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuGI(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuGI(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuGI(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuGI(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuGI(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuGI(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'N')
                            MaSuGI(1,1)=9;
                        end
                    end
                    if MaSuGI(1,1)>0
                        GISumTemp=load(files(iFile).name);
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),1)=ConID;
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),2:size(GISumTemp,2)+1)=GISumTemp;
                        GINFCode=1;
                    end
                end
            end
            if GINFCode==1
                for iFile=1:nOfFiles
                    if (strcmp(files(iFile).name(1:4),'DENO'))
                        MaSuDN(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                    && strcmp(files(iFile).name(13),'N')
                                MaSuDN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                    && strcmp(files(iFile).name(14),'N')
                                MaSuDN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=3;
                            end
                        end
                        if SamID<10 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                    && strcmp(files(iFile).name(14),'N')
                                MaSuDN(1,1)=4;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=5;
                            end
                        end
                        if SamID>=100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                    && strcmp(files(iFile).name(16),'N')
                                MaSuDN(1,1)=6;
                            end
                        end
                        if SamID<10 && ConID>=100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=7;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                    && strcmp(files(iFile).name(16),'N')
                                MaSuDN(1,1)=8;
                            end
                        end
                        if SamID>=100 && ConID>=100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                    && strcmp(files(iFile).name(17),'N')
                                MaSuDN(1,1)=9;
                            end
                        end
                        if MaSuDN(1,1)>0
                            IntSumTemp=load(files(iFile).name);
                            for u=AddedLength+1:AddedLength+size(GISumTemp,1)
                                OiO=0;
                                for z=1:size(IntSumTemp,1)
                                    if abs(GISumTemp2(u,7)-IntSumTemp(z,1))<=MassDIFFTor && ...
                                            abs(GISumTemp2(u,3)-IntSumTemp(z,2))<TimeDIFFTor*4
                                        if GISumTemp2(u,8)==IntSumTemp(z,10);
                                            OiO=OiO+1;
                                            Temp_OiO(OiO,1)=abs(GISumTemp2(u,7)-IntSumTemp(z,1));
                                            Temp_OiO(OiO,2)=abs(GISumTemp2(u,3)-IntSumTemp(z,2));
                                            Temp_OiO(OiO,3)=IntSumTemp(z,11);
                                            Temp_OiO(OiO,4)=IntSumTemp(z,2);
                                        end
                                    end
                                end
                                if OiO>0
                                    Temp_OiO=sortrows(Temp_OiO,-3);
                                    GISumTemp2(u,3)=Temp_OiO(1,4);
                                    GISumTemp2(u,8)=Temp_OiO(1,3);
                                else
                                    GISumTemp2(u,8)=0;
                                end
                            end
                            AddedLength=AddedLength+size(GISumTemp,1);
                            clear GISumTemp
                        end
                    end
                end
            end
        end
        if AddedLength>0
            GISumTemp2=sortrows(GISumTemp2,[1,7]);
            GISumTemp3=GISumTemp2;
            clear GISumTemp2
            nGISumTemp2=0;
            for h=1:size(GISumTemp3,1)
                ASTM=0.1:0.1:100;
                ASTM=ASTM';
                solutionCount=0;
                for o=1:size(ASTM,1)
                    tR=ASTM(o,1);
                    for ut=2:MBLength
                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                            TIORH2O=(tR-MB(ut-1,1))*((MB(ut,GISumTemp3(h,1)+1)-MB(ut-1,GISumTemp3(h,1)+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,GISumTemp3(h,1)+1);
                            u0=ut;
                            WTVOL=0;
                            for u1=1:u0-1
                                WTVOL=WTVOL+MB(u1+1,GISumTemp3(h,1)+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,GISumTemp3(h,1)+1)-MB(u1,GISumTemp3(h,1)+1))*(MB(u1+1,1)-MB(u1,1));
                            end
                            WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,GISumTemp3(h,1)+1)+(MB(u0,GISumTemp3(h,1)+1)-TIORH2O)*(MB(u0,1)-tR);
                            WTVOL=WTVOL/100;
                            TWVOL(1,GISumTemp3(h,1))=tR-WTVOL;
                            TIORStrong=log10(WTVOL/tR);
                        end
                    end
                    
                    tR0=10^((TIORStrong-GISumTemp3(h,5))/GISumTemp3(h,4));
                    if abs(tR-tR0)<TimeDIFFTor*4
                        solutionCount=solutionCount+1;
                        STSET(solutionCount,1)=tR;
                        STSET(solutionCount,3)=abs(tR-tR0);
                        STSET(solutionCount,2)=TIORStrong;
                    end
                end
                for o=1:solutionCount
                    if STSET(o,3)==min(STSET(:,3))
                        GISumTemp3(h,9)=STSET(o,1);
                        if abs(GISumTemp3(h,9)-GISumTemp3(h,3))<TimeDIFFTor*2
                            nGISumTemp2=nGISumTemp2+1;
                            GISumTemp2(nGISumTemp2,1:8)=GISumTemp3(h,1:8);
                        end
                    end
                end
                clear STSET
            end
            clear GISumTemp3
        end
        
        t01=cputime-t00;
        disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
        if AddedLength>0
            RTBR(:,1:3)=GISumTemp2(:,4:6);
            SBHR=unique(RTBR,'rows');
            SBHR=sortrows(SBHR,3);
            for s=1:size(SBHR,1)
                ASTM=0.1:0.1:100;
                ASTM=ASTM';
                solutionCount=0;
                for o=1:size(ASTM,1)
                    tR=ASTM(o,1);
                    for ut=2:MBLength
                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                            TIORH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                            u0=ut;
                            WTVOL=0;
                            for u1=1:u0-1
                                WTVOL=WTVOL+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                            end
                            WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-TIORH2O)*(MB(u0,1)-tR);
                            WTVOL=WTVOL/100;
                            TWVOL(1,1)=tR-WTVOL;
                            TIORStrong=log10(WTVOL/tR);
                        end
                    end
                    
                    tR0=10^((TIORStrong-SBHR(s,2))/SBHR(s,1));
                    
                    solutionCount=solutionCount+1;
                    STSET(solutionCount,1)=tR;
                    STSET(solutionCount,3)=abs(tR-tR0);
                    STSET(solutionCount,2)=TIORStrong;
                end
                for o=1:solutionCount
                    if STSET(o,3)==min(STSET(:,3))
                        SBHR(s,4)=STSET(o,1);
                    end
                end
                clear STSET
            end
            nDSBehavior=1;
            SP=0;
            WidthCode=zeros(size(SBHR,1),1);
            for z=1:size(SBHR,1)
                if SBHR(z,3)>=MiMLinearity-0.05 && SP==0
                    DSBehavior(nDSBehavior,1:3)=SBHR(z,1:3);
                    z1=z;
                    SP=1;
                    WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                    BHTI(nDSBehavior,1)=SBHR(z,4);
                end
            end
            if size(SBHR,1)>1
                for z=z1+1:size(SBHR,1)
                    if SBHR(z,3)>=MiMLinearity-0.05
                        Rep=0;
                        for u=1:nDSBehavior
                            for v=1:3:WidthCode(u,1)-1
                                if abs(SBHR(z,1)-DSBehavior(u,v))<SlopeDIFFTolerance ...
                                        && abs(SBHR(z,2)-DSBehavior(u,v+1))<IntersectDIFFTolerance...
                                        && Rep==0
                                    if max(BHTI(nDSBehavior,:))<2*t0
                                        TimeDIFF=TimeDIFFTor/2;
                                    else
                                        TimeDIFF=TimeDIFFTor;
                                    end
                                    
                                    BHTITemp=BHTI(u,:)';
                                    BTT1=sortrows(BHTITemp,1);
                                    for m=1:size(BTT1,1)
                                        if BTT1(m,1)~=0
                                            minTime=BTT1(m,1);
                                            break
                                        end
                                    end
                                    
                                    if abs(SBHR(z,4)-max(BHTI(u,:)))<=TimeDIFF*2 ...
                                            && abs(SBHR(z,4)-minTime)<=TimeDIFF*2
                                        DSBehavior(u,WidthCode(u,1)+1:WidthCode(u,1)+3)=SBHR(z,1:3);
                                        WidthCode(u,1)=WidthCode(u,1)+3;
                                        Rep=1;
                                        BHTI(u,WidthCode(u,1)/3)=SBHR(z,4);
                                    end
                                end
                            end
                        end
                        if Rep==0
                            nDSBehavior=nDSBehavior+1;
                            DSBehavior(nDSBehavior,1:3)=SBHR(z,1:3);
                            WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                            BHTI(nDSBehavior,1)=SBHR(z,4);
                        end
                    end
                end
            end
            nDSBehavior_Extended=0;
            for p=1:nDSBehavior
                nBahavioredRetentionTime=zeros(ConNo,1);
                for v=1:3:size(DSBehavior,2)
                    if DSBehavior(p,v)~=0
                        for q=1:size(GISumTemp2,1)
                            if GISumTemp2(q,4:6)==DSBehavior(p,v:v+2)
                                nBahavioredRetentionTime(GISumTemp2(q,1),1)=nBahavioredRetentionTime(GISumTemp2(q,1),1)+1;
                                BRT_temp(nBahavioredRetentionTime(GISumTemp2(q,1),1),GISumTemp2(q,1))=GISumTemp2(q,3);
                            end
                        end
                    end
                end
                for de=1:size(BRT_temp,2)
                    BRT_temp2=BRT_temp(:,de);
                    BRT_temp3=unique(BRT_temp2,'rows');
                    BRT_temp3=sortrows(BRT_temp3,-1);
                    nBRT_Short3=1;
                    BRT_Short3(nBRT_Short3,1)=BRT_temp3(nBRT_Short3,1);
                    if size(BRT_temp3,1)>1
                        for u=2:size(BRT_temp3,1)
                            if BRT_Short3(nBRT_Short3,1)-BRT_temp3(u,1)>TimeDIFFTor && BRT_temp3(u,1)>0
                                nBRT_Short3=nBRT_Short3+1;
                                BRT_Short3(nBRT_Short3,1)=BRT_temp3(u,1);
                            end
                        end
                    end
                    BRT(1:size(BRT_Short3,1),de)=BRT_Short3(1:size(BRT_Short3,1),1);
                    clear BRT_temp2 BRT_temp3 BRT_Short3
                end
                SeeTime=0;
                for s=1:size(SlowestID,2)
                    for k=1:size(BRT,2)
                        if k==SlowestID(1,s)
                            if BRT(1,k)>0 && SeeTime==0
                                SeeTime=1;
                                if k==SlowestID(1,1)
                                    for z=1:size(BRT,1)
                                        if BRT(z,k)>0
                                            nDSBehavior_Extended=nDSBehavior_Extended+1;
                                            DSBehavior_Extended(nDSBehavior_Extended,1)=BRT(z,k);
                                            DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                            DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                        end
                                    end
                                else
                                    ASTM=0.1:0.1:100;
                                    ASTM=ASTM';
                                    solutionCount=0;
                                    for o=1:size(ASTM,1)
                                        tR=ASTM(o,1);
                                        for ut=2:MBLength
                                            if tR>MB(ut-1,1) && tR<MB(ut,1)
                                                TIORH2O=(tR-MB(ut-1,1))*((MB(ut,k+1)-MB(ut-1,k+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,k+1);
                                                u0=ut;
                                                WTVOL=0;
                                                for u1=1:u0-1
                                                    WTVOL=WTVOL+MB(u1+1,k+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,k+1)-MB(u1,k+1))*(MB(u1+1,1)-MB(u1,1))/2;
                                                end
                                                WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,k+1)+(MB(u0,k+1)-TIORH2O)*(MB(u0,1)-tR)/2;
                                                WTVOL=WTVOL/100;
                                                TWVOL(1,k)=tR-WTVOL;
                                                TIORStrong=log10(WTVOL/tR);
                                            end
                                        end
                                        tR0=10^((TIORStrong-DSBehavior(p,2))/DSBehavior(p,1));
                                        if abs(tR-tR0)<TimeDIFFTor*4
                                            solutionCount=solutionCount+1;
                                            STSET(solutionCount,1)=tR;
                                            STSET(solutionCount,3)=abs(tR-tR0);
                                            STSET(solutionCount,2)=TIORStrong;
                                        end
                                    end
                                    if solutionCount>0
                                        for o=1:solutionCount
                                            if STSET(o,3)==min(STSET(:,3))
                                                nDSBehavior_Extended=nDSBehavior_Extended+1;
                                                DSBehavior_Extended(nDSBehavior_Extended,1)=STSET(o,1);
                                                DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                                DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                            end
                                        end
                                    end
                                    clear STSET
                                end
                            end
                        end
                    end
                end
                
                clear BRT clear BRT_temp
            end
            t01=cputime-t00;
            disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            Error_Tor=0.05;
            DSBehavior_Extended=sortrows(DSBehavior_Extended,1);
            DSBehavior_Extended_Temp=DSBehavior_Extended;
            clear DSBehavior_Extended;
            nDSBehavior_Extended=1;
            DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
                DSBehavior_Extended_Temp(1,1:size(DSBehavior_Extended_Temp,2));
            nSLVW1=0;
            for v=3:3:size(DSBehavior_Extended,2);
                if DSBehavior_Extended(nDSBehavior_Extended,v)~=0;
                    nSLVW1=nSLVW1+1;
                    SLVW1(nSLVW1,1:2)=DSBehavior_Extended(nDSBehavior_Extended,1:2);
                    SLVW1(nSLVW1,3:5)=DSBehavior_Extended(nDSBehavior_Extended,v:v+2);
                end
            end
            SLVW1=sortrows(SLVW1,3);
            for z=2:size(DSBehavior_Extended_Temp,1)
                nSLVW2=0;
                for v=3:3:size(DSBehavior_Extended_Temp,2);
                    if DSBehavior_Extended_Temp(z,v)~=0;
                        nSLVW2=nSLVW2+1;
                        SLVW2(nSLVW2,1:2)=DSBehavior_Extended_Temp(z,1:2);
                        SLVW2(nSLVW2,3:5)=DSBehavior_Extended_Temp(z,v:v+2);
                    end
                end
                SLVW2=sortrows(SLVW2,3);
                
                if max(SLVW1(:,1))*(1+Error_Tor)>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor) && ...
                        min(SLVW1(:,1))*(1+Error_Tor)+TimeDIFFTor*4>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor)
                    SLVW=[SLVW1;SLVW2];
                    SLVW=sortrows(SLVW,3);
                    clear SLVW1
                    SLVW1=SLVW;
                    nSLVW1=size(SLVW,1);
                    clear SLVW
                    DSBehavior_Extended(nDSBehavior_Extended,1:2)=SLVW1(1,1:2);
                    
                    for v=1:nSLVW1
                        if v~=1
                            vot=0;
                            for o=3:3:size(DSBehavior_Extended,2)
                                if SLVW1(v,3)==DSBehavior_Extended(nDSBehavior_Extended,o) && ...
                                        SLVW1(v,4)==DSBehavior_Extended(nDSBehavior_Extended,o+1) && ...
                                        SLVW1(v,5)==DSBehavior_Extended(nDSBehavior_Extended,o+2)
                                    vot=1;
                                end
                            end
                            if vot==0
                                nRow=nRow+1;
                                DSBehavior_Extended(nDSBehavior_Extended,2+3*nRow-2:2+3*nRow)=SLVW1(v,3:5);
                            end
                        else
                            DSBehavior_Extended(nDSBehavior_Extended,2+3*v-2:2+3*v)=SLVW1(v,3:5);
                            nRow=v;
                        end
                    end
                else
                    nDSBehavior_Extended=nDSBehavior_Extended+1;
                    DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
                        DSBehavior_Extended_Temp(z,1:size(DSBehavior_Extended_Temp,2));
                    clear SLVW1
                    SLVW1=SLVW2;
                    nSLVW1=nSLVW2;
                end
                clear SLVW2
            end
            clear DSBehavior_Extended_Temp;
            
            IonNumber=zeros(nDSBehavior_Extended,1);
            if nDSBehavior_Extended>0
                for p=1:nDSBehavior_Extended
                    for v=3:3:size(DSBehavior_Extended,2)
                        for q=1:size(GISumTemp2,1)
                            if (abs(DSBehavior_Extended(p,1)-GISumTemp2(q,3))<TimeDIFFTor*8 && GISumTemp2(q,1)==SlowestID(1,1)) ||...
                                    (GISumTemp2(q,1)~=SlowestID(1,1))
                                if GISumTemp2(q,4)==DSBehavior_Extended(p,v) && ...
                                        GISumTemp2(q,5)==DSBehavior_Extended(p,v+1) && ...
                                        GISumTemp2(q,6)==DSBehavior_Extended(p,v+2)
                                    
                                    IonNumber(p,1)=IonNumber(p,1)+1;
                                    INSM(IonNumber(p,1),1:size(GISumTemp2,2),p)=GISumTemp2(q,:);
                                    INSM(IonNumber(p,1),1+size(GISumTemp2,2),p)=p;
                                end
                            end
                        end
                    end
                end
                nINSMShort=0;
                for p=1:nDSBehavior_Extended
                    if INSM(1,1,p)>0
                        nINSMShort=nINSMShort+1;
                        INSMShort(:,:,nINSMShort)=INSM(:,:,p);
                    end
                end
                clear INSM
                INSM=INSMShort;
            end
            t01=cputime-t00;
            disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            
            if sum(IonNumber(:,1))>0
                for z=1:nDSBehavior_Extended
                    nIonDerep=1;
                    INSMDerepTemp(nIonDerep,:)=INSM(1,:,z);
                    if size(INSM,1)>1
                        for u=2:size(INSM,1)
                            if INSM(u,7,z)>0
                                if abs(INSM(u,7,z)-INSMDerepTemp(nIonDerep,7))<=MassDIFFTor
                                    if INSM(u,8,z)>INSMDerepTemp(nIonDerep,8)
                                        INSMDerepTemp(nIonDerep,:)=INSM(u,:,z);
                                    end
                                else
                                    nIonDerep=nIonDerep+1;
                                    INSMDerepTemp(nIonDerep,:)=INSM(u,:,z);
                                end
                            end
                        end
                    end
                    INSMDerep(1:nIonDerep,1:9,z)=INSMDerepTemp(1:nIonDerep,1:9);
                    clear INSMDerepTemp
                end
                
                clear IonNumber
                
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
                nINSMTS=1;
                INSMTS(1:size(INSMDerep,1),1,nINSMTS)=INSMDerep(1:size(INSMDerep,1),1,1);
                INSMTS(1:size(INSMDerep,1),2:8,nINSMTS)=INSMDerep(1:size(INSMDerep,1),3:9,1);
                if nDSBehavior_Extended>1
                    for g=2:nDSBehavior_Extended
                        Tereplicate=0;
                        Replicate=0;
                        for h=1:nINSMTS
                            if abs(INSMTS(1,2,h)-INSMDerep(1,3,g))<TimeDIFFTor && INSMTS(1,2,h)*INSMDerep(1,3,g)~=0
                                Tereplicate=1;
                                Tereplicate_hit=0;
                                for u1=1:size(INSMDerep,1)
                                    if INSMDerep(u1,7,g)~=0
                                        vot=0;
                                        for u2=1:size(INSMTS,1)
                                            if abs(INSMDerep(u1,7,g)-INSMTS(u2,6,h))<MassDIFFTor
                                                vot=1;
                                            end
                                        end
                                        if vot==0
                                            Tereplicate_hit=1;
                                        end
                                    end
                                end
                                Tereplicate_hot=0;
                                for u1=1:size(INSMTS,1)
                                    if INSMDerep(u2,7,g)~=0
                                        vot=0;
                                        for u2=1:size(INSMDerep,1)
                                            if abs(INSMDerep(u2,7,g)-INSMTS(u1,6,h))<MassDIFFTor
                                                vot=1;
                                            end
                                        end
                                        if vot==0
                                            Tereplicate_hot=1;
                                        end
                                    end
                                end
                                if Tereplicate_hit==0
                                    Replicate=1;
                                    if Tereplicate_hot==1
                                        Replicate=2;
                                        h_Code=h;
                                    end
                                end
                            end
                        end
                        if Tereplicate==1
                            if Replicate==0
                                nINSMTS=nINSMTS+1;
                                INSMTS(1:size(INSMDerep,1),1,nINSMTS)=INSMDerep(1:size(INSMDerep,1),1,g);
                                INSMTS(1:size(INSMDerep,1),2:8,nINSMTS)=INSMDerep(1:size(INSMDerep,1),3:9,g);
                            else if Replicate==2
                                    INSMTS(1:size(INSMDerep,1),1,h_Code)=INSMDerep(1:size(INSMDerep,1),1,g);
                                    INSMTS(1:size(INSMDerep,1),2:8,h_Code)=INSMDerep(1:size(INSMDerep,1),3:9,g);
                                end
                            end
                        end
                        
                        if Tereplicate==0
                            nINSMTS=nINSMTS+1;
                            INSMTS(1:size(INSMDerep,1),1,nINSMTS)=INSMDerep(1:size(INSMDerep,1),1,g);
                            INSMTS(1:size(INSMDerep,1),2:8,nINSMTS)=INSMDerep(1:size(INSMDerep,1),3:9,g);
                        end
                        
                    end
                end
                for GroupID=1:size(INSMTS,3)
                    TimeTableTemp(GroupID,1)=INSMTS(1,2,GroupID);
                    TimeTableTemp(GroupID,2)=0;
                end
                TimeTableTemp=sortrows(TimeTableTemp,1);
                for TTT=1:size(INSMTS,3)
                    for GroupID=1:size(INSMTS,3)
                        if TimeTableTemp(TTT,1)==INSMTS(1,2,GroupID) && GroupID~=TimeTableTemp(TTT,2)
                            INSMTS2(:,:,TTT)=INSMTS(:,:,GroupID);
                            TimeTableTemp(TTT,2)=GroupID;
                        end
                    end
                end
                clear INSMTS
                INSMTS=INSMTS2;
                clear INSMTS2 TimeTableTemp
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
                
                
                for GroupID=1:size(INSMTS,3)
                    ConID=INSMTS(1,1,GroupID);
                    for iFile=1:nOfFiles
                        if (strcmp(files(iFile).name(1:4),'DENO'))
                            MaSuDN(1,1)=0;
                            if SamID<10 && ConID<10
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                        && strcmp(files(iFile).name(13),'N')
                                    MaSuDN(1,1)=1;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID<10
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                        && strcmp(files(iFile).name(14),'N')
                                    MaSuDN(1,1)=2;
                                end
                            end
                            if SamID>=100 && ConID<10
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                        && strcmp(files(iFile).name(15),'N')
                                    MaSuDN(1,1)=3;
                                end
                            end
                            if SamID<10 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                        && strcmp(files(iFile).name(14),'N')
                                    MaSuDN(1,1)=4;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                        && strcmp(files(iFile).name(15),'N')
                                    MaSuDN(1,1)=5;
                                end
                            end
                            if SamID>=100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                        && strcmp(files(iFile).name(16),'N')
                                    MaSuDN(1,1)=6;
                                end
                            end
                            if SamID<10 && ConID>=100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                        && strcmp(files(iFile).name(15),'N')
                                    MaSuDN(1,1)=7;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                        && strcmp(files(iFile).name(16),'N')
                                    MaSuDN(1,1)=8;
                                end
                            end
                            if SamID>=100 && ConID>=100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                        && strcmp(files(iFile).name(17),'N')
                                    MaSuDN(1,1)=9;
                                end
                            end
                            if MaSuDN(1,1)>0
                                IntSumTemp=load(files(iFile).name);
                                
                                for r=1:size(INSMTS,1)
                                    OiO=0;
                                    for w=1:size(IntSumTemp,1)
                                        if abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1))<MassDIFFTor
                                            if OiO==0
                                                INSMTS(r,9,GroupID)=IntSumTemp(w,12);
                                                TDSet=abs(INSMTS(r,2,GroupID)-IntSumTemp(w,2));
                                                MDSet=abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1));
                                                IntSet=IntSumTemp(w,11);
                                                OiO=1;
                                                if IntSet>INSMTS(r,7,GroupID)
                                                    INSMTS(r,7,GroupID)=IntSet;
                                                end
                                            else
                                                if abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1))<MDSet
                                                    if INSMTS(r,7,GroupID)>IntSet
                                                        TDSet=abs(INSMTS(r,2,GroupID)-IntSumTemp(w,2));
                                                        MDSet=abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1));
                                                        IntSet=IntSumTemp(w,11);
                                                        INSMTS(r,7,GroupID)=IntSet;
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
                
                nISSM=0;
                for GroupID=1:size(INSMTS,3)
                    nISSM=nISSM+1;
                    
                    INSMTemp=INSMTS(:,:,GroupID);
                    INSMTemp=sortrows(INSMTemp,-7);
                    
                    ISSM(nISSM,1:3)=DSBehavior_Extended(INSMTemp(1,8),3:5);
                    
                    ASTM=0.1:0.1:100;
                    ASTM=ASTM';
                    solutionCount=0;
                    for o=1:size(ASTM,1)
                        tR=ASTM(o,1);
                        for ut=2:MBLength
                            if tR>MB(ut-1,1) && tR<MB(ut,1)
                                TIORH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                                u0=ut;
                                WTVOL=0;
                                for u1=1:u0-1
                                    WTVOL=WTVOL+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                                end
                                WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-TIORH2O)*(MB(u0,1)-tR);
                                WTVOL=WTVOL/100;
                                TWVOL(1,1)=tR-WTVOL;
                                TIORStrong=log10(WTVOL/tR);
                            end
                        end
                        
                        tR0=10^((TIORStrong-ISSM(nISSM,2))/ISSM(nISSM,1));
                        solutionCount=solutionCount+1;
                        STSET(solutionCount,1)=tR;
                        STSET(solutionCount,3)=abs(tR-tR0);
                        STSET(solutionCount,2)=TIORStrong;
                    end
                    if solutionCount>0
                        for o=1:solutionCount
                            if STSET(o,3)==min(STSET(:,3))
                                ISSM(nISSM,4)=STSET(o,1);
                            end
                        end
                    end
                    clear STSET
                    ISSM(nISSM,5)=0;
                    IntThreshold=0.8;
                    nIon=0;
                    for z=1:size(INSMTemp,1)
                        if INSMTemp(z,7)/max(INSMTemp(:,7))>=IntThreshold
                            ISSM(nISSM,5)=ISSM(nISSM,5)+INSMTemp(z,7);
                            nIon=nIon+1;
                        end
                    end
                    ISSM(nISSM,5)=ISSM(nISSM,5)/nIon;
                    ISSM(nISSM,6)=INSMTemp(1,9);
                    nCount=1;
                    nCountRem=0;
                    ISSM(nISSM,6+nCount)=INSMTemp(1,6);
                    if size(INSMTS,1)>1
                        for u=2:size(INSMTS,1)
                            if INSMTemp(u,9)>0
                                if abs(INSMTemp(u,9)-ISSM(nISSM,6))<0.2
                                    vot=0;
                                    for z=1:nCount
                                        if abs(INSMTemp(u,6)-ISSM(nISSM,6+z))<IMI
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        nCount=nCount+1;
                                        ISSM(nISSM,6+nCount)=INSMTemp(u,6);
                                    end
                                else if INSMTemp(u,9)>0
                                        nCountRem=nCountRem+1;
                                        IsoTempRem(nCountRem,:)=INSMTemp(u,:);
                                    end
                                end
                            end
                        end
                        if nCountRem>0
                            nISSM=nISSM+1;
                            ISSM(nISSM,6)=IsoTempRem(1,9);
                            nCountRemPlus=1;
                            ISSM(nISSM,6+nCountRemPlus)=IsoTempRem(1,6);
                            for u=1:nCountRem
                                vot=0;
                                for z=1:nCountRemPlus
                                    if abs(IsoTempRem(u,6)-ISSM(nISSM,6+z))<IMI
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    nCountRemPlus=nCountRemPlus+1;
                                    ISSM(nISSM,6+nCountRemPlus)=IsoTempRem(u,6);
                                end
                            end
                            clear IsoTempRem
                        end
                    end
                    clear INSMTemp
                end
                MostAbundantIon=max(ISSM(:,5));
                ISSM(:,5)=ISSM(:,5)./MostAbundantIon;
                
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
                
                
                nMassList=0;
                for u=1:size(ISSM,1)
                    for v=7:size(ISSM,2)
                        if ISSM(u,v)>0
                            nMassList=nMassList+1;
                            MassList(nMassList,1)=ISSM(u,v);
                            MassList(nMassList,3)=ISSM(u,6);
                            if ISSM(u,4)>0
                                MassList(nMassList,2)=ISSM(u,4);
                            else
                                MassList(nMassList,2)=ISSM(u-1,4);
                            end
                        end
                    end
                end
                
                for iUV=1:nOfFiles
                    MaSuUV(1,1)=0;
                    if (strcmp(files(iUV).name(1:3),'Sam'))
                        if SamID<10
                            if str2double(files(iUV).name(4))==SamID && str2double(files(iUV).name(8))==SlowestID(1,1) && ...
                                    strcmp(files(iUV).name(9),'.')
                                MaSuUV(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100
                            if str2double(files(iUV).name(4:5))==SamID && str2double(files(iUV).name(9))==SlowestID(1,1) && ...
                                    strcmp(files(iUV).name(10),'.')
                                MaSuUV(1,1)=2;
                            end
                        end
                        if SamID>=100
                            if str2double(files(iUV).name(4:6))==SamID && str2double(files(iUV).name(10))==SlowestID(1,1) && ...
                                    strcmp(files(iUV).name(11),'.')
                                MaSuUV(1,1)=3;
                            end
                        end
                        if MaSuUV(1,1)>0
                            UVTemp=load(files(iUV).name);
                            TIRA=UVTemp(size(UVTemp,1),1);
                        end
                    end
                end
                for iMat=1:nOfMats
                    if strcmp( Mats(iMat).name(1:3),'Sam')
                        nPISGS=0;
                        
                        MaSuMa(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==SlowestID(1,1)...
                                    && (strcmp(Mats(iMat).name(9),'N'))...
                                    && strcmp(Mats(iMat).name(10),'.')
                                MaSuMa(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==SlowestID(1,1)...
                                    && (strcmp(Mats(iMat).name(10),'N'))...
                                    && strcmp(Mats(iMat).name(11),'.')
                                MaSuMa(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==SlowestID(1,1)...
                                    && (strcmp(Mats(iMat).name(11),'N'))...
                                    && strcmp(Mats(iMat).name(12),'.')
                                MaSuMa(1,1)=3;
                            end
                        end
                        if MaSuMa(1,1)>0
                            data = load(Mats(iMat).name);
                            Scans=data.Scans;
                            SDWI=size(Scans,2);
                            MergeMass=data.Masses;
                            dataLength=size(MergeMass,1);
                            MergeData=data.Data;
                            FDTH=round(TIRA*2.5*log10(SDWI));
                            AWTH=SDWI;
                            TIOR=round(AWTH/FDTH);
                            if TIOR>=1
                                iCol=0;
                                for k=1:TIOR:AWTH-TIOR
                                    iCol=iCol+1;
                                    dataTemp(1:dataLength,1:TIOR)=MergeData(1:dataLength,k:k+TIOR-1);
                                    for o=1:dataLength
                                        DANW(o,iCol)=sum(dataTemp(o,1:TIOR));
                                    end
                                    METI(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+TIOR-1))/Scans(1,SDWI)*TIRA;
                                end
                            else
                                TIOR2=round(FDTH/AWTH);
                                iCol=TIOR2*AWTH;
                                for o=1:SDWI
                                    METI(1,o*TIOR2-TIOR2+1:o*TIOR2)=Scans(1,o)/Scans(1,SDWI)*TIRA;
                                    for k=1:dataLength
                                        DANW(k,o*TIOR2-TIOR2+1:o*TIOR2)=MergeData(k,o);
                                    end
                                end
                            end
                            SDWI=iCol;
                            
                            XIC=zeros(SDWI,2);
                            nPISGS=0;
                            fr = FDTH/16;
                            dt = (16/FDTH)^2;
                            rick = ricker(FDTH,fr,dt,20);
                            rick_smooth = getSmoothRicker(rick);
                            for r=1:nMassList
                                for h=MassRange+1:dataLength-MassRange
                                    if abs(MergeMass(h,1)-MassList(r,1))<MassDIFFTor
                                        for j=1:SDWI
                                            XIC(j,1)=METI(1,j);
                                            XIC(j,2)=sum(DANW(h-MassRange:h+MassRange,j));
                                        end
                                        SXIC0  = conv( rick_smooth(:,1),XIC(:,2) );
                                        SXIC(:,1)=XIC(:,1);
                                        SXIC(:,2)=SXIC0( round(length(rick_smooth)/2)+1:length(XIC(:,2))+round(length(rick_smooth)/2));
                                        SXICLength=size(SXIC,1);
                                        PTSD=0.01;
                                        PPGSN=0;
                                        HighPoint=max(SXIC(:,2));
                                        for i=2:SXICLength-1
                                            if SXIC(i,2)>=SXIC(i-1,2) && SXIC(i,2)>=SXIC(i+1,2) && SXIC(i,2)> HighPoint*PTSD && (SXIC(i,2)-SXIC(i-1,2))+(SXIC(i,2)-SXIC(i+1,2))~=0
                                                PPGSN=PPGSN+1;
                                                PPGS(PPGSN,1) = SXIC(i,1);
                                                PPGS(PPGSN,2) = SXIC(i,2);
                                            end;
                                        end;
                                        
                                        BASLT=0.01;
                                        NPIR=0;
                                        
                                        if PPGSN>0
                                            for m=1:PPGSN
                                                PTI=PPGS(m,1);
                                                PHT=PPGS(m,2);
                                                PPSN(1,1)=PPGS(m,1);
                                                PPSN(1,2)=PPGS(m,2);
                                                halfPH=PHT/2;
                                                
                                                for z=1:SXICLength
                                                    if SXIC(z,1)==PTI
                                                        PP=z;
                                                    end;
                                                end;
                                                
                                                vbv1=0;
                                                for z=PP:-1:2
                                                    if SXIC(z,2)>=0 && SXIC(z-1,2)<=0 && vbv1==0
                                                        CZTL=SXIC(z,1);
                                                        LeftID=z;
                                                        vbv1=1;
                                                    end;
                                                end;
                                                
                                                if vbv1==0
                                                    CZTL=0;
                                                    LeftID=1;
                                                end;
                                                
                                                vbv2=0;
                                                for z=PP:SXICLength-1
                                                    if SXIC(z,2)>=0 && SXIC(z+1,2)<=0 && vbv2==0
                                                        CZTR=SXIC(z,1);
                                                        RightID=z;
                                                        vbv2=1;
                                                    end;
                                                end;
                                                
                                                if vbv2==0
                                                    CZTR=SXIC(SXICLength,1);
                                                    RightID=SXICLength;
                                                end;
                                                
                                                PPGS(m,3)=CZTL;
                                                PPGS(m,4)=CZTR;
                                                PPGS(m,5)=(CZTR-CZTL)/TIRA;
                                                PPGS(m,6)=PHT/HighPoint;
                                                PPGS(m,7)=PPGS(m,6)/PPGS(m,5);
                                                
                                                
                                                if LeftID>1 && RightID<SXICLength
                                                    PPGS(m,8)=0;
                                                    for z=LeftID:RightID
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                if LeftID==1 && RightID<SXICLength
                                                    PPGS(m,8)=(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                    for z=2:RightID
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                if LeftID>1 && RightID==SXICLength
                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                    for z=LeftID:RightID-1
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                
                                                if LeftID==1 && RightID==SXICLength
                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                    PPGS(m,8)=PPGS(m,8)+(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                    for z=2:SXICLength-1
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                            end;
                                            
                                            PPGSST(1,:)=PPGS(1,:);
                                            nPPShort=1;
                                            for z=1:PPGSN
                                                if PPGS(z,1)-PPGSST(nPPShort,1)<TimeDIFFTor
                                                    if PPGS(z,2)>PPGSST(nPPShort,2)
                                                        PPGSST(nPPShort,1)=PPGS(z,1);
                                                        PPGSST(nPPShort,2)=PPGS(z,2);
                                                    end;
                                                    if PPGS(z,3)>PPGSST(nPPShort,3)
                                                        PPGSST(nPPShort,3)=PPGS(z,3);
                                                    end;
                                                    if PPGS(z,4)<PPGSST(nPPShort,4)
                                                        PPGSST(nPPShort,4)=PPGS(z,4);
                                                    end;
                                                    PPGSST(nPPShort,5)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))/TIRA;
                                                    PPGSST(nPPShort,6)=PPGSST(nPPShort,2)/HighPoint;
                                                    PPGSST(nPPShort,7)=PPGSST(nPPShort,6)/PPGSST(nPPShort,5);
                                                    PPGSST(nPPShort,8)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))*PPGSST(nPPShort,2)/2;
                                                else
                                                    nPPShort=nPPShort+1;
                                                    PPGSST(nPPShort,:)=PPGS(z,:);
                                                end;
                                            end;
                                            
                                            LargestPeak=max(PPGSST(:,8));
                                            
                                            PPGSST(:,9)=PPGSST(:,8)/LargestPeak;
                                            
                                            
                                            
                                            if nPPShort>0
                                                for s=1:nPPShort
                                                    if abs(PPGSST(s,1)-MassList(r,2))<TimeDIFFTor*4 && PPGSST(s,9)>RelArea
                                                        if size(MassList,2)==3 || MassList(r,3)==0
                                                            MassList(r,4)=PPGSST(s,1);
                                                            MassList(r,5)=PPGSST(s,8);
                                                            MassList(r,6)=MergeMass(h,1);
                                                            
                                                        else
                                                            if abs(MassList(r,3)-MassList(r,2))>TimeDIFFTor*2
                                                                if abs(PPGSST(s,1)-MassList(r,2))<abs(MassList(r,3)-MassList(r,2))
                                                                    MassList(r,4)=PPGSST(s,1);
                                                                    MassList(r,5)=PPGSST(s,8);
                                                                    MassList(r,6)=MergeMass(h,1);
                                                                end
                                                            else
                                                                if MassList(r,4)<PPGSST(s,8)
                                                                    MassList(r,4)=PPGSST(s,1);
                                                                    MassList(r,5)=PPGSST(s,8);
                                                                    MassList(r,6)=MergeMass(h,1);
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                                
                                                
                                                clear PPGS PPGSST ...
                                                    width PPSN;
                                                
                                            end
                                            
                                            
                                        end
                                        
                                        clear XIC SXIC SETI;
                                    end
                                end
                            end
                        end
                        
                    end
                end
                
                MassList=sortrows(MassList,4);
                
                
                nCRAD_Peaks=0;
                NGP=0;
                NGPedIsomer=0;
                for z=1:size(MassList,1)
                    if MassList(z,4)>0
                        
                        if nCRAD_Peaks==0
                            nCRAD_Peaks=nCRAD_Peaks+1;
                            CRAD_Peaks(nCRAD_Peaks,1)=MassList(z,6);
                            CRAD_Peaks(nCRAD_Peaks,2)=MassList(z,4);
                            CRAD_Peaks(nCRAD_Peaks,3)=MassList(z,5);
                            CRAD_Peaks(nCRAD_Peaks,4)=MassList(z,3);
                        else
                            vot=0;
                            for p=1:nCRAD_Peaks
                                if CRAD_Peaks(p,1)==MassList(z,6) && ...
                                        CRAD_Peaks(p,2)==MassList(z,4)
                                    vot=1;
                                    if CRAD_Peaks(p,4)>MassList(z,3)
                                        CRAD_Peaks(p,4)=MassList(z,3);
                                    end
                                end
                            end
                            if vot==0
                                nCRAD_Peaks=nCRAD_Peaks+1;
                                CRAD_Peaks(nCRAD_Peaks,1)=MassList(z,6);
                                CRAD_Peaks(nCRAD_Peaks,2)=MassList(z,4);
                                CRAD_Peaks(nCRAD_Peaks,3)=MassList(z,5);
                                CRAD_Peaks(nCRAD_Peaks,4)=MassList(z,3);
                            end
                        end
                        
                        if NGPedIsomer==0
                            NGPedIsomer=NGPedIsomer+1;
                            GPIM(NGPedIsomer,:)=MassList(z,:);
                        else
                            if GPIM(NGPedIsomer,2)==MassList(z,2) &&...
                                    MassList(z,4)-GPIM(NGPedIsomer,4)<=TimeDIFFTor
                                NGPedIsomer=NGPedIsomer+1;
                                GPIM(NGPedIsomer,:)=MassList(z,:);
                            else
                                GPIM_short=unique(GPIM,'rows');
                                clear GPIM
                                GPIM=GPIM_short;
                                GPIM=sortrows(GPIM,3);
                                NGPedIsomer=size(GPIM,1);
                                NGP=NGP+1;
                                if NGPedIsomer>1
                                    o=NGPedIsomer;
                                    for k=1:NGPedIsomer-1
                                        if GPIM(k,3)~=GPIM(k+1,3)
                                            o=k;
                                        end
                                    end
                                    if o<NGPedIsomer
                                        GPIM1=GPIM(1:o,1:6);
                                        GPIM1=sortrows(GPIM1,-5);
                                        ISSM2(NGP,6,1)=GPIM1(1,3);
                                        ISSM2(NGP,4,1)=GPIM1(1,4);
                                        ISSM2(NGP,5,1)=0;
                                        for p=1:o
                                            if size(ISSM2,2)>6
                                                vot=0;
                                                for v=7:size(ISSM2,2)
                                                    if ISSM2(NGP,v,1)==GPIM1(p,6)
                                                        vot=1;
                                                    end
                                                end
                                                if vot==0
                                                    ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                                    if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                                    end
                                                end
                                            else
                                                ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                                if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                                    ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                                end
                                            end
                                        end
                                        
                                        GPIM2=GPIM(o+1:NGPedIsomer,1:6);
                                        GPIM2=sortrows(GPIM2,-5);
                                        ISSM2(NGP,6,2)=GPIM2(1,3);
                                        ISSM2(NGP,5,2)=0;
                                        for p=1:NGPedIsomer-o
                                            if size(ISSM2,2)>6
                                                vot=0;
                                                for v=7:size(ISSM2,2)
                                                    if ISSM2(NGP,v,2)==GPIM2(p,6)
                                                        vot=1;
                                                    end
                                                end
                                                if vot==0
                                                    ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                                    if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                                        ISSM2(NGP,5,2)=ISSM2(NGP,5,1)+GPIM2(p,5);
                                                    end
                                                end
                                            else
                                                ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                                if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                                    ISSM2(NGP,5,2)=ISSM2(NGP,5,2)+GPIM2(p,5);
                                                end
                                            end
                                        end
                                        
                                        clear GPIM1 GPIM2
                                    else
                                        GPIM=sortrows(GPIM,-5);
                                        ISSM2(NGP,6,1)=GPIM(1,3);
                                        ISSM2(NGP,4,1)=GPIM(1,4);
                                        ISSM2(NGP,5,1)=0;
                                        for p=1:o
                                            if size(ISSM2,2)>6
                                                vot=0;
                                                for v=7:size(ISSM2,2)
                                                    if ISSM2(NGP,v,1)==GPIM(p,6)
                                                        vot=1;
                                                    end
                                                end
                                                if vot==0
                                                    ISSM2(NGP,6+p,1)=GPIM(p,6);
                                                    if GPIM(p,5)>max(GPIM(:,5))*0.8
                                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                                    end
                                                end
                                            else
                                                ISSM2(NGP,6+p,1)=GPIM(p,6);
                                                if GPIM(p,5)>max(GPIM(:,5))*0.8
                                                    ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                                end
                                            end
                                        end
                                    end
                                    
                                else
                                    ISSM2(NGP,7,1)=GPIM(NGPedIsomer,6);
                                    ISSM2(NGP,6,1)=GPIM(NGPedIsomer,3);
                                    ISSM2(NGP,5,1)=GPIM(NGPedIsomer,5);
                                    ISSM2(NGP,4,1)=GPIM(NGPedIsomer,4);
                                end
                                clear GPIM
                                NGPedIsomer=1;
                                GPIM(NGPedIsomer,:)=MassList(z,:);
                            end
                        end
                    end
                end
                
                if NGPedIsomer>0
                    GPIM_short=unique(GPIM,'rows');
                    clear GPIM
                    GPIM=GPIM_short;
                    GPIM=sortrows(GPIM,3);
                    NGPedIsomer=size(GPIM,1);
                    NGP=NGP+1;
                    if NGPedIsomer>1
                        o=NGPedIsomer;
                        for k=1:NGPedIsomer-1
                            if GPIM(k,3)~=GPIM(k+1,3)
                                o=k;
                            end
                        end
                        if o<NGPedIsomer
                            GPIM1=GPIM(1:o,1:6);
                            GPIM1=sortrows(GPIM1,-5);
                            ISSM2(NGP,6,1)=GPIM1(1,3);
                            ISSM2(NGP,4,1)=GPIM1(1,4);
                            ISSM2(NGP,5,1)=0;
                            for p=1:o
                                if size(ISSM2,2)>6
                                    vot=0;
                                    for v=7:size(ISSM2,2)
                                        if ISSM2(NGP,v,1)==GPIM1(p,6)
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                        if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                            ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                        end
                                    end
                                else
                                    ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                    if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                    end
                                end
                            end
                            
                            GPIM2=GPIM(o+1:NGPedIsomer,1:6);
                            GPIM2=sortrows(GPIM2,-5);
                            ISSM2(NGP,6,2)=GPIM2(1,3);
                            ISSM2(NGP,5,2)=0;
                            for p=1:NGPedIsomer-o
                                if size(ISSM2,2)>6
                                    vot=0;
                                    for v=7:size(ISSM2,2)
                                        if ISSM2(NGP,v,2)==GPIM2(p,6)
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                        if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                            ISSM2(NGP,5,2)=ISSM2(NGP,5,1)+GPIM2(p,5);
                                        end
                                    end
                                else
                                    ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                    if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                        ISSM2(NGP,5,2)=ISSM2(NGP,5,2)+GPIM2(p,5);
                                    end
                                end
                            end
                            
                            clear GPIM1 GPIM2
                        else
                            GPIM=sortrows(GPIM,-5);
                            ISSM2(NGP,6,1)=GPIM(1,3);
                            ISSM2(NGP,4,1)=GPIM(1,4);
                            ISSM2(NGP,5,1)=0;
                            for p=1:o
                                if size(ISSM2,2)>6
                                    vot=0;
                                    for v=7:size(ISSM2,2)
                                        if ISSM2(NGP,v,1)==GPIM(p,6)
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        ISSM2(NGP,6+p,1)=GPIM(p,6);
                                        if GPIM(p,5)>max(GPIM(:,5))*0.8
                                            ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                        end
                                    end
                                else
                                    ISSM2(NGP,6+p,1)=GPIM(p,6);
                                    if GPIM(p,5)>max(GPIM(:,5))*0.8
                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                    end
                                end
                            end
                        end
                        
                    else
                        ISSM2(NGP,7,1)=GPIM(NGPedIsomer,6);
                        ISSM2(NGP,6,1)=GPIM(NGPedIsomer,3);
                        ISSM2(NGP,5,1)=GPIM(NGPedIsomer,5);
                        ISSM2(NGP,4,1)=GPIM(NGPedIsomer,4);
                    end
                    clear GPIM
                end
                
                nISSM3=0;
                if NGP>0
                    for z=1:NGP
                        nISSM3=nISSM3+1;
                        ISSM3(nISSM3,1:size(ISSM2,2))=ISSM2(z,:,1);
                        if ISSM2(z,7,2)>0
                            nISSM3=nISSM3+1;
                            ISSM3(nISSM3,1:size(ISSM2,2))=ISSM2(z,:,2);
                        end
                    end
                end
                
                for iMat=1:nOfMats
                    MaSuTN(1,1)=0;
                    if (strcmp(Mats(iMat).name(1:4),'TDAN'))
                        if SamID<10
                            if str2double(Mats(iMat).name(8))==SamID && strcmp(Mats(iMat).name(9),'N')
                                MaSuTN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(Mats(iMat).name(8:9))==SamID && strcmp(Mats(iMat).name(10),'N')
                                MaSuTN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(Mats(iMat).name(8:10))==SamID && strcmp(Mats(iMat).name(11),'N')
                                MaSuTN(1,1)=3;
                            end
                        end
                        if MaSuTN(1,1)>0
                            data = load(Mats(iMat).name);
                            TDAN=data.TDANBYAbun;
                        end
                    end
                end
                
                for z=1:size(ISSM3,1)
                    if z==1
                        MassTime1(1,1)=ISSM3(z,7);
                        MassTime1(1,2)=ISSM3(z,4);
                        SlopeLine=1;
                        if ISSM3(z+1,4)==0
                            No1=0;
                            for v=7:size(ISSM3,2)
                                if ISSM3(z,v)>0
                                    No1=No1+1;
                                end
                            end
                            No2=0;
                            for v=7:size(ISSM3,2)
                                if ISSM3(z+1,v)>0
                                    No2=No2+1;
                                end
                            end
                            if No2>No1
                                MassTime1(1,1)=ISSM3(z+1,7);
                            end
                            if No2==No1 && ISSM3(z+1,5)>ISSM3(z,5)
                                MassTime1(1,1)=ISSM3(z+1,7);
                            end
                        end
                    end
                    if z>1 && z<size(ISSM3,1) && ISSM3(z,4)~=0
                        MassTime1(1,1)=ISSM3(z,7);
                        MassTime1(1,2)=ISSM3(z,4);
                        SlopeLine=z;
                        if ISSM3(z+1,4)==0
                            if ISSM3(z+1,4)==0
                                No1=0;
                                for v=7:size(ISSM3,2)
                                    if ISSM3(z,v)>0
                                        No1=No1+1;
                                    end
                                end
                                No2=0;
                                for v=7:size(ISSM3,2)
                                    if ISSM3(z+1,v)>0
                                        No2=No2+1;
                                    end
                                end
                                if No2>No1
                                    MassTime1(1,1)=ISSM3(z+1,7);
                                end
                                if No2==No1 && ISSM3(z+1,5)>ISSM3(z,5)
                                    MassTime1(1,1)=ISSM3(z+1,7);
                                end
                            end
                        end
                    end
                    if z==size(ISSM3,1)
                        if ISSM3(z,4)~=0
                            SlopeLine=z;
                            MassTime1(1,1)=ISSM3(z,7);
                            MassTime1(1,2)=ISSM3(z,4);
                        end
                    end
                    
                    nMatch=0;
                    for v=1:size(TDAN,3)
                        MatchTime=0;
                        for w=1:4:size(TDAN,2)
                            for u=1:size(TDAN,1)
                                if abs(MassTime1(1,2)-TDAN(u,w+1,v))>TimeDIFFTor*2 && TDAN(u,w+1,v)~=0 ...
                                        && w==1
                                    MatchTime=MatchTime-0.25;
                                end
                                if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDIFFTor*2
                                    if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDIFFTor*2 && w==1
                                        MatchTime=MatchTime+1;
                                    end
                                    if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                        MatchTime=MatchTime+0.25;
                                    end
                                end
                            end
                        end
                        if MatchTime>0
                            nMatch=nMatch+1;
                            MAMX(nMatch,1)=MatchTime;
                            MAMX(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                            MAMX(nMatch,5)=v;
                        end
                    end
                    if nMatch>0
                        nMatchShort=0;
                        for u=1:nMatch
                            if MAMX(u,1)==max(MAMX(:,1))
                                nMatchShort=nMatchShort+1;
                                MAMXS(nMatchShort,:)=MAMX(u,:);
                            end
                        end
                        
                        MAMXS=sortrows(MAMXS,2);
                        ISSM3(SlopeLine,1:3)=MAMXS(1,2:4);
                        clear MAMX MAMXS
                    else
                        for v=1:size(TDAN,3)
                            MatchTime=0;
                            for w=1:4:size(TDAN,2)
                                for u=1:size(TDAN,1)
                                    if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDIFFTor
                                        if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDIFFTor*8 && w==1
                                            MatchTime=MatchTime+1;
                                        end
                                        if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                            MatchTime=MatchTime+0.25;
                                        end
                                    end
                                end
                            end
                            
                            if MatchTime>0
                                nMatch=nMatch+1;
                                MAMX(nMatch,1)=MatchTime;
                                MAMX(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                                MAMX(nMatch,5)=v;
                            end
                        end
                        if nMatch>0
                            nMatchShort=0;
                            for u=1:nMatch
                                if MAMX(u,1)==max(MAMX(:,1))
                                    nMatchShort=nMatchShort+1;
                                    MAMXS(nMatchShort,:)=MAMX(u,:);
                                end
                            end
                            MAMXS=sortrows(MAMXS,2);
                            ISSM3(SlopeLine,1:2)=MAMXS(1,2:3);
                            clear MAMX MAMXS
                        end
                    end
                end
                
                nISSM4=0;
                for z=1:size(ISSM3,1)
                    if ISSM3(z,3)==0 && ISSM3(z,4)~=0
                        if ISSM3(z,1)~=0
                            for u=1:size(ISSM3,1)
                                if ISSM3(z,1)==ISSM3(u,1) && ...
                                        ISSM3(z,2)==ISSM3(u,2) && ...
                                        ISSM3(u,3)~=0
                                    if ISSM3(u+1,4)~=0
                                        for v=7:size(ISSM3,2)
                                            if ISSM3(u,v)==0
                                                v0=v-1;
                                                break
                                            end
                                        end
                                        for v=7:size(ISSM3,2)
                                            if ISSM3(z,v)>0
                                                ISSM3(u,v0+v-6)=ISSM3(z,v);
                                            end
                                        end
                                    else
                                        if abs(ISSM3(u,6)-ISSM3(z,6))<abs(ISSM3(u+1,6)-ISSM3(z,6))
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(u,v)==0
                                                    v0=v-1;
                                                    break
                                                end
                                            end
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(z,v)>0
                                                    ISSM3(u,v0+v-6)=ISSM3(z,v);
                                                end
                                            end
                                        else
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(u+1,v)==0
                                                    v0=v-1;
                                                    break
                                                end
                                            end
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(z,v)>0
                                                    ISSM3(u+1,v0+v-6)=ISSM3(z,v);
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                for z=1:size(ISSM3,1)
                    if ISSM3(z,3)>0 || (ISSM3(z,3)==0 && ISSM3(z,4)==0 && ISSM3(z-1,3)>0)
                        nISSM4=nISSM4+1;
                        ISSM4(nISSM4,1:size(ISSM3,2))=ISSM3(z,1:size(ISSM3,2));
                    end
                end
                
                clear ISSM ISSM2 ISSM3
                
                ISSM=ISSM4;
                PeakInt=max(ISSM(:,5));
                ISSM(:,5)=ISSM(:,5)./PeakInt;
                nISSM=size(ISSM,1);
                
                clear ISSM4
                
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
                
                if nISSM>0
                    for u1=1:nISSM
                        for u2=u1:nISSM
                            if u1~=u2 && ISSM(u1,4)*ISSM(u2,4)~=0 && ...
                                    ISSM(u1,4)==ISSM(u2,4) && ...
                                    ISSM(u1,3)==ISSM(u2,3) && ...
                                    ISSM(u1,2)==ISSM(u2,2) && ...
                                    ISSM(u1,1)==ISSM(u2,1)
                                
                                RefIon1=ISSM(u1,7:size(ISSM,2))';
                                RefIon2=ISSM(u2,7:size(ISSM,2))';
                                RefIon=[RefIon1;RefIon2];
                                RefIonShort=unique(RefIon,'rows');
                                RefIonShort=sortrows(RefIonShort,1);
                                nRefIonDS=0;
                                for j=1:size(RefIonShort,1)
                                    for z=1:size(CRAD_Peaks,1)
                                        if RefIonShort(j,1)~=0 && RefIonShort(j,1)==CRAD_Peaks(z,1) ...
                                                && abs(ISSM(u1,4)-CRAD_Peaks(z,2))<TimeDIFFTor
                                            nRefIonDS=nRefIonDS+1;
                                            RefIonDS(nRefIonDS,1:4)=CRAD_Peaks(z,1:4);
                                        end
                                    end
                                end
                                RefIonDS=sortrows(RefIonDS,-3);
                                RefIonDSS=RefIonDS(:,1)';
                                ISSM(u1,7:nRefIonDS+6)=RefIonDSS;
                                ISSM(u2,7:nRefIonDS+6)=RefIonDSS;
                                clear RefIon1 RefIon2 RefIon RefIonShort RefIonDS RefIonDSS
                                
                                v1v=0;
                                if u1<nISSM
                                    if ISSM(u1+1,4)==0;
                                        RefIon3=ISSM(u1+1,7:size(ISSM,2))';
                                        v1v=1;
                                    end
                                end
                                v2v=0;
                                if u2<nISSM
                                    if ISSM(u2+1,4)==0;
                                        RefIon4=ISSM(u2+1,7:size(ISSM,2))';
                                        v2v=1;
                                    end
                                end
                                v0v=0;
                                if v1v~=0 && v2v==0
                                    RefIon_O=RefIon3;
                                    v0v=1;
                                end
                                if v1v==0 && v2v~=0
                                    RefIon_O=RefIon4;
                                    v0v=1;
                                end
                                if v1v~=0 && v2v~=0
                                    RefIon_O=[RefIon3;RefIon4];
                                    v0v=1;
                                end
                                if v0v==1
                                    RefIonShort=unique(RefIon_O,'rows');
                                    RefIonShort=sortrows(RefIonShort,1);
                                    nRefIonDS=0;
                                    for j=1:size(RefIonShort,1)
                                        for z=1:size(CRAD_Peaks,1)
                                            if RefIonShort(j,1)~=0 && RefIonShort(j,1)==CRAD_Peaks(z,1) ...
                                                    && abs(ISSM(u1,4)-CRAD_Peaks(z,2))<TimeDIFFTor
                                                nRefIonDS=nRefIonDS+1;
                                                RefIonDS(nRefIonDS,1:4)=CRAD_Peaks(z,1:4);
                                            end
                                        end
                                    end
                                    RefIonDS=sortrows(RefIonDS,-3);
                                    RefIonDSS=RefIonDS(:,1)';
                                    if v1v~=0
                                        ISSM(u1+1,7:nRefIonDS+6)=RefIonDSS;
                                    end
                                    if v2v~=0
                                        ISSM(u2+1,7:nRefIonDS+6)=RefIonDSS;
                                    end
                                end
                                clear RefIon3 RefIon4 RefIon_O RefIonShort RefIonDS RefIonDSS
                                
                            end
                        end
                    end
                end
                if nISSM>1
                    nISSMShort=1;
                    ISSMShort(nISSMShort,:)=ISSM(1,:);
                    for u1=2:nISSM
                        vot=0;
                        for u2=1:nISSMShort
                            if isequal(ISSMShort(u2,1:4),ISSM(u1,1:4))==1 && ...
                                    isequal(ISSMShort(u2,7:size(ISSMShort,2)),ISSM(u1,7:size(ISSM,2)))==1
                                vot=1;
                            end
                        end
                        if vot==0
                            nISSMShort=nISSMShort+1;
                            ISSMShort(nISSMShort,:)=ISSM(u1,:);
                        end
                    end
                end
                
                clear ISSM
                ISSM=ISSMShort;
                nISSM=nISSMShort;
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
                
                
                str= sprintf('%s/%s%s%s%s',new_folder,'IDCS','Sam',num2str(SamID),'N.txt');
                fid=fopen(str,'w');
                for u=1:nISSM
                    fprintf(fid,'%.4f ',ISSM(u,1));
                    fprintf(fid,'%.4f ',ISSM(u,2));
                    if ISSM(u,3)<MiMLinearity && ISSM(u,2)~=0
                        ISSM(u,3)=MiMLinearity;
                    end
                    fprintf(fid,'%.2f ',ISSM(u,3));
                    fprintf(fid,'%.1f ',ISSM(u,4));
                    fprintf(fid,'%.4f ',ISSM(u,5));
                    fprintf(fid,'%.3f ',ISSM(u,6));
                    
                    for v=7:size(ISSM,2)
                        fprintf(fid,'%.2f ',ISSM(u,v));
                    end
                    fprintf(fid,'\n');
                end
                fclose(fid);
                clear ISSM
                
                str= sprintf('%s/%s%s%s%s',new_folder,'CRPL','Sam',num2str(SamID),'N.txt');
                fid=fopen(str,'w');
                for u=1:nCRAD_Peaks
                    for v=1:4
                        fprintf(fid,'%.4f ',CRAD_Peaks(u,v));
                    end
                    fprintf(fid,'\n');
                end
                fclose(fid);
                clear CRAD_Peaks
                
            end
        end
        clearvars -except t0 IntensityThreshold_Positive IntensityThreshold_Negative ionMode PXSet RelArea MassRange MassResolution ...
            GroupDIFFTIORControl IMI INTDIFF IRT IntensityThreshold IntersectDIFFTolerance...
            IsotopeVariance MB MBLength MBWidth MIMAssocIons MassDIFFTor Mats MaxIsotopeTIOR MiMLinearity MiMRep NosEliDIFF...
            PXSet RedundantIons RelArea SamID SamNoEn SamNoSt SlopeDIFFTolerance SlowestID TimeDIFFTor TimeVariance files ...
            nOfFiles nOfMats new_folder t00 ConNo ConsideredCoLDNo
        
        t01=cputime-t00;
        disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
        
        AddedLength=0;
        for SlowestIDNo=1:ConsideredCoLDNo
            ConID=SlowestID(1,SlowestIDNo);
            GINFCode=0;
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:4),'GINF'))
                    MaSuGI(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'P')
                            MaSuGI(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuGI(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuGI(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuGI(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuGI(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuGI(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuGI(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuGI(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'P')
                            MaSuGI(1,1)=9;
                        end
                    end
                    if MaSuGI(1,1)>0
                        GISumTemp=load(files(iFile).name);
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),1)=ConID;
                        GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),2:size(GISumTemp,2)+1)=GISumTemp;
                        GINFCode=1;
                    end
                end
            end
            if GINFCode==1
                for iFile=1:nOfFiles
                    if (strcmp(files(iFile).name(1:4),'DENO'))
                        MaSuDN(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                    && strcmp(files(iFile).name(13),'P')
                                MaSuDN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                    && strcmp(files(iFile).name(14),'P')
                                MaSuDN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=3;
                            end
                        end
                        if SamID<10 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                    && strcmp(files(iFile).name(14),'P')
                                MaSuDN(1,1)=4;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=5;
                            end
                        end
                        if SamID>=100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                    && strcmp(files(iFile).name(16),'P')
                                MaSuDN(1,1)=6;
                            end
                        end
                        if SamID<10 && ConID>=100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=7;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                    && strcmp(files(iFile).name(16),'P')
                                MaSuDN(1,1)=8;
                            end
                        end
                        if SamID>=100 && ConID>=100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                    && strcmp(files(iFile).name(17),'P')
                                MaSuDN(1,1)=9;
                            end
                        end
                        if MaSuDN(1,1)>0
                            IntSumTemp=load(files(iFile).name);
                            for u=AddedLength+1:AddedLength+size(GISumTemp,1)
                                OiO=0;
                                for z=1:size(IntSumTemp,1)
                                    if abs(GISumTemp2(u,7)-IntSumTemp(z,1))<=MassDIFFTor && ...
                                            abs(GISumTemp2(u,3)-IntSumTemp(z,2))<TimeDIFFTor*4
                                        if GISumTemp2(u,8)==IntSumTemp(z,10);
                                            OiO=OiO+1;
                                            Temp_OiO(OiO,1)=abs(GISumTemp2(u,7)-IntSumTemp(z,1));
                                            Temp_OiO(OiO,2)=abs(GISumTemp2(u,3)-IntSumTemp(z,2));
                                            Temp_OiO(OiO,3)=IntSumTemp(z,11);
                                            Temp_OiO(OiO,4)=IntSumTemp(z,2);
                                        end
                                    end
                                end
                                if OiO>0
                                    Temp_OiO=sortrows(Temp_OiO,-3);
                                    GISumTemp2(u,3)=Temp_OiO(1,4);
                                    GISumTemp2(u,8)=Temp_OiO(1,3);
                                else
                                    GISumTemp2(u,8)=0;
                                end
                            end
                            AddedLength=AddedLength+size(GISumTemp,1);
                            clear GISumTemp
                        end
                    end
                end
            end
        end
        if AddedLength>0
            GISumTemp2=sortrows(GISumTemp2,[1,7]);
            GISumTemp3=GISumTemp2;
            clear GISumTemp2
            nGISumTemp2=0;
            for h=1:size(GISumTemp3,1)
                ASTM=0.1:0.1:100;
                ASTM=ASTM';
                solutionCount=0;
                for o=1:size(ASTM,1)
                    tR=ASTM(o,1);
                    for ut=2:MBLength
                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                            TIORH2O=(tR-MB(ut-1,1))*((MB(ut,GISumTemp3(h,1)+1)-MB(ut-1,GISumTemp3(h,1)+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,GISumTemp3(h,1)+1);
                            u0=ut;
                            WTVOL=0;
                            for u1=1:u0-1
                                WTVOL=WTVOL+MB(u1+1,GISumTemp3(h,1)+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,GISumTemp3(h,1)+1)-MB(u1,GISumTemp3(h,1)+1))*(MB(u1+1,1)-MB(u1,1));
                            end
                            WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,GISumTemp3(h,1)+1)+(MB(u0,GISumTemp3(h,1)+1)-TIORH2O)*(MB(u0,1)-tR);
                            WTVOL=WTVOL/100;
                            TWVOL(1,GISumTemp3(h,1))=tR-WTVOL;
                            TIORStrong=log10(WTVOL/tR);
                        end
                    end
                    
                    tR0=10^((TIORStrong-GISumTemp3(h,5))/GISumTemp3(h,4));
                    if abs(tR-tR0)<TimeDIFFTor*4
                        solutionCount=solutionCount+1;
                        STSET(solutionCount,1)=tR;
                        STSET(solutionCount,3)=abs(tR-tR0);
                        STSET(solutionCount,2)=TIORStrong;
                    end
                end
                for o=1:solutionCount
                    if STSET(o,3)==min(STSET(:,3))
                        GISumTemp3(h,9)=STSET(o,1);
                        if abs(GISumTemp3(h,9)-GISumTemp3(h,3))<TimeDIFFTor*2
                            nGISumTemp2=nGISumTemp2+1;
                            GISumTemp2(nGISumTemp2,1:8)=GISumTemp3(h,1:8);
                        end
                    end
                end
                clear STSET
            end
            clear GISumTemp3
        end
        t01=cputime-t00;
        disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
        if AddedLength>0
            
            RTBR(:,1:3)=GISumTemp2(:,4:6);
            SBHR=unique(RTBR,'rows');
            SBHR=sortrows(SBHR,3);
            for s=1:size(SBHR,1)
                ASTM=0.1:0.1:100;
                ASTM=ASTM';
                solutionCount=0;
                for o=1:size(ASTM,1)
                    tR=ASTM(o,1);
                    for ut=2:MBLength
                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                            TIORH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                            u0=ut;
                            WTVOL=0;
                            for u1=1:u0-1
                                WTVOL=WTVOL+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                            end
                            WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-TIORH2O)*(MB(u0,1)-tR);
                            WTVOL=WTVOL/100;
                            TWVOL(1,1)=tR-WTVOL;
                            TIORStrong=log10(WTVOL/tR);
                        end
                    end
                    
                    tR0=10^((TIORStrong-SBHR(s,2))/SBHR(s,1));
                    
                    solutionCount=solutionCount+1;
                    STSET(solutionCount,1)=tR;
                    STSET(solutionCount,3)=abs(tR-tR0);
                    STSET(solutionCount,2)=TIORStrong;
                end
                for o=1:solutionCount
                    if STSET(o,3)==min(STSET(:,3))
                        SBHR(s,4)=STSET(o,1);
                    end
                end
                clear STSET
            end
            nDSBehavior=1;
            SP=0;
            WidthCode=zeros(size(SBHR,1),1);
            for z=1:size(SBHR,1)
                if SBHR(z,3)>=MiMLinearity-0.05 && SP==0
                    DSBehavior(nDSBehavior,1:3)=SBHR(z,1:3);
                    z1=z;
                    SP=1;
                    WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                    BHTI(nDSBehavior,1)=SBHR(z,4);
                end
            end
            if size(SBHR,1)>1
                for z=z1+1:size(SBHR,1)
                    if SBHR(z,3)>=MiMLinearity-0.05
                        Rep=0;
                        for u=1:nDSBehavior
                            for v=1:3:WidthCode(u,1)-1
                                if abs(SBHR(z,1)-DSBehavior(u,v))<SlopeDIFFTolerance ...
                                        && abs(SBHR(z,2)-DSBehavior(u,v+1))<IntersectDIFFTolerance...
                                        && Rep==0
                                    if max(BHTI(nDSBehavior,:))<2*t0
                                        TimeDIFF=TimeDIFFTor/2;
                                    else
                                        TimeDIFF=TimeDIFFTor;
                                    end
                                    
                                    BHTITemp=BHTI(u,:)';
                                    BTT1=sortrows(BHTITemp,1);
                                    for m=1:size(BTT1,1)
                                        if BTT1(m,1)~=0
                                            minTime=BTT1(m,1);
                                            break
                                        end
                                    end
                                    
                                    if abs(SBHR(z,4)-max(BHTI(u,:)))<=TimeDIFF*2 ...
                                            && abs(SBHR(z,4)-minTime)<=TimeDIFF*2
                                        DSBehavior(u,WidthCode(u,1)+1:WidthCode(u,1)+3)=SBHR(z,1:3);
                                        WidthCode(u,1)=WidthCode(u,1)+3;
                                        Rep=1;
                                        BHTI(u,WidthCode(u,1)/3)=SBHR(z,4);
                                    end
                                end
                            end
                        end
                        if Rep==0
                            nDSBehavior=nDSBehavior+1;
                            DSBehavior(nDSBehavior,1:3)=SBHR(z,1:3);
                            WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                            BHTI(nDSBehavior,1)=SBHR(z,4);
                        end
                    end
                end
            end
            nDSBehavior_Extended=0;
            for p=1:nDSBehavior
                nBahavioredRetentionTime=zeros(ConNo,1);
                for v=1:3:size(DSBehavior,2)
                    if DSBehavior(p,v)~=0
                        for q=1:size(GISumTemp2,1)
                            if GISumTemp2(q,4:6)==DSBehavior(p,v:v+2)
                                nBahavioredRetentionTime(GISumTemp2(q,1),1)=nBahavioredRetentionTime(GISumTemp2(q,1),1)+1;
                                BRT_temp(nBahavioredRetentionTime(GISumTemp2(q,1),1),GISumTemp2(q,1))=GISumTemp2(q,3);
                            end
                        end
                    end
                end
                for de=1:size(BRT_temp,2)
                    BRT_temp2=BRT_temp(:,de);
                    BRT_temp3=unique(BRT_temp2,'rows');
                    BRT_temp3=sortrows(BRT_temp3,-1);
                    nBRT_Short3=1;
                    BRT_Short3(nBRT_Short3,1)=BRT_temp3(nBRT_Short3,1);
                    if size(BRT_temp3,1)>1
                        for u=2:size(BRT_temp3,1)
                            if BRT_Short3(nBRT_Short3,1)-BRT_temp3(u,1)>TimeDIFFTor && BRT_temp3(u,1)>0
                                nBRT_Short3=nBRT_Short3+1;
                                BRT_Short3(nBRT_Short3,1)=BRT_temp3(u,1);
                            end
                        end
                    end
                    BRT(1:size(BRT_Short3,1),de)=BRT_Short3(1:size(BRT_Short3,1),1);
                    clear BRT_temp2 BRT_temp3 BRT_Short3
                end
                SeeTime=0;
                for s=1:size(SlowestID,2)
                    for k=1:size(BRT,2)
                        if k==SlowestID(1,s)
                            if BRT(1,k)>0 && SeeTime==0
                                SeeTime=1;
                                if k==SlowestID(1,1)
                                    for z=1:size(BRT,1)
                                        if BRT(z,k)>0
                                            nDSBehavior_Extended=nDSBehavior_Extended+1;
                                            DSBehavior_Extended(nDSBehavior_Extended,1)=BRT(z,k);
                                            DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                            DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                        end
                                    end
                                else
                                    ASTM=0.1:0.1:100;
                                    ASTM=ASTM';
                                    solutionCount=0;
                                    for o=1:size(ASTM,1)
                                        tR=ASTM(o,1);
                                        for ut=2:MBLength
                                            if tR>MB(ut-1,1) && tR<MB(ut,1)
                                                TIORH2O=(tR-MB(ut-1,1))*((MB(ut,k+1)-MB(ut-1,k+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,k+1);
                                                u0=ut;
                                                WTVOL=0;
                                                for u1=1:u0-1
                                                    WTVOL=WTVOL+MB(u1+1,k+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,k+1)-MB(u1,k+1))*(MB(u1+1,1)-MB(u1,1))/2;
                                                end
                                                WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,k+1)+(MB(u0,k+1)-TIORH2O)*(MB(u0,1)-tR)/2;
                                                WTVOL=WTVOL/100;
                                                TWVOL(1,k)=tR-WTVOL;
                                                TIORStrong=log10(WTVOL/tR);
                                            end
                                        end
                                        tR0=10^((TIORStrong-DSBehavior(p,2))/DSBehavior(p,1));
                                        if abs(tR-tR0)<TimeDIFFTor*4
                                            solutionCount=solutionCount+1;
                                            STSET(solutionCount,1)=tR;
                                            STSET(solutionCount,3)=abs(tR-tR0);
                                            STSET(solutionCount,2)=TIORStrong;
                                        end
                                    end
                                    if solutionCount>0
                                        for o=1:solutionCount
                                            if STSET(o,3)==min(STSET(:,3))
                                                nDSBehavior_Extended=nDSBehavior_Extended+1;
                                                DSBehavior_Extended(nDSBehavior_Extended,1)=STSET(o,1);
                                                DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                                DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                            end
                                        end
                                    end
                                    clear STSET
                                end
                            end
                        end
                    end
                end
                
                clear BRT clear BRT_temp
            end
            t01=cputime-t00;
            disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            Error_Tor=0.05;
            DSBehavior_Extended=sortrows(DSBehavior_Extended,1);
            DSBehavior_Extended_Temp=DSBehavior_Extended;
            clear DSBehavior_Extended;
            nDSBehavior_Extended=1;
            DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
                DSBehavior_Extended_Temp(1,1:size(DSBehavior_Extended_Temp,2));
            nSLVW1=0;
            for v=3:3:size(DSBehavior_Extended,2);
                if DSBehavior_Extended(nDSBehavior_Extended,v)~=0;
                    nSLVW1=nSLVW1+1;
                    SLVW1(nSLVW1,1:2)=DSBehavior_Extended(nDSBehavior_Extended,1:2);
                    SLVW1(nSLVW1,3:5)=DSBehavior_Extended(nDSBehavior_Extended,v:v+2);
                end
            end
            SLVW1=sortrows(SLVW1,3);
            for z=2:size(DSBehavior_Extended_Temp,1)
                nSLVW2=0;
                for v=3:3:size(DSBehavior_Extended_Temp,2);
                    if DSBehavior_Extended_Temp(z,v)~=0;
                        nSLVW2=nSLVW2+1;
                        SLVW2(nSLVW2,1:2)=DSBehavior_Extended_Temp(z,1:2);
                        SLVW2(nSLVW2,3:5)=DSBehavior_Extended_Temp(z,v:v+2);
                    end
                end
                SLVW2=sortrows(SLVW2,3);
                
                if max(SLVW1(:,1))*(1+Error_Tor)>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor) && ...
                        min(SLVW1(:,1))*(1+Error_Tor)+TimeDIFFTor*4>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor)
                    SLVW=[SLVW1;SLVW2];
                    SLVW=sortrows(SLVW,3);
                    clear SLVW1
                    SLVW1=SLVW;
                    nSLVW1=size(SLVW,1);
                    clear SLVW
                    DSBehavior_Extended(nDSBehavior_Extended,1:2)=SLVW1(1,1:2);
                    
                    for v=1:nSLVW1
                        if v~=1
                            vot=0;
                            for o=3:3:size(DSBehavior_Extended,2)
                                if SLVW1(v,3)==DSBehavior_Extended(nDSBehavior_Extended,o) && ...
                                        SLVW1(v,4)==DSBehavior_Extended(nDSBehavior_Extended,o+1) && ...
                                        SLVW1(v,5)==DSBehavior_Extended(nDSBehavior_Extended,o+2)
                                    vot=1;
                                end
                            end
                            if vot==0
                                nRow=nRow+1;
                                DSBehavior_Extended(nDSBehavior_Extended,2+3*nRow-2:2+3*nRow)=SLVW1(v,3:5);
                            end
                        else
                            DSBehavior_Extended(nDSBehavior_Extended,2+3*v-2:2+3*v)=SLVW1(v,3:5);
                            nRow=v;
                        end
                    end
                else
                    nDSBehavior_Extended=nDSBehavior_Extended+1;
                    DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
                        DSBehavior_Extended_Temp(z,1:size(DSBehavior_Extended_Temp,2));
                    clear SLVW1
                    SLVW1=SLVW2;
                    nSLVW1=nSLVW2;
                end
                clear SLVW2
            end
            clear DSBehavior_Extended_Temp;
            IonNumber=zeros(nDSBehavior_Extended,1);
            if nDSBehavior_Extended>0
                for p=1:nDSBehavior_Extended
                    for v=3:3:size(DSBehavior_Extended,2)
                        for q=1:size(GISumTemp2,1)
                            if (abs(DSBehavior_Extended(p,1)-GISumTemp2(q,3))<TimeDIFFTor*8 && GISumTemp2(q,1)==SlowestID(1,1)) ||...
                                    (GISumTemp2(q,1)~=SlowestID(1,1))
                                if GISumTemp2(q,4)==DSBehavior_Extended(p,v) && ...
                                        GISumTemp2(q,5)==DSBehavior_Extended(p,v+1) && ...
                                        GISumTemp2(q,6)==DSBehavior_Extended(p,v+2)
                                    
                                    IonNumber(p,1)=IonNumber(p,1)+1;
                                    INSM(IonNumber(p,1),1:size(GISumTemp2,2),p)=GISumTemp2(q,:);
                                    INSM(IonNumber(p,1),1+size(GISumTemp2,2),p)=p;
                                end
                            end
                        end
                    end
                end
                nINSMShort=0;
                for p=1:nDSBehavior_Extended
                    if INSM(1,1,p)>0
                        nINSMShort=nINSMShort+1;
                        INSMShort(:,:,nINSMShort)=INSM(:,:,p);
                    end
                end
                clear INSM
                INSM=INSMShort;
            end
            t01=cputime-t00;
            disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            
            if sum(IonNumber(:,1))>0
                for z=1:nDSBehavior_Extended
                    nIonDerep=1;
                    INSMDerepTemp(nIonDerep,:)=INSM(1,:,z);
                    if size(INSM,1)>1
                        for u=2:size(INSM,1)
                            if INSM(u,7,z)>0
                                if abs(INSM(u,7,z)-INSMDerepTemp(nIonDerep,7))<=MassDIFFTor
                                    if INSM(u,8,z)>INSMDerepTemp(nIonDerep,8)
                                        INSMDerepTemp(nIonDerep,:)=INSM(u,:,z);
                                    end
                                else
                                    nIonDerep=nIonDerep+1;
                                    INSMDerepTemp(nIonDerep,:)=INSM(u,:,z);
                                end
                            end
                        end
                    end
                    INSMDerep(1:nIonDerep,1:9,z)=INSMDerepTemp(1:nIonDerep,1:9);
                    clear INSMDerepTemp
                end
                clear IonNumber
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
                nINSMTS=1;
                INSMTS(1:size(INSMDerep,1),1,nINSMTS)=INSMDerep(1:size(INSMDerep,1),1,1);
                INSMTS(1:size(INSMDerep,1),2:8,nINSMTS)=INSMDerep(1:size(INSMDerep,1),3:9,1);
                if nDSBehavior_Extended>1
                    for g=2:nDSBehavior_Extended
                        Tereplicate=0;
                        Replicate=0;
                        for h=1:nINSMTS
                            if abs(INSMTS(1,2,h)-INSMDerep(1,3,g))<TimeDIFFTor && INSMTS(1,2,h)*INSMDerep(1,3,g)~=0
                                Tereplicate=1;
                                Tereplicate_hit=0;
                                for u1=1:size(INSMDerep,1)
                                    if INSMDerep(u1,7,g)~=0
                                        vot=0;
                                        for u2=1:size(INSMTS,1)
                                            if abs(INSMDerep(u1,7,g)-INSMTS(u2,6,h))<MassDIFFTor
                                                vot=1;
                                            end
                                        end
                                        if vot==0
                                            Tereplicate_hit=1;
                                        end
                                    end
                                end
                                Tereplicate_hot=0;
                                for u1=1:size(INSMTS,1)
                                    if INSMDerep(u2,7,g)~=0
                                        vot=0;
                                        for u2=1:size(INSMDerep,1)
                                            if abs(INSMDerep(u2,7,g)-INSMTS(u1,6,h))<MassDIFFTor
                                                vot=1;
                                            end
                                        end
                                        if vot==0
                                            Tereplicate_hot=1;
                                        end
                                    end
                                end
                                if Tereplicate_hit==0
                                    Replicate=1;
                                    if Tereplicate_hot==1
                                        Replicate=2;
                                        h_Code=h;
                                    end
                                end
                            end
                        end
                        if Tereplicate==1
                            if Replicate==0
                                nINSMTS=nINSMTS+1;
                                INSMTS(1:size(INSMDerep,1),1,nINSMTS)=INSMDerep(1:size(INSMDerep,1),1,g);
                                INSMTS(1:size(INSMDerep,1),2:8,nINSMTS)=INSMDerep(1:size(INSMDerep,1),3:9,g);
                            else if Replicate==2
                                    INSMTS(1:size(INSMDerep,1),1,h_Code)=INSMDerep(1:size(INSMDerep,1),1,g);
                                    INSMTS(1:size(INSMDerep,1),2:8,h_Code)=INSMDerep(1:size(INSMDerep,1),3:9,g);
                                end
                            end
                        end
                        
                        if Tereplicate==0
                            nINSMTS=nINSMTS+1;
                            INSMTS(1:size(INSMDerep,1),1,nINSMTS)=INSMDerep(1:size(INSMDerep,1),1,g);
                            INSMTS(1:size(INSMDerep,1),2:8,nINSMTS)=INSMDerep(1:size(INSMDerep,1),3:9,g);
                        end
                        
                    end
                end
                for GroupID=1:size(INSMTS,3)
                    TimeTableTemp(GroupID,1)=INSMTS(1,2,GroupID);
                    TimeTableTemp(GroupID,2)=0;
                end
                TimeTableTemp=sortrows(TimeTableTemp,1);
                for TTT=1:size(INSMTS,3)
                    for GroupID=1:size(INSMTS,3)
                        if TimeTableTemp(TTT,1)==INSMTS(1,2,GroupID) && GroupID~=TimeTableTemp(TTT,2)
                            INSMTS2(:,:,TTT)=INSMTS(:,:,GroupID);
                            TimeTableTemp(TTT,2)=GroupID;
                        end
                    end
                end
                clear INSMTS
                INSMTS=INSMTS2;
                clear INSMTS2 TimeTableTemp
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
                
                
                
                for GroupID=1:size(INSMTS,3)
                    ConID=INSMTS(1,1,GroupID);
                    for iFile=1:nOfFiles
                        if (strcmp(files(iFile).name(1:4),'DENO'))
                            MaSuDN(1,1)=0;
                            if SamID<10 && ConID<10
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                        && strcmp(files(iFile).name(13),'P')
                                    MaSuDN(1,1)=1;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID<10
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                        && strcmp(files(iFile).name(14),'P')
                                    MaSuDN(1,1)=2;
                                end
                            end
                            if SamID>=100 && ConID<10
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                        && strcmp(files(iFile).name(15),'P')
                                    MaSuDN(1,1)=3;
                                end
                            end
                            if SamID<10 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                        && strcmp(files(iFile).name(14),'P')
                                    MaSuDN(1,1)=4;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                        && strcmp(files(iFile).name(15),'P')
                                    MaSuDN(1,1)=5;
                                end
                            end
                            if SamID>=100 && ConID>=10 && ConID<100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                        && strcmp(files(iFile).name(16),'P')
                                    MaSuDN(1,1)=6;
                                end
                            end
                            if SamID<10 && ConID>=100
                                if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                        && strcmp(files(iFile).name(15),'P')
                                    MaSuDN(1,1)=7;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=100
                                if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                        && strcmp(files(iFile).name(16),'P')
                                    MaSuDN(1,1)=8;
                                end
                            end
                            if SamID>=100 && ConID>=100
                                if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                        && strcmp(files(iFile).name(17),'P')
                                    MaSuDN(1,1)=9;
                                end
                            end
                            if MaSuDN(1,1)>0
                                IntSumTemp=load(files(iFile).name);
                                
                                for r=1:size(INSMTS,1)
                                    OiO=0;
                                    for w=1:size(IntSumTemp,1)
                                        if abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1))<MassDIFFTor
                                            if OiO==0
                                                INSMTS(r,9,GroupID)=IntSumTemp(w,12);
                                                TDSet=abs(INSMTS(r,2,GroupID)-IntSumTemp(w,2));
                                                MDSet=abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1));
                                                IntSet=IntSumTemp(w,11);
                                                OiO=1;
                                                if IntSet>INSMTS(r,7,GroupID)
                                                    INSMTS(r,7,GroupID)=IntSet;
                                                end
                                            else
                                                if abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1))<MDSet
                                                    if INSMTS(r,7,GroupID)>IntSet
                                                        TDSet=abs(INSMTS(r,2,GroupID)-IntSumTemp(w,2));
                                                        MDSet=abs(INSMTS(r,6,GroupID)-IntSumTemp(w,1));
                                                        IntSet=IntSumTemp(w,11);
                                                        INSMTS(r,7,GroupID)=IntSet;
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
                nISSM=0;
                for GroupID=1:size(INSMTS,3)
                    nISSM=nISSM+1;
                    
                    INSMTemp=INSMTS(:,:,GroupID);
                    INSMTemp=sortrows(INSMTemp,-7);
                    
                    ISSM(nISSM,1:3)=DSBehavior_Extended(INSMTemp(1,8),3:5);
                    
                    ASTM=0.1:0.1:100;
                    ASTM=ASTM';
                    solutionCount=0;
                    for o=1:size(ASTM,1)
                        tR=ASTM(o,1);
                        for ut=2:MBLength
                            if tR>MB(ut-1,1) && tR<MB(ut,1)
                                TIORH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                                u0=ut;
                                WTVOL=0;
                                for u1=1:u0-1
                                    WTVOL=WTVOL+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                                end
                                WTVOL=WTVOL-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-TIORH2O)*(MB(u0,1)-tR);
                                WTVOL=WTVOL/100;
                                TWVOL(1,1)=tR-WTVOL;
                                TIORStrong=log10(WTVOL/tR);
                            end
                        end
                        
                        tR0=10^((TIORStrong-ISSM(nISSM,2))/ISSM(nISSM,1));
                        solutionCount=solutionCount+1;
                        STSET(solutionCount,1)=tR;
                        STSET(solutionCount,3)=abs(tR-tR0);
                        STSET(solutionCount,2)=TIORStrong;
                    end
                    if solutionCount>0
                        for o=1:solutionCount
                            if STSET(o,3)==min(STSET(:,3))
                                ISSM(nISSM,4)=STSET(o,1);
                            end
                        end
                    end
                    clear STSET
                    ISSM(nISSM,5)=0;
                    IntThreshold=0.8;
                    nIon=0;
                    for z=1:size(INSMTemp,1)
                        if INSMTemp(z,7)/max(INSMTemp(:,7))>=IntThreshold
                            ISSM(nISSM,5)=ISSM(nISSM,5)+INSMTemp(z,7);
                            nIon=nIon+1;
                        end
                    end
                    ISSM(nISSM,5)=ISSM(nISSM,5)/nIon;
                    ISSM(nISSM,6)=INSMTemp(1,9);
                    nCount=1;
                    nCountRem=0;
                    ISSM(nISSM,6+nCount)=INSMTemp(1,6);
                    if size(INSMTS,1)>1
                        for u=2:size(INSMTS,1)
                            if INSMTemp(u,9)>0
                                if abs(INSMTemp(u,9)-ISSM(nISSM,6))<0.2
                                    vot=0;
                                    for z=1:nCount
                                        if abs(INSMTemp(u,6)-ISSM(nISSM,6+z))<IMI
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        nCount=nCount+1;
                                        ISSM(nISSM,6+nCount)=INSMTemp(u,6);
                                    end
                                else if INSMTemp(u,9)>0
                                        nCountRem=nCountRem+1;
                                        IsoTempRem(nCountRem,:)=INSMTemp(u,:);
                                    end
                                end
                            end
                        end
                        if nCountRem>0
                            nISSM=nISSM+1;
                            ISSM(nISSM,6)=IsoTempRem(1,9);
                            nCountRemPlus=1;
                            ISSM(nISSM,6+nCountRemPlus)=IsoTempRem(1,6);
                            for u=1:nCountRem
                                vot=0;
                                for z=1:nCountRemPlus
                                    if abs(IsoTempRem(u,6)-ISSM(nISSM,6+z))<IMI
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    nCountRemPlus=nCountRemPlus+1;
                                    ISSM(nISSM,6+nCountRemPlus)=IsoTempRem(u,6);
                                end
                            end
                            clear IsoTempRem
                        end
                    end
                    clear INSMTemp
                end
                MostAbundantIon=max(ISSM(:,5));
                ISSM(:,5)=ISSM(:,5)./MostAbundantIon;
                
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
                nMassList=0;
                for u=1:size(ISSM,1)
                    for v=7:size(ISSM,2)
                        if ISSM(u,v)>0
                            nMassList=nMassList+1;
                            MassList(nMassList,1)=ISSM(u,v);
                            MassList(nMassList,3)=ISSM(u,6);
                            if ISSM(u,4)>0
                                MassList(nMassList,2)=ISSM(u,4);
                            else
                                MassList(nMassList,2)=ISSM(u-1,4);
                            end
                        end
                    end
                end
                
                for iUV=1:nOfFiles
                    MaSuUV(1,1)=0;
                    if (strcmp(files(iUV).name(1:3),'Sam'))
                        if SamID<10
                            if str2double(files(iUV).name(4))==SamID && str2double(files(iUV).name(8))==SlowestID(1,1) && ...
                                    strcmp(files(iUV).name(9),'.')
                                MaSuUV(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100
                            if str2double(files(iUV).name(4:5))==SamID && str2double(files(iUV).name(9))==SlowestID(1,1) && ...
                                    strcmp(files(iUV).name(10),'.')
                                MaSuUV(1,1)=2;
                            end
                        end
                        if SamID>=100
                            if str2double(files(iUV).name(4:6))==SamID && str2double(files(iUV).name(10))==SlowestID(1,1) && ...
                                    strcmp(files(iUV).name(11),'.')
                                MaSuUV(1,1)=3;
                            end
                        end
                        if MaSuUV(1,1)>0
                            UVTemp=load(files(iUV).name);
                            TIRA=UVTemp(size(UVTemp,1),1);
                        end
                    end
                end
                for iMat=1:nOfMats
                    if strcmp( Mats(iMat).name(1:3),'Sam')
                        nPISGS=0;
                        MaSuMa(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==SlowestID(1,1)...
                                    && (strcmp(Mats(iMat).name(9),'P'))...
                                    && strcmp(Mats(iMat).name(10),'.')
                                MaSuMa(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==SlowestID(1,1)...
                                    && (strcmp(Mats(iMat).name(10),'P'))...
                                    && strcmp(Mats(iMat).name(11),'.')
                                MaSuMa(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==SlowestID(1,1)...
                                    && (strcmp(Mats(iMat).name(11),'P'))...
                                    && strcmp(Mats(iMat).name(12),'.')
                                MaSuMa(1,1)=3;
                            end
                        end
                        if MaSuMa(1,1)>0
                            data = load(Mats(iMat).name);
                            Scans=data.Scans;
                            SDWI=size(Scans,2);
                            MergeMass=data.Masses;
                            dataLength=size(MergeMass,1);
                            MergeData=data.Data;
                            FDTH=round(TIRA*2.5*log10(SDWI));
                            AWTH=SDWI;
                            TIOR=round(AWTH/FDTH);
                            if TIOR>=1
                                iCol=0;
                                for k=1:TIOR:AWTH-TIOR
                                    iCol=iCol+1;
                                    dataTemp(1:dataLength,1:TIOR)=MergeData(1:dataLength,k:k+TIOR-1);
                                    for o=1:dataLength
                                        DANW(o,iCol)=sum(dataTemp(o,1:TIOR));
                                    end
                                    METI(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+TIOR-1))/Scans(1,SDWI)*TIRA;
                                end
                            else
                                TIOR2=round(FDTH/AWTH);
                                iCol=TIOR2*AWTH;
                                for o=1:SDWI
                                    METI(1,o*TIOR2-TIOR2+1:o*TIOR2)=Scans(1,o)/Scans(1,SDWI)*TIRA;
                                    for k=1:dataLength
                                        DANW(k,o*TIOR2-TIOR2+1:o*TIOR2)=MergeData(k,o);
                                    end
                                end
                            end
                            SDWI=iCol;
                            
                            XIC=zeros(SDWI,2);
                            nPISGS=0;
                            fr = FDTH/16;
                            dt = (16/FDTH)^2;
                            rick = ricker(FDTH,fr,dt,20);
                            rick_smooth = getSmoothRicker(rick);
                            for r=1:nMassList
                                for h=MassRange+1:dataLength-MassRange
                                    if abs(MergeMass(h,1)-MassList(r,1))<MassDIFFTor
                                        for j=1:SDWI
                                            XIC(j,1)=METI(1,j);
                                            XIC(j,2)=sum(DANW(h-MassRange:h+MassRange,j));
                                        end
                                        SXIC0  = conv( rick_smooth(:,1),XIC(:,2) );
                                        SXIC(:,1)=XIC(:,1);
                                        SXIC(:,2)=SXIC0( round(length(rick_smooth)/2)+1:length(XIC(:,2))+round(length(rick_smooth)/2));
                                        SXICLength=size(SXIC,1);
                                        PTSD=0.01;
                                        PPGSN=0;
                                        HighPoint=max(SXIC(:,2));
                                        for i=2:SXICLength-1
                                            if SXIC(i,2)>=SXIC(i-1,2) && SXIC(i,2)>=SXIC(i+1,2) && SXIC(i,2)> HighPoint*PTSD && (SXIC(i,2)-SXIC(i-1,2))+(SXIC(i,2)-SXIC(i+1,2))~=0
                                                PPGSN=PPGSN+1;
                                                PPGS(PPGSN,1) = SXIC(i,1);
                                                PPGS(PPGSN,2) = SXIC(i,2);
                                            end;
                                        end;
                                        
                                        BASLT=0.01;
                                        NPIR=0;
                                        
                                        if PPGSN>0
                                            for m=1:PPGSN
                                                PTI=PPGS(m,1);
                                                PHT=PPGS(m,2);
                                                PPSN(1,1)=PPGS(m,1);
                                                PPSN(1,2)=PPGS(m,2);
                                                halfPH=PHT/2;
                                                
                                                for z=1:SXICLength
                                                    if SXIC(z,1)==PTI
                                                        PP=z;
                                                    end;
                                                end;
                                                
                                                vbv1=0;
                                                for z=PP:-1:2
                                                    if SXIC(z,2)>=0 && SXIC(z-1,2)<=0 && vbv1==0
                                                        CZTL=SXIC(z,1);
                                                        LeftID=z;
                                                        vbv1=1;
                                                    end;
                                                end;
                                                
                                                if vbv1==0
                                                    CZTL=0;
                                                    LeftID=1;
                                                end;
                                                
                                                vbv2=0;
                                                for z=PP:SXICLength-1
                                                    if SXIC(z,2)>=0 && SXIC(z+1,2)<=0 && vbv2==0
                                                        CZTR=SXIC(z,1);
                                                        RightID=z;
                                                        vbv2=1;
                                                    end;
                                                end;
                                                
                                                if vbv2==0
                                                    CZTR=SXIC(SXICLength,1);
                                                    RightID=SXICLength;
                                                end;
                                                
                                                PPGS(m,3)=CZTL;
                                                PPGS(m,4)=CZTR;
                                                PPGS(m,5)=(CZTR-CZTL)/TIRA;
                                                PPGS(m,6)=PHT/HighPoint;
                                                PPGS(m,7)=PPGS(m,6)/PPGS(m,5);
                                                
                                                
                                                if LeftID>1 && RightID<SXICLength
                                                    PPGS(m,8)=0;
                                                    for z=LeftID:RightID
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                if LeftID==1 && RightID<SXICLength
                                                    PPGS(m,8)=(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                    for z=2:RightID
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                if LeftID>1 && RightID==SXICLength
                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                    for z=LeftID:RightID-1
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                                
                                                if LeftID==1 && RightID==SXICLength
                                                    PPGS(m,8)=(SXIC(SXICLength,1)-SXIC(SXICLength-1,1))/2*SXIC(SXICLength,2);
                                                    PPGS(m,8)=PPGS(m,8)+(SXIC(2,1)-SXIC(1,1))/2*SXIC(1,2);
                                                    for z=2:SXICLength-1
                                                        PPGS(m,8)=PPGS(m,8)+(SXIC(z+1,1)-SXIC(z-1,1))/2*SXIC(z,2);
                                                    end
                                                end
                                            end;
                                            
                                            PPGSST(1,:)=PPGS(1,:);
                                            nPPShort=1;
                                            for z=1:PPGSN
                                                if PPGS(z,1)-PPGSST(nPPShort,1)<TimeDIFFTor
                                                    if PPGS(z,2)>PPGSST(nPPShort,2)
                                                        PPGSST(nPPShort,1)=PPGS(z,1);
                                                        PPGSST(nPPShort,2)=PPGS(z,2);
                                                    end;
                                                    if PPGS(z,3)>PPGSST(nPPShort,3)
                                                        PPGSST(nPPShort,3)=PPGS(z,3);
                                                    end;
                                                    if PPGS(z,4)<PPGSST(nPPShort,4)
                                                        PPGSST(nPPShort,4)=PPGS(z,4);
                                                    end;
                                                    PPGSST(nPPShort,5)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))/TIRA;
                                                    PPGSST(nPPShort,6)=PPGSST(nPPShort,2)/HighPoint;
                                                    PPGSST(nPPShort,7)=PPGSST(nPPShort,6)/PPGSST(nPPShort,5);
                                                    PPGSST(nPPShort,8)=(PPGSST(nPPShort,4)-PPGSST(nPPShort,3))*PPGSST(nPPShort,2)/2;
                                                else
                                                    nPPShort=nPPShort+1;
                                                    PPGSST(nPPShort,:)=PPGS(z,:);
                                                end;
                                            end;
                                            
                                            LargestPeak=max(PPGSST(:,8));
                                            
                                            PPGSST(:,9)=PPGSST(:,8)/LargestPeak;
                                            
                                            
                                            
                                            if nPPShort>0
                                                for s=1:nPPShort
                                                    if abs(PPGSST(s,1)-MassList(r,2))<TimeDIFFTor*4 && PPGSST(s,9)>RelArea
                                                        if size(MassList,2)==3 || MassList(r,3)==0
                                                            MassList(r,4)=PPGSST(s,1);
                                                            MassList(r,5)=PPGSST(s,8);
                                                            MassList(r,6)=MergeMass(h,1);
                                                            
                                                        else
                                                            if abs(MassList(r,3)-MassList(r,2))>TimeDIFFTor*2
                                                                if abs(PPGSST(s,1)-MassList(r,2))<abs(MassList(r,3)-MassList(r,2))
                                                                    MassList(r,4)=PPGSST(s,1);
                                                                    MassList(r,5)=PPGSST(s,8);
                                                                    MassList(r,6)=MergeMass(h,1);
                                                                end
                                                            else
                                                                if MassList(r,4)<PPGSST(s,8)
                                                                    MassList(r,4)=PPGSST(s,1);
                                                                    MassList(r,5)=PPGSST(s,8);
                                                                    MassList(r,6)=MergeMass(h,1);
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                                
                                                
                                                clear PPGS PPGSST ...
                                                    width PPSN;
                                                
                                            end
                                            
                                            
                                        end
                                        
                                        clear XIC SXIC SETI;
                                    end
                                end
                            end
                        end
                    end
                end
                
                MassList=sortrows(MassList,4);
                
                
                nCRAD_Peaks=0;
                NGP=0;
                NGPedIsomer=0;
                for z=1:size(MassList,1)
                    if MassList(z,4)>0
                        
                        if nCRAD_Peaks==0
                            nCRAD_Peaks=nCRAD_Peaks+1;
                            CRAD_Peaks(nCRAD_Peaks,1)=MassList(z,6);
                            CRAD_Peaks(nCRAD_Peaks,2)=MassList(z,4);
                            CRAD_Peaks(nCRAD_Peaks,3)=MassList(z,5);
                            CRAD_Peaks(nCRAD_Peaks,4)=MassList(z,3);
                        else
                            vot=0;
                            for p=1:nCRAD_Peaks
                                if CRAD_Peaks(p,1)==MassList(z,6) && ...
                                        CRAD_Peaks(p,2)==MassList(z,4)
                                    vot=1;
                                    if CRAD_Peaks(p,4)>MassList(z,3)
                                        CRAD_Peaks(p,4)=MassList(z,3);
                                    end
                                end
                            end
                            if vot==0
                                nCRAD_Peaks=nCRAD_Peaks+1;
                                CRAD_Peaks(nCRAD_Peaks,1)=MassList(z,6);
                                CRAD_Peaks(nCRAD_Peaks,2)=MassList(z,4);
                                CRAD_Peaks(nCRAD_Peaks,3)=MassList(z,5);
                                CRAD_Peaks(nCRAD_Peaks,4)=MassList(z,3);
                            end
                        end
                        
                        
                        if NGPedIsomer==0
                            NGPedIsomer=NGPedIsomer+1;
                            GPIM(NGPedIsomer,:)=MassList(z,:);
                        else
                            if GPIM(NGPedIsomer,2)==MassList(z,2) &&...
                                    MassList(z,4)-GPIM(NGPedIsomer,4)<=TimeDIFFTor
                                NGPedIsomer=NGPedIsomer+1;
                                GPIM(NGPedIsomer,:)=MassList(z,:);
                            else
                                GPIM_short=unique(GPIM,'rows');
                                clear GPIM
                                GPIM=GPIM_short;
                                GPIM=sortrows(GPIM,3);
                                NGPedIsomer=size(GPIM,1);
                                NGP=NGP+1;
                                if NGPedIsomer>1
                                    o=NGPedIsomer;
                                    for k=1:NGPedIsomer-1
                                        if GPIM(k,3)~=GPIM(k+1,3)
                                            o=k;
                                        end
                                    end
                                    if o<NGPedIsomer
                                        GPIM1=GPIM(1:o,1:6);
                                        GPIM1=sortrows(GPIM1,-5);
                                        ISSM2(NGP,6,1)=GPIM1(1,3);
                                        ISSM2(NGP,4,1)=GPIM1(1,4);
                                        ISSM2(NGP,5,1)=0;
                                        for p=1:o
                                            if size(ISSM2,2)>6
                                                vot=0;
                                                for v=7:size(ISSM2,2)
                                                    if ISSM2(NGP,v,1)==GPIM1(p,6)
                                                        vot=1;
                                                    end
                                                end
                                                if vot==0
                                                    ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                                    if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                                    end
                                                end
                                            else
                                                ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                                if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                                    ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                                end
                                            end
                                        end
                                        
                                        GPIM2=GPIM(o+1:NGPedIsomer,1:6);
                                        GPIM2=sortrows(GPIM2,-5);
                                        ISSM2(NGP,6,2)=GPIM2(1,3);
                                        ISSM2(NGP,5,2)=0;
                                        for p=1:NGPedIsomer-o
                                            if size(ISSM2,2)>6
                                                vot=0;
                                                for v=7:size(ISSM2,2)
                                                    if ISSM2(NGP,v,2)==GPIM2(p,6)
                                                        vot=1;
                                                    end
                                                end
                                                if vot==0
                                                    ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                                    if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                                        ISSM2(NGP,5,2)=ISSM2(NGP,5,1)+GPIM2(p,5);
                                                    end
                                                end
                                            else
                                                ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                                if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                                    ISSM2(NGP,5,2)=ISSM2(NGP,5,2)+GPIM2(p,5);
                                                end
                                            end
                                        end
                                        
                                        clear GPIM1 GPIM2
                                    else
                                        GPIM=sortrows(GPIM,-5);
                                        ISSM2(NGP,6,1)=GPIM(1,3);
                                        ISSM2(NGP,4,1)=GPIM(1,4);
                                        ISSM2(NGP,5,1)=0;
                                        for p=1:o
                                            if size(ISSM2,2)>6
                                                vot=0;
                                                for v=7:size(ISSM2,2)
                                                    if ISSM2(NGP,v,1)==GPIM(p,6)
                                                        vot=1;
                                                    end
                                                end
                                                if vot==0
                                                    ISSM2(NGP,6+p,1)=GPIM(p,6);
                                                    if GPIM(p,5)>max(GPIM(:,5))*0.8
                                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                                    end
                                                end
                                            else
                                                ISSM2(NGP,6+p,1)=GPIM(p,6);
                                                if GPIM(p,5)>max(GPIM(:,5))*0.8
                                                    ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                                end
                                            end
                                        end
                                    end
                                    
                                else
                                    ISSM2(NGP,7,1)=GPIM(NGPedIsomer,6);
                                    ISSM2(NGP,6,1)=GPIM(NGPedIsomer,3);
                                    ISSM2(NGP,5,1)=GPIM(NGPedIsomer,5);
                                    ISSM2(NGP,4,1)=GPIM(NGPedIsomer,4);
                                end
                                clear GPIM
                                NGPedIsomer=1;
                                GPIM(NGPedIsomer,:)=MassList(z,:);
                            end
                        end
                    end
                end
                
                if NGPedIsomer>0
                    GPIM_short=unique(GPIM,'rows');
                    clear GPIM
                    GPIM=GPIM_short;
                    GPIM=sortrows(GPIM,3);
                    NGPedIsomer=size(GPIM,1);
                    NGP=NGP+1;
                    if NGPedIsomer>1
                        o=NGPedIsomer;
                        for k=1:NGPedIsomer-1
                            if GPIM(k,3)~=GPIM(k+1,3)
                                o=k;
                            end
                        end
                        if o<NGPedIsomer
                            GPIM1=GPIM(1:o,1:6);
                            GPIM1=sortrows(GPIM1,-5);
                            ISSM2(NGP,6,1)=GPIM1(1,3);
                            ISSM2(NGP,4,1)=GPIM1(1,4);
                            ISSM2(NGP,5,1)=0;
                            for p=1:o
                                if size(ISSM2,2)>6
                                    vot=0;
                                    for v=7:size(ISSM2,2)
                                        if ISSM2(NGP,v,1)==GPIM1(p,6)
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                        if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                            ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                        end
                                    end
                                else
                                    ISSM2(NGP,6+p,1)=GPIM1(p,6);
                                    if GPIM1(p,5)>max(GPIM1(:,5))*0.8
                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM1(p,5);
                                    end
                                end
                            end
                            
                            GPIM2=GPIM(o+1:NGPedIsomer,1:6);
                            GPIM2=sortrows(GPIM2,-5);
                            ISSM2(NGP,6,2)=GPIM2(1,3);
                            ISSM2(NGP,5,2)=0;
                            for p=1:NGPedIsomer-o
                                if size(ISSM2,2)>6
                                    vot=0;
                                    for v=7:size(ISSM2,2)
                                        if ISSM2(NGP,v,2)==GPIM2(p,6)
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                        if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                            ISSM2(NGP,5,2)=ISSM2(NGP,5,1)+GPIM2(p,5);
                                        end
                                    end
                                else
                                    ISSM2(NGP,6+p,2)=GPIM2(p,6);
                                    if GPIM2(p,5)>max(GPIM2(:,5))*0.8
                                        ISSM2(NGP,5,2)=ISSM2(NGP,5,2)+GPIM2(p,5);
                                    end
                                end
                            end
                            
                            clear GPIM1 GPIM2
                        else
                            GPIM=sortrows(GPIM,-5);
                            ISSM2(NGP,6,1)=GPIM(1,3);
                            ISSM2(NGP,4,1)=GPIM(1,4);
                            ISSM2(NGP,5,1)=0;
                            for p=1:o
                                if size(ISSM2,2)>6
                                    vot=0;
                                    for v=7:size(ISSM2,2)
                                        if ISSM2(NGP,v,1)==GPIM(p,6)
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        ISSM2(NGP,6+p,1)=GPIM(p,6);
                                        if GPIM(p,5)>max(GPIM(:,5))*0.8
                                            ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                        end
                                    end
                                else
                                    ISSM2(NGP,6+p,1)=GPIM(p,6);
                                    if GPIM(p,5)>max(GPIM(:,5))*0.8
                                        ISSM2(NGP,5,1)=ISSM2(NGP,5,1)+GPIM(p,5);
                                    end
                                end
                            end
                        end
                        
                    else
                        ISSM2(NGP,7,1)=GPIM(NGPedIsomer,6);
                        ISSM2(NGP,6,1)=GPIM(NGPedIsomer,3);
                        ISSM2(NGP,5,1)=GPIM(NGPedIsomer,5);
                        ISSM2(NGP,4,1)=GPIM(NGPedIsomer,4);
                    end
                    clear GPIM
                end
                
                nISSM3=0;
                if NGP>0
                    for z=1:NGP
                        nISSM3=nISSM3+1;
                        ISSM3(nISSM3,1:size(ISSM2,2))=ISSM2(z,:,1);
                        if ISSM2(z,7,2)>0
                            nISSM3=nISSM3+1;
                            ISSM3(nISSM3,1:size(ISSM2,2))=ISSM2(z,:,2);
                        end
                    end
                end
                
                for iMat=1:nOfMats
                    MaSuTN(1,1)=0;
                    if (strcmp(Mats(iMat).name(1:4),'TDAN'))
                        if SamID<10
                            if str2double(Mats(iMat).name(8))==SamID && strcmp(Mats(iMat).name(9),'P')
                                MaSuTN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(Mats(iMat).name(8:9))==SamID && strcmp(Mats(iMat).name(10),'P')
                                MaSuTN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(Mats(iMat).name(8:10))==SamID && strcmp(Mats(iMat).name(11),'P')
                                MaSuTN(1,1)=3;
                            end
                        end
                        if MaSuTN(1,1)>0
                            data = load(Mats(iMat).name);
                            TDAN=data.TDANBYAbun;
                        end
                    end
                end
                
                for z=1:size(ISSM3,1)
                    if z==1
                        MassTime1(1,1)=ISSM3(z,7);
                        MassTime1(1,2)=ISSM3(z,4);
                        SlopeLine=1;
                        if ISSM3(z+1,4)==0
                            No1=0;
                            for v=7:size(ISSM3,2)
                                if ISSM3(z,v)>0
                                    No1=No1+1;
                                end
                            end
                            No2=0;
                            for v=7:size(ISSM3,2)
                                if ISSM3(z+1,v)>0
                                    No2=No2+1;
                                end
                            end
                            if No2>No1
                                MassTime1(1,1)=ISSM3(z+1,7);
                            end
                            if No2==No1 && ISSM3(z+1,5)>ISSM3(z,5)
                                MassTime1(1,1)=ISSM3(z+1,7);
                            end
                        end
                    end
                    if z>1 && z<size(ISSM3,1) && ISSM3(z,4)~=0
                        MassTime1(1,1)=ISSM3(z,7);
                        MassTime1(1,2)=ISSM3(z,4);
                        SlopeLine=z;
                        if ISSM3(z+1,4)==0
                            if ISSM3(z+1,4)==0
                                No1=0;
                                for v=7:size(ISSM3,2)
                                    if ISSM3(z,v)>0
                                        No1=No1+1;
                                    end
                                end
                                No2=0;
                                for v=7:size(ISSM3,2)
                                    if ISSM3(z+1,v)>0
                                        No2=No2+1;
                                    end
                                end
                                if No2>No1
                                    MassTime1(1,1)=ISSM3(z+1,7);
                                end
                                if No2==No1 && ISSM3(z+1,5)>ISSM3(z,5)
                                    MassTime1(1,1)=ISSM3(z+1,7);
                                end
                            end
                        end
                    end
                    if z==size(ISSM3,1)
                        if ISSM3(z,4)~=0
                            SlopeLine=z;
                            MassTime1(1,1)=ISSM3(z,7);
                            MassTime1(1,2)=ISSM3(z,4);
                        end
                    end
                    
                    nMatch=0;
                    for v=1:size(TDAN,3)
                        MatchTime=0;
                        for w=1:4:size(TDAN,2)
                            for u=1:size(TDAN,1)
                                if abs(MassTime1(1,2)-TDAN(u,w+1,v))>TimeDIFFTor*2 && TDAN(u,w+1,v)~=0 ...
                                        && w==1
                                    MatchTime=MatchTime-0.25;
                                end
                                if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDIFFTor*2
                                    if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDIFFTor*2 && w==1
                                        MatchTime=MatchTime+1;
                                    end
                                    if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                        MatchTime=MatchTime+0.25;
                                    end
                                end
                            end
                        end
                        if MatchTime>0
                            nMatch=nMatch+1;
                            MAMX(nMatch,1)=MatchTime;
                            MAMX(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                            MAMX(nMatch,5)=v;
                        end
                    end
                    if nMatch>0
                        nMatchShort=0;
                        for u=1:nMatch
                            if MAMX(u,1)==max(MAMX(:,1))
                                nMatchShort=nMatchShort+1;
                                MAMXS(nMatchShort,:)=MAMX(u,:);
                            end
                        end
                        
                        MAMXS=sortrows(MAMXS,2);
                        ISSM3(SlopeLine,1:3)=MAMXS(1,2:4);
                        clear MAMX MAMXS
                    else
                        for v=1:size(TDAN,3)
                            MatchTime=0;
                            for w=1:4:size(TDAN,2)
                                for u=1:size(TDAN,1)
                                    if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDIFFTor
                                        if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDIFFTor*8 && w==1
                                            MatchTime=MatchTime+1;
                                        end
                                        if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                            MatchTime=MatchTime+0.25;
                                        end
                                    end
                                end
                            end
                            
                            if MatchTime>0
                                nMatch=nMatch+1;
                                MAMX(nMatch,1)=MatchTime;
                                MAMX(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                                MAMX(nMatch,5)=v;
                            end
                        end
                        if nMatch>0
                            nMatchShort=0;
                            for u=1:nMatch
                                if MAMX(u,1)==max(MAMX(:,1))
                                    nMatchShort=nMatchShort+1;
                                    MAMXS(nMatchShort,:)=MAMX(u,:);
                                end
                            end
                            MAMXS=sortrows(MAMXS,2);
                            ISSM3(SlopeLine,1:2)=MAMXS(1,2:3);
                            clear MAMX MAMXS
                        end
                    end
                end
                
                nISSM4=0;
                for z=1:size(ISSM3,1)
                    if ISSM3(z,3)==0 && ISSM3(z,4)~=0
                        if ISSM3(z,1)~=0
                            for u=1:size(ISSM3,1)
                                if ISSM3(z,1)==ISSM3(u,1) && ...
                                        ISSM3(z,2)==ISSM3(u,2) && ...
                                        ISSM3(u,3)~=0
                                    if ISSM3(u+1,4)~=0
                                        for v=7:size(ISSM3,2)
                                            if ISSM3(u,v)==0
                                                v0=v-1;
                                                break
                                            end
                                        end
                                        for v=7:size(ISSM3,2)
                                            if ISSM3(z,v)>0
                                                ISSM3(u,v0+v-6)=ISSM3(z,v);
                                            end
                                        end
                                    else
                                        if abs(ISSM3(u,6)-ISSM3(z,6))<abs(ISSM3(u+1,6)-ISSM3(z,6))
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(u,v)==0
                                                    v0=v-1;
                                                    break
                                                end
                                            end
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(z,v)>0
                                                    ISSM3(u,v0+v-6)=ISSM3(z,v);
                                                end
                                            end
                                        else
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(u+1,v)==0
                                                    v0=v-1;
                                                    break
                                                end
                                            end
                                            for v=7:size(ISSM3,2)
                                                if ISSM3(z,v)>0
                                                    ISSM3(u+1,v0+v-6)=ISSM3(z,v);
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                for z=1:size(ISSM3,1)
                    if ISSM3(z,3)>0 || (ISSM3(z,3)==0 && ISSM3(z,4)==0 && ISSM3(z-1,3)>0)
                        nISSM4=nISSM4+1;
                        ISSM4(nISSM4,1:size(ISSM3,2))=ISSM3(z,1:size(ISSM3,2));
                    end
                end
                
                clear ISSM ISSM2 ISSM3
                
                ISSM=ISSM4;
                PeakInt=max(ISSM(:,5));
                ISSM(:,5)=ISSM(:,5)./PeakInt;
                nISSM=size(ISSM,1);
                
                clear ISSM4
                
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
                
                
                if nISSM>0
                    for u1=1:nISSM
                        for u2=u1:nISSM
                            if u1~=u2 && ISSM(u1,4)*ISSM(u2,4)~=0 && ...
                                    ISSM(u1,4)==ISSM(u2,4) && ...
                                    ISSM(u1,3)==ISSM(u2,3) && ...
                                    ISSM(u1,2)==ISSM(u2,2) && ...
                                    ISSM(u1,1)==ISSM(u2,1)
                                
                                RefIon1=ISSM(u1,7:size(ISSM,2))';
                                RefIon2=ISSM(u2,7:size(ISSM,2))';
                                RefIon=[RefIon1;RefIon2];
                                RefIonShort=unique(RefIon,'rows');
                                RefIonShort=sortrows(RefIonShort,1);
                                nRefIonDS=0;
                                for j=1:size(RefIonShort,1)
                                    for z=1:size(CRAD_Peaks,1)
                                        if RefIonShort(j,1)~=0 && RefIonShort(j,1)==CRAD_Peaks(z,1) ...
                                                && abs(ISSM(u1,4)-CRAD_Peaks(z,2))<TimeDIFFTor
                                            nRefIonDS=nRefIonDS+1;
                                            RefIonDS(nRefIonDS,1:4)=CRAD_Peaks(z,1:4);
                                        end
                                    end
                                end
                                RefIonDS=sortrows(RefIonDS,-3);
                                RefIonDSS=RefIonDS(:,1)';
                                ISSM(u1,7:nRefIonDS+6)=RefIonDSS;
                                ISSM(u2,7:nRefIonDS+6)=RefIonDSS;
                                clear RefIon1 RefIon2 RefIon RefIonShort RefIonDS RefIonDSS
                                
                                v1v=0;
                                if u1<nISSM
                                    if ISSM(u1+1,4)==0;
                                        RefIon3=ISSM(u1+1,7:size(ISSM,2))';
                                        v1v=1;
                                    end
                                end
                                v2v=0;
                                if u2<nISSM
                                    if ISSM(u2+1,4)==0;
                                        RefIon4=ISSM(u2+1,7:size(ISSM,2))';
                                        v2v=1;
                                    end
                                end
                                v0v=0;
                                if v1v~=0 && v2v==0
                                    RefIon_O=RefIon3;
                                    v0v=1;
                                end
                                if v1v==0 && v2v~=0
                                    RefIon_O=RefIon4;
                                    v0v=1;
                                end
                                if v1v~=0 && v2v~=0
                                    RefIon_O=[RefIon3;RefIon4];
                                    v0v=1;
                                end
                                if v0v==1
                                    RefIonShort=unique(RefIon_O,'rows');
                                    RefIonShort=sortrows(RefIonShort,1);
                                    nRefIonDS=0;
                                    for j=1:size(RefIonShort,1)
                                        for z=1:size(CRAD_Peaks,1)
                                            if RefIonShort(j,1)~=0 && RefIonShort(j,1)==CRAD_Peaks(z,1) ...
                                                    && abs(ISSM(u1,4)-CRAD_Peaks(z,2))<TimeDIFFTor
                                                nRefIonDS=nRefIonDS+1;
                                                RefIonDS(nRefIonDS,1:4)=CRAD_Peaks(z,1:4);
                                            end
                                        end
                                    end
                                    RefIonDS=sortrows(RefIonDS,-3);
                                    RefIonDSS=RefIonDS(:,1)';
                                    if v1v~=0
                                        ISSM(u1+1,7:nRefIonDS+6)=RefIonDSS;
                                    end
                                    if v2v~=0
                                        ISSM(u2+1,7:nRefIonDS+6)=RefIonDSS;
                                    end
                                end
                                clear RefIon3 RefIon4 RefIon_O RefIonShort RefIonDS RefIonDSS
                                
                            end
                        end
                    end
                end
                if nISSM>1
                    nISSMShort=1;
                    ISSMShort(nISSMShort,:)=ISSM(1,:);
                    for u1=2:nISSM
                        vot=0;
                        for u2=1:nISSMShort
                            if isequal(ISSMShort(u2,1:4),ISSM(u1,1:4))==1 && ...
                                    isequal(ISSMShort(u2,7:size(ISSMShort,2)),ISSM(u1,7:size(ISSM,2)))==1
                                vot=1;
                            end
                        end
                        if vot==0
                            nISSMShort=nISSMShort+1;
                            ISSMShort(nISSMShort,:)=ISSM(u1,:);
                        end
                    end
                end
                
                clear ISSM
                ISSM=ISSMShort;
                nISSM=nISSMShort;
                
                t01=cputime-t00;
                disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
                
                str= sprintf('%s/%s%s%s%s',new_folder,'IDCS','Sam',num2str(SamID),'P.txt');
                fid=fopen(str,'w');
                for u=1:nISSM
                    fprintf(fid,'%.4f ',ISSM(u,1));
                    fprintf(fid,'%.4f ',ISSM(u,2));
                    if ISSM(u,3)<MiMLinearity && ISSM(u,2)~=0
                        ISSM(u,3)=MiMLinearity;
                    end
                    fprintf(fid,'%.2f ',ISSM(u,3));
                    fprintf(fid,'%.1f ',ISSM(u,4));
                    fprintf(fid,'%.4f ',ISSM(u,5));
                    fprintf(fid,'%.3f ',ISSM(u,6));
                    
                    for v=7:size(ISSM,2)
                        fprintf(fid,'%.2f ',ISSM(u,v));
                    end
                    fprintf(fid,'\n');
                end
                fclose(fid);
                clear ISSM
                
                str= sprintf('%s/%s%s%s%s',new_folder,'CRPL','Sam',num2str(SamID),'P.txt');
                fid=fopen(str,'w');
                for u=1:nCRAD_Peaks
                    for v=1:4
                        fprintf(fid,'%.4f ',CRAD_Peaks(u,v));
                    end
                    fprintf(fid,'\n');
                end
                fclose(fid);
                clear CRAD_Peaks
                
            end
        end
        clearvars -except t0 IntensityThreshold_Positive IntensityThreshold_Negative ionMode PXSet RelArea MassRange MassResolution ...
            GroupDIFFTIORControl IMI INTDIFF IRT IntensityThreshold IntersectDIFFTolerance...
            IsotopeVariance MB MBLength MBWidth MIMAssocIons MassDIFFTor Mats MaxIsotopeTIOR MiMLinearity MiMRep NosEliDIFF...
            PXSet RedundantIons RelArea SamID SamNoEn SamNoSt SlopeDIFFTolerance SlowestID TimeDIFFTor TimeVariance files ...
            nOfFiles nOfMats new_folder t00 ConNo ConsideredCoLDNo
        
        t01=cputime-t00;
        disp(['hold on... Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    end
    t01=cputime-t00;
    disp(['hold on... Calculation time = ',num2str(t01), ' seconds ']);
end
