function rick_smooth = getSmoothRicker(rick)
from = find(rick<-1e-8,1,'first');
to = find(rick<-1e-8,1,'last');
rick_smooth = rick(from:to);
