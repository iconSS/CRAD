%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CRAD: for E picking and denoising before the origin, application, or composition of a sample are known
%%% Copyright (C) <2016>  Wang Renqi
%%% This program is free software: you can redistribute it and/or modify
%%% it under the terms of the GNU General Public License as published by
%%% the Free Software Foundation, either version 3 of the License, or
%%% any later version.


%%% This program is distributed in the hope that it will be useful,
%%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%%% GNU General Public License for more details.

%%% For details of the GNU General Public License, please see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;

SamNoSt = 1; %Sample number Start spot
SamNoEn = 2;%Sample number End spot
ConNo = 5;  %Total Condition No
IntensityThreshold = 1.25*10^2;

for CRAD=1:1
PXSet =10;
RelArea = 0.2;
IRT = 0.01;
TimeDifferTor = 0.5;
MassDifferTor = 0.5;
MassResolution=0.05;
t0=2.5;
t00=cputime;
IMI = MassDifferTor*MassResolution*2/5.5;
MassRange=round(MassDifferTor/(MassResolution*2))-1;
files = dir(fullfile('.', '*.txt'));
[nOfFiles,~] = size(files);
Mats = dir(fullfile('.', '*.mat'));
[nOfMats,~]=size(Mats);
for SamID=SamNoSt:SamNoEn
    for ConID=1:ConNo
        for iFile=1:nOfFiles
            if (strcmp(files(iFile).name(1:3),'Sam'))
                MaSuUV(1,1)=0;
                if SamID<10 && ConID<10
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                            && strcmp(files(iFile).name(9),'.')
                        MaSuUV(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                            && strcmp(files(iFile).name(10),'.')
                        MaSuUV(1,1)=2;
                    end
                end
                if SamID>=100 && ConID<10
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=3;
                    end
                end
                if SamID<10 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                            && strcmp(files(iFile).name(10),'.')
                        MaSuUV(1,1)=4;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=5;
                    end
                end
                if SamID>=100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                            && strcmp(files(iFile).name(12),'.')
                        MaSuUV(1,1)=6;
                    end
                end
                if SamID<10 && ConID>=100
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=7;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=100
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                            && strcmp(files(iFile).name(12),'.')
                        MaSuUV(1,1)=8;
                    end
                end
                if SamID>=100 && ConID>=100
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                            && strcmp(files(iFile).name(13),'.')
                        MaSuUV(1,1)=9;
                    end
                end
                if MaSuUV(1,1)>0
                    UVTemp=load(files(iFile).name);
                    UVTempLS=size(UVTemp,1);
                    TIRA =UVTemp(UVTempLS,1);
                    
                    UVSPOR = load(files(iFile).name);
                    UVLS  = size(UVSPOR,1);
                    UVSP(1:UVLS, 1:2) = UVSPOR(1:UVLS, 1:2);
                    HighPoint = max(UVSP(:,2));
                    LowPoint  = min(UVSP(:,2));
                    sectionNo = 100;
                    Incre     = (HighPoint-LowPoint)/sectionNo;
                    section   = zeros(sectionNo,3);
                    
                    for i=1:sectionNo
                        section(i,1) = Incre*(i-1)+LowPoint;
                        section(i,2) = Incre*i+LowPoint;
                        section(i,3) = 0;
                    end;
                    
                    for j=1:UVLS
                        for u=1:sectionNo
                            if (UVSP(j,2)>=section(u,1) && ...
                                    UVSP(j,2)<section(u,2) )
                                section(u,3)=section(u,3)+1;
                            end;
                        end;
                    end;
                    chooseSection=max(section(:,3));
                    
                    for i=1:sectionNo
                        if section(i,3)==chooseSection
                            baselineLow=section(i,1);
                            baselineHigh=section(i,2);
                        end;
                    end;
                    
                    BaseLineValue=0;
                    count=0;
                    
                    for i=1:UVLS
                        if (UVSP(i,2)>=baselineLow && ...
                                UVSP(i,2)<baselineHigh)
                            BaseLineValue=BaseLineValue+UVSP(i,2);
                            count=count+1;
                        end;
                    end;
                    BaseLineValue=BaseLineValue/count;
                    UVSP(:,2) = UVSP(:,2)-BaseLineValue;
                end;
                if MaSuUV(1,1)>0
                    MaxMajorENo=PXSet;
                    MajorEThreshold=RelArea;
                    for iMat=1:nOfMats
                        if strcmp( Mats(iMat).name(1:3),'Sam')
                            nEInforSummaryGS=0;
                            MaSuMa(1,1)=0;
                            if SamID<10 && ConID<10
                                if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                        && (strcmp(Mats(iMat).name(9),'N') || strcmp(Mats(iMat).name(9),'P'))...
                                        && strcmp(Mats(iMat).name(10),'.')
                                    MaSuMa(1,1)=1;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID<10
                                if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                        && (strcmp(Mats(iMat).name(10),'N') || strcmp(Mats(iMat).name(10),'P'))...
                                        && strcmp(Mats(iMat).name(11),'.')
                                    MaSuMa(1,1)=2;
                                end
                            end
                            if SamID>=100 && ConID<10
                                if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                        && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                        && strcmp(Mats(iMat).name(12),'.')
                                    MaSuMa(1,1)=3;
                                end
                            end
                            if SamID<10 && ConID>=10 && ConID<100
                                if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                        && (strcmp(Mats(iMat).name(10),'N') || strcmp(Mats(iMat).name(10),'P'))...
                                        && strcmp(Mats(iMat).name(11),'.')
                                    MaSuMa(1,1)=4;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                        && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                        && strcmp(Mats(iMat).name(12),'.')
                                    MaSuMa(1,1)=5;
                                end
                            end
                            if SamID>=100 && ConID>=10 && ConID<100
                                if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                        && (strcmp(Mats(iMat).name(12),'N') || strcmp(Mats(iMat).name(12),'P'))...
                                        && strcmp(Mats(iMat).name(13),'.')
                                    MaSuMa(1,1)=6;
                                end
                            end
                            if SamID<10 && ConID>=100
                                if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                        && (strcmp(Mats(iMat).name(11),'N') || strcmp(Mats(iMat).name(11),'P'))...
                                        && strcmp(Mats(iMat).name(12),'.')
                                    MaSuMa(1,1)=7;
                                end
                            end
                            if SamID>=10 && SamID<100 && ConID>=100
                                if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                        && (strcmp(Mats(iMat).name(12),'N') || strcmp(Mats(iMat).name(12),'P'))...
                                        && strcmp(Mats(iMat).name(13),'.')
                                    MaSuMa(1,1)=8;
                                end
                            end
                            if SamID>=100 && ConID>=100
                                if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                        && (strcmp(Mats(iMat).name(13),'N') || strcmp(Mats(iMat).name(13),'P'))...
                                        && strcmp(Mats(iMat).name(14),'.')
                                    MaSuMa(1,1)=9;
                                end
                            end
                            if MaSuMa(1,1)>0
                                data = load(Mats(iMat).name);
                                Scans=data.Scans;
                                dataWidth=size(Scans,2);
                                MergeMass=data.Masses;
                                dataLength=size(MergeMass,1);
                                MergeData=data.Data;
                                FH=round(TIRA*2.5*log10(dataWidth));
                                ATH=dataWidth;
                                Ratio=round(ATH/FH);
                                if Ratio>=1
                                    iCol=0;
                                    for k=1:Ratio:ATH-Ratio
                                        iCol=iCol+1;
                                        dataTemp(1:dataLength,1:Ratio)=MergeData(1:dataLength,k:k+Ratio-1);
                                        for o=1:dataLength
                                            Data_New(o,iCol)=sum(dataTemp(o,1:Ratio));
                                        end
                                        MergeTime(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+Ratio-1))/Scans(1,dataWidth)*TIRA;
                                    end
                                else
                                    Ratio2=round(FH/ATH);
                                    iCol=Ratio2*ATH;
                                    for o=1:dataWidth
                                        MergeTime(1,o*Ratio2-Ratio2+1:o*Ratio2)=Scans(1,o)/Scans(1,dataWidth)*TIRA;
                                        for k=1:dataLength
                                            Data_New(k,o*Ratio2-Ratio2+1:o*Ratio2)=MergeData(k,o);
                                        end
                                    end
                                end
                                dataWidth=iCol;
                                XIC=zeros(dataWidth,2);
                                nEInforSummaryGS=0;
                                fr = FH/16;
                                dt = (16/FH)^2;
                                rick = ricker(FH,fr,dt,20);
                                rick_smooth = getSmoothRicker(rick);
                                for h=MassRange+1:dataLength-MassRange
                                    for j=1:dataWidth
                                        XIC(j,1)=MergeTime(1,j);
                                        XIC(j,2)=sum(Data_New(h-MassRange:h+MassRange,j));
                                    end
                                    smoothXIC0  = conv( rick_smooth(:,1),XIC(:,2) );
                                    smoothXIC(:,1)=XIC(:,1);
                                    smoothXIC(:,2)=smoothXIC0( round(length(rick_smooth)/2)+1:length(XIC(:,2))+round(length(rick_smooth)/2));
                                    smoothXICLength=size(smoothXIC,1);
                                    EThreshold=0.01;
                                    EPointGSNo=0;
                                    HighPoint=max(smoothXIC(:,2));
                                    for i=2:smoothXICLength-1
                                        if smoothXIC(i,2)>=smoothXIC(i-1,2) && smoothXIC(i,2)>=smoothXIC(i+1,2) && smoothXIC(i,2)> HighPoint*EThreshold && (smoothXIC(i,2)-smoothXIC(i-1,2))+(smoothXIC(i,2)-smoothXIC(i+1,2))~=0
                                            EPointGSNo=EPointGSNo+1;
                                            EPointGS(EPointGSNo,1) = smoothXIC(i,1);
                                            EPointGS(EPointGSNo,2) = smoothXIC(i,2);
                                        end;
                                    end;
                                    BaseLineTolerance=0.01;
                                    nEInfor=0;
                                    
                                    if EPointGSNo>0
                                        for m=1:EPointGSNo
                                            ETime=EPointGS(m,1);
                                            EHight=EPointGS(m,2);
                                            EPosition(1,1)=EPointGS(m,1);
                                            EPosition(1,2)=EPointGS(m,2);
                                            halfPH=EHight/2;
                                            
                                            for z=1:smoothXICLength
                                                if smoothXIC(z,1)==ETime
                                                    PP=z;
                                                end;
                                            end;
                                            
                                            vbv1=0;
                                            for z=PP:-1:2
                                                if smoothXIC(z,2)>=0 && smoothXIC(z-1,2)<=0 && vbv1==0
                                                    CrossZeroLeft=smoothXIC(z,1);
                                                    LeftIndex=z;
                                                    vbv1=1;
                                                end;
                                            end;
                                            
                                            if vbv1==0
                                                CrossZeroLeft=0;
                                                LeftIndex=1;
                                            end;
                                            
                                            vbv2=0;
                                            for z=PP:smoothXICLength-1
                                                if smoothXIC(z,2)>=0 && smoothXIC(z+1,2)<=0 && vbv2==0
                                                    CrossZeroRight=smoothXIC(z,1);
                                                    RightIndex=z;
                                                    vbv2=1;
                                                end;
                                            end;
                                            
                                            if vbv2==0
                                                CrossZeroRight=smoothXIC(smoothXICLength,1);
                                                RightIndex=smoothXICLength;
                                            end;
                                            
                                            EPointGS(m,3)=CrossZeroLeft;
                                            EPointGS(m,4)=CrossZeroRight;
                                            EPointGS(m,5)=(CrossZeroRight-CrossZeroLeft)/TIRA;
                                            EPointGS(m,6)=EHight/HighPoint;
                                            EPointGS(m,7)=EPointGS(m,6)/EPointGS(m,5);
                                            
                                            
                                            if LeftIndex>1 && RightIndex<smoothXICLength
                                                EPointGS(m,8)=0;
                                                for z=LeftIndex:RightIndex
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            if LeftIndex==1 && RightIndex<smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                for z=2:RightIndex
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            if LeftIndex>1 && RightIndex==smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                for z=LeftIndex:RightIndex-1
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            
                                            if LeftIndex==1 && RightIndex==smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                for z=2:smoothXICLength-1
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                        end;
                                        
                                        EPointGSShort(1,:)=EPointGS(1,:);
                                        nPPShort=1;
                                        for z=1:EPointGSNo
                                            if EPointGS(z,1)-EPointGSShort(nPPShort,1)<TimeDifferTor
                                                if EPointGS(z,2)>EPointGSShort(nPPShort,2)
                                                    EPointGSShort(nPPShort,1)=EPointGS(z,1);
                                                    EPointGSShort(nPPShort,2)=EPointGS(z,2);
                                                end;
                                                if EPointGS(z,3)>EPointGSShort(nPPShort,3)
                                                    EPointGSShort(nPPShort,3)=EPointGS(z,3);
                                                end;
                                                if EPointGS(z,4)<EPointGSShort(nPPShort,4)
                                                    EPointGSShort(nPPShort,4)=EPointGS(z,4);
                                                end;
                                                EPointGSShort(nPPShort,5)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))/TIRA;
                                                EPointGSShort(nPPShort,6)=EPointGSShort(nPPShort,2)/HighPoint;
                                                EPointGSShort(nPPShort,7)=EPointGSShort(nPPShort,6)/EPointGSShort(nPPShort,5);
                                                EPointGSShort(nPPShort,8)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))*EPointGSShort(nPPShort,2)/2;
                                            else
                                                nPPShort=nPPShort+1;
                                                EPointGSShort(nPPShort,:)=EPointGS(z,:);
                                            end;
                                        end;
                                        
                                        LargestE=max(EPointGSShort(:,8));
                                        
                                        EPointGSShort(:,9)=EPointGSShort(:,8)/LargestE;
                                        
                                        if nPPShort>0
                                            EPointGSShort=sortrows(EPointGSShort,-9);
                                            countNoMajor=0;
                                            for z=1:nPPShort
                                                if (EPointGSShort(z,9)>MajorEThreshold &&...
                                                        EPointGSShort(z,1)>t0)
                                                    countNoMajor=countNoMajor+1;
                                                end;
                                            end;
                                            if countNoMajor<=MaxMajorENo
                                                for z=1:nPPShort
                                                    if (EPointGSShort(z,9)>MajorEThreshold && ...
                                                            EPointGSShort(z,7)>MajorEThreshold/EPointGSShort(z,5) && ...
                                                            EPointGSShort(z,1)>t0 && EPointGSShort(z,4)<TIRA-1)
                                                        nEInforSummaryGS=nEInforSummaryGS+1;
                                                        EInforSummaryGS(nEInforSummaryGS,1)=MergeMass(h,1);
                                                        EInforSummaryGS(nEInforSummaryGS,2:10)=EPointGSShort(z,1:9);
                                                    end;
                                                end;
                                            end
                                        end;
                                        clear EPointGS LeftPoint RightPoint EPointGSShort ...
                                            width EPosition;
                                    end;
                                    clear XIC smoothXIC section;
                                end;
                                t01=cputime-t00;
                                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                                    'Con',num2str(ConID),'hold on...']);
                            end
                            if nEInforSummaryGS>0
                                PIG=EInforSummaryGS(:,1);
                                PIGS=unique(PIG,'rows');
                                
                                PISGSLength = size(EInforSummaryGS,1);
                                EAreaMax=max(EInforSummaryGS(:,9));
                                EInforSummaryGSTemp=zeros(PISGSLength,11);
                                EInforSummaryGSTemp(1:PISGSLength,1:10) = EInforSummaryGS(1:PISGSLength,1:10);
                                EInforSummaryGSTemp(1:PISGSLength,11)   = EInforSummaryGSTemp(1:PISGSLength,9)/EAreaMax;
                                
                                
                                t01=cputime-t00;
                                disp(['squezzing time1 = ',num2str(t01), ' seconds' ]);
                                
                                EInforSummaryGS2=zeros(PISGSLength,13);
                                nEInforSummaryGS2=0;
                                for i=1:PISGSLength
                                    if EInforSummaryGSTemp(i,9)>IntensityThreshold
                                        for j=1:PISGSLength
                                            hit=0;
                                            hot=0;
                                            if EInforSummaryGSTemp(j,9)>IntensityThreshold
                                                if EInforSummaryGSTemp(i,1)-(EInforSummaryGSTemp(j,1))<-1/3+IMI &&...
                                                        EInforSummaryGSTemp(i,1)-(EInforSummaryGSTemp(j,1))>=-1-IMI && ...
                                                        abs(EInforSummaryGSTemp(i,2)-(EInforSummaryGSTemp(j,2)))<TimeDifferTor &&...
                                                        EInforSummaryGSTemp(j,11)/EInforSummaryGSTemp(i,11)<1 && ...
                                                        EInforSummaryGSTemp(j,11)/EInforSummaryGSTemp(i,11)>=IRT
                                                    IsotopeRatio=EInforSummaryGSTemp(j,11)/EInforSummaryGSTemp(i,11);
                                                    hit=1;
                                                    hot=1;
                                                end
                                                if EInforSummaryGSTemp(j,1)-(EInforSummaryGSTemp(i,1))<-1/3+IMI &&...
                                                        EInforSummaryGSTemp(j,1)-(EInforSummaryGSTemp(i,1))>=-1-IMI && ...
                                                        abs(EInforSummaryGSTemp(i,2)-(EInforSummaryGSTemp(j,2)))<TimeDifferTor &&...
                                                        EInforSummaryGSTemp(i,11)/EInforSummaryGSTemp(j,11)<1 && ...
                                                        EInforSummaryGSTemp(i,11)/EInforSummaryGSTemp(j,11)>=IRT
                                                    IsotopeRatio=EInforSummaryGSTemp(i,11)/EInforSummaryGSTemp(j,11);
                                                    hit=1;
                                                end
                                            end
                                            if hit==1
                                                nEInforSummaryGS2=nEInforSummaryGS2+1;
                                                EInforSummaryGS2(nEInforSummaryGS2,1:11)=EInforSummaryGSTemp(i,1:11);
                                                if hot==1
                                                    EInforSummaryGS2(nEInforSummaryGS2,12)=IsotopeRatio;
                                                else
                                                    EInforSummaryGS2(nEInforSummaryGS2,13)=IsotopeRatio;
                                                end
                                            end
                                        end
                                    end
                                end
                                
                                EInforSummaryGS2T=EInforSummaryGS2(1:nEInforSummaryGS2,1:13);
                                clear EInforSummaryGS2
                                EInforSummaryGS2=EInforSummaryGS2T;
                                clear EInforSummaryGS2T
                                
                                
                                if size(EInforSummaryGS2,1)>0
                                    t02=cputime-t00;
                                    disp(['squezzing time2 = ',num2str(t02), ' seconds' ]);
                                    
                                    nEInforSummaryGS3=0;
                                    for i=1:nEInforSummaryGS2
                                        if EInforSummaryGS2(i,12)>0
                                            nEInforSummaryGS3=nEInforSummaryGS3+1;
                                            EInforSummaryGS3(nEInforSummaryGS3,1:12)=EInforSummaryGS2(i,1:12);
                                        end
                                    end
                                    
                                    if nEInforSummaryGS3>0
                                        for i=1:nEInforSummaryGS3
                                            Temp=EInforSummaryGS3(i,:);
                                            for j=1:nEInforSummaryGS3
                                                if abs(EInforSummaryGS3(i,1)-EInforSummaryGS3(j,1))<1 && ...
                                                        abs(EInforSummaryGS3(i,2)-EInforSummaryGS3(j,2))<0.1 && ...
                                                        EInforSummaryGS3(j,11)>=Temp(1,11)
                                                    Temp=EInforSummaryGS3(j,:);
                                                end
                                            end
                                            EInforSummaryGS4(i,:)=Temp;
                                            clear Temp
                                        end
                                        
                                        
                                        t03=cputime-t00;
                                        disp(['squezzing time3 = ',num2str(t03), ' seconds' ]);
                                        
                                        if size(EInforSummaryGS4,1)>0
                                            EInforSummaryGS5=unique(EInforSummaryGS4,'rows');
                                            nEInforSummaryGS5=size(EInforSummaryGS5,1);
                                            
                                            PIG5=EInforSummaryGS5(:,1);
                                            PIG5S=unique(PIG5,'rows');
                                            
                                            
                                            clear EInforSummaryGSTemp;
                                            
                                            
                                            t04=cputime-t00;
                                            disp(['squezzing time4 = ',num2str(t04), ' seconds' ]);
                                            MajorEThreshold=round(MajorEThreshold*1000)/1000;
                                            dataOutputShort=EInforSummaryGS5(1:nEInforSummaryGS5, 1:12);
                                            [~, outputFile0] = fileparts( Mats(iMat).name );
                                            outputFilename = strcat( 'DENO',outputFile0,'.txt' );
                                            save(outputFilename,'dataOutputShort','-ascii');
                                            clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo IMI IRT IntensityThreshold MajorEThreshold INTDiffer...
                                                MassDifferTor Mats MaxMajorENo PXSet RelArea SamID SamNoEn SamNoSt TimeDifferTor ...
                                                dt files fr iFile iMat nOfFiles nOfMats DPT DeadTime TIRA rick rick_smooth t0 t00
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo IMI IRT IntensityThreshold MassDifferTor Mats PXSet RelArea SamID SamNoEn SamNoSt ...
                TimeDifferTor files iFile nOfFiles nOfMats INTDiffer t0 t00
        end
    end
    t01=cputime-t00;
    disp(['Calculation time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),'Con',num2str(ConID)]);
end
t01=cputime-t00;
disp(['Calculation time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
MassRange=round(MassDifferTor/MassResolution)-1;
IMI = MassDifferTor*MassResolution/5.5;
INTDiffer=0.05;
TimeShortLong=t0*2;
MiMLinearity=0.8;
MIMAssocIons=2;
load Mobile_Phase.txt
MB=Mobile_Phase;
MBLength=size(MB,1);
files = dir(fullfile('.', '*.txt'));
[nOfFiles,~] = size(files);
for SamID=SamNoSt:SamNoEn
    LengthRef=0;
    LengthRefMiR=0;
    for ConID=1:ConNo
        for iFile=1:nOfFiles
            if (strcmp( files(iFile).name(1:4),'DENO'))
                MaSuDN(1,1)=0;
                if SamID<10 && ConID<10
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                            && strcmp(files(iFile).name(13),'N')
                        MaSuDN(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                            && strcmp(files(iFile).name(14),'N')
                        MaSuDN(1,1)=2;
                    end
                end
                if SamID>=100 && ConID<10
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                            && strcmp(files(iFile).name(15),'N')
                        MaSuDN(1,1)=3;
                    end
                end
                if SamID<10 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                            && strcmp(files(iFile).name(14),'N')
                        MaSuDN(1,1)=4;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                            && strcmp(files(iFile).name(15),'N')
                        MaSuDN(1,1)=5;
                    end
                end
                if SamID>=100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                            && strcmp(files(iFile).name(16),'N')
                        MaSuDN(1,1)=6;
                    end
                end
                if SamID<10 && ConID>=100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                            && strcmp(files(iFile).name(15),'N')
                        MaSuDN(1,1)=7;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                            && strcmp(files(iFile).name(16),'N')
                        MaSuDN(1,1)=8;
                    end
                end
                if SamID>=100 && ConID>=100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                            && strcmp(files(iFile).name(17),'N')
                        MaSuDN(1,1)=9;
                    end
                end
                if MaSuDN(1,1)>0
                    dataTemp=load(files(iFile).name);
                    LengthTemp=size(dataTemp,1);
                    dataSummary(1:LengthTemp,1,ConID)=dataTemp(1:LengthTemp,1);
                    dataSummary(1:LengthTemp,2,ConID)=dataTemp(1:LengthTemp,2);
                    dataSummary(1:LengthTemp,3,ConID)=dataTemp(1:LengthTemp,7);
                    dataSummary(1:LengthTemp,4,ConID)=dataTemp(1:LengthTemp,12);
                    LengthSummary(ConID,1)=ConID;
                    LengthSummary(ConID,2)=LengthTemp;
                    Ref(LengthRef+1:LengthRef+LengthTemp,1:4)=dataSummary(1:LengthTemp,1:4,ConID);
                    LengthRef=LengthRef+LengthTemp;
                    clear dataTemp;
                end
            end
        end
    end
    t01=cputime-t00;
    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
        'Con',num2str(ConID),'hold on...']);
    
    if LengthRef>0
        Ref=sortrows(Ref,1);
        nMultiply=0;
        for i=1:LengthRef
            nFound=0;
            for w=1:size(LengthSummary,1)
                for z=1:LengthSummary(w,2)
                    if abs(dataSummary(z,1,w)-Ref(i,1))<MassDifferTor &&...
                            abs(dataSummary(z,4,w)-Ref(i,4))<1 &&...
                            abs(dataSummary(z,3,w)-Ref(i,3))<INTDiffer
                        
                        nFound=nFound+1;
                        Found(nFound,1:4)=dataSummary(z,1:4,w);
                        Found(nFound,5)=w;
                    end
                end
            end
            if max(Found(1:nFound,2))>TimeShortLong
                MiMRep=3;
                TimeDiffer=TimeDifferTor;
            else
                MiMRep=3;
                TimeDiffer=TimeDifferTor/2;
            end
            
            if nFound>=MiMRep
                nTimeGood=0;
                for z=1:nFound
                    nSet=1;
                    SetU(nSet,:)=Found(z,:);
                    for z1=1:nFound
                        vot=0;
                        for z2=1:nSet
                            if SetU(z2,5)==Found(z1,5)
                                vot=1;
                            end
                        end
                        if vot==0
                            nSet=nSet+1;
                            SetU(nSet,:)=Found(z1,:);
                        end
                    end
                    for z1=1:nSet
                        nTimeRoutine=1;
                        RefU(nTimeRoutine,:)=SetU(z1,:);
                        for z2=1:nSet
                            if RefU(nTimeRoutine,5)<SetU(z2,5) && RefU(nTimeRoutine,2)-SetU(z2,2)>TimeDiffer
                                nTimeRoutine=nTimeRoutine+1;
                                RefU(nTimeRoutine,:)=SetU(z2,:);
                            end
                        end
                        
                        if max(RefU(1:nTimeRoutine,2))>TimeShortLong
                            MiMRep=3;
                        else
                            MiMRep=3;
                        end
                        
                        if nTimeRoutine>=MiMRep && max(SetU(:,2))-min(SetU(:,2))>2*TimeDiffer
                            nTimeGood=nTimeGood+1;
                            for z3=1:nTimeRoutine
                                TempU(nTimeGood,RefU(z3,5)*4-3:RefU(z3,5)*4)=RefU(z3,1:4);
                            end
                        end
                        clear RefU
                    end
                end
                clear SetU
                if nTimeGood>0
                    nTimeGoodShort=1;
                    TimeGoodWdith=size(TempU,2);
                    TimeGoodShort(nTimeGoodShort,:)=TempU(1,:);
                    for v=2:nTimeGood
                        vot=0;
                        vbt=0;
                        for v1=1:nTimeGoodShort
                            vpt=1;
                            for v2=4:4:TimeGoodWdith
                                if TimeGoodShort(v1,v2-3)*TempU(v,v2-3)~=0
                                    if TimeGoodShort(v1,v2-3)==TempU(v,v2-3) && TimeGoodShort(v1,v2-2)==TempU(v,v2-2) && ...
                                            TimeGoodShort(v1,v2-1)==TempU(v,v2-1) && TimeGoodShort(v1,v2)==TempU(v,v2)
                                        vpt=vpt*2;
                                    else
                                        vpt=vpt*0;
                                    end
                                end
                            end
                            if vpt>1
                                for v3=4:4:TimeGoodWdith
                                    if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                        vbt=1;
                                    end
                                end
                                if vbt==0
                                    for v3=4:4:TimeGoodWdith
                                        if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                            TimeGoodShort(v1,v3-3:v3)=TempU(v,v3-3:v3);
                                        end
                                    end
                                end
                                vot=1;
                            end
                        end
                        if vot==0
                            nTimeGoodShort=nTimeGoodShort+1;
                            TimeGoodShort(nTimeGoodShort,:)=TempU(v,:);
                        end
                    end
                    TGSWidth=size(TimeGoodShort,2);
                    clear TempU;
                    
                    for v=1:nTimeGoodShort
                        Multiply0(nMultiply+v,1:TGSWidth)=TimeGoodShort(v,1:TGSWidth);
                    end
                    nMultiply=nMultiply+nTimeGoodShort;
                    clear TimeGoodShort;
                    
                end
            end
        end
        t01=cputime-t00;
        disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
            'Con',num2str(ConID),'hold on...']);
        
        if nMultiply>0
            Multiply1=unique(Multiply0,'rows');
            MultiplyLength=size(Multiply1,1);
            MultiplyWidth=size(Multiply1,2);
            nMultiply_Short=0;
            for w=1:MultiplyLength
                for z=2:4:MultiplyWidth
                    if Multiply1(w,z)>0
                        conditionNo=(z+2)/4;
                        for u=2:MBLength
                            if Multiply1(w,z)>MB(u-1,1) && Multiply1(w,z)<=MB(u,1)
                                RatioH2O=(Multiply1(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                u0=u;
                                volH2O(1,conditionNo)=0;
                                for u1=1:u0-1
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                end
                                volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-Multiply1(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-Multiply1(w,z));
                                volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                volMeOH(1,conditionNo)=Multiply1(w,z)-volH2O(1,conditionNo);
                                RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/Multiply1(w,z));
                                lnTime(1,conditionNo)=log10(Multiply1(w,z));
                            end
                        end
                    end
                end
                
                countNo=0;
                for u=1:conditionNo
                    if lnTime(1,u)~=0
                        countNo=countNo+1;
                        RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                        lnTime_PSS(1,countNo)=lnTime(1,u);
                    end
                end
                
                vot=0;
                for z=1:4:MultiplyWidth
                    if Multiply1(w,z)>0 && vot==0
                        pSS(w,1)=Multiply1(w,z);
                        vot=1;
                    end
                end
                pSS(w,2:3)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                
                for z=1:countNo
                    RatioStrongfit2(1,z)=pSS(w,2)*lnTime_PSS(1,z)+pSS(w,3);
                end
                
                R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                pSS(w,4)=R2;
                
                if R2>MiMLinearity
                    nMultiply_Short=nMultiply_Short+1;
                    p2(nMultiply_Short,:)=pSS(w,:);
                    Multiply(nMultiply_Short,:)=Multiply1(w,:);
                end
                
                clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
            end
            t01=cputime-t00;
            disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                'Con',num2str(ConID),'hold on...']);
            if nMultiply_Short>0
                MultiplyTemp=Multiply;
                clear Multiply;
                nMultiply=0;
                BoundaryMinorMajor=0.6;
                for z=1:nMultiply_Short
                    MoM=0;
                    for v=3:4:size(MultiplyTemp,2)
                        if MultiplyTemp(z,v)>=BoundaryMinorMajor
                            MoM=1;
                        end
                    end
                    if MoM==0
                        nMultiply=nMultiply+1;
                        Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                    else
                        oMo=0;
                        NoMass=0;
                        AveMass=0;
                        for v=1:4:size(MultiplyTemp,2)
                            if MultiplyTemp(z,v)>0
                                AveMass=AveMass+MultiplyTemp(z,v);
                                NoMass=NoMass+1;
                            end
                        end
                        AveMass=AveMass/NoMass;
                        
                        for u=1:size(MultiplyTemp,1)
                            if oMo==0
                                for v=1:4:size(MultiplyTemp,2)
                                    if abs(AveMass-MultiplyTemp(u,v))<MassDifferTor && MultiplyTemp(u,v+2)==1
                                        oMo=1;
                                    end
                                end
                            end
                        end
                        
                        if oMo==1
                            nMultiply=nMultiply+1;
                            Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                        end
                    end
                end
                nMultiply=size(Multiply,1);
                CWidth=size(Multiply,2);
                nr=1;
                condition=0;
                for i=2:4:CWidth
                    condition=condition+1;
                    rFeature(nr,condition)=Multiply(1,i);
                end
                for i=2:nMultiply
                    condition=0;
                    for j=2:4:CWidth
                        condition=condition+1;
                        Temp(1,condition)=Multiply(i,j);
                    end
                    Temp2=Temp';
                    if min(Temp2)<2*t0
                        TimeDiffer=TimeDifferTor/2;
                    else
                        TimeDiffer=TimeDifferTor;
                    end
                    vot=0;
                    vbt=0;
                    
                    for z=1:nr
                        vmt=0;
                        vpt=1;
                        for u=1:condition
                            if Temp(1,u)*rFeature(z,u)~=0
                                if abs(Temp(1,u)-rFeature(z,u))<TimeDiffer
                                    vpt=vpt*2;
                                else
                                    vpt=vpt*0;
                                end
                            end
                            if abs(Temp(1,u)-rFeature(z,u))>=TimeDiffer
                                vmt=1;
                            end
                        end
                        if vmt==0
                            vot=1;
                        end
                        if vpt>1 && vmt==1
                            for u=1:condition
                                if Temp(1,u)~=0 && rFeature(z,u)==0
                                    if (u==1 && Temp(1,u)-rFeature(z,u+1)>TimeDiffer && rFeature(z,u+1)~=0)||...
                                            (u==condition && rFeature(z,u-1)-Temp(1,u)>TimeDiffer) ||...
                                            (u<condition && u>1 && rFeature(z,u-1)-Temp(1,u)>TimeDiffer...
                                            && Temp(1,u)-rFeature(z,u+1)>TimeDiffer && rFeature(z,u+1)~=0)
                                        rFeature(z,u)=Temp(1,u);
                                        vot=1;
                                    end
                                end
                            end
                        end
                    end
                    if vot==0
                        nr=nr+1;
                        condition=0;
                        for v=2:4:CWidth
                            condition=condition+1;
                            rFeature(nr,condition)=Multiply(i,v);
                        end
                    end
                    clear Temp Temp2
                end
                rFeature_Short=unique(rFeature,'rows');
                clear rFeature
                rFeature=rFeature_Short;
                nr=size(rFeature,1);
                
                for w=1:nr
                    for z=1:size(rFeature,2)
                        if rFeature(w,z)>0
                            conditionNo=z;
                            for u=2:MBLength
                                if rFeature(w,z)>MB(u-1,1) && rFeature(w,z)<=MB(u,1)
                                    RatioH2O=(rFeature(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                    u0=u;
                                    volH2O(1,conditionNo)=0;
                                    for u1=1:u0-1
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                    end
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-rFeature(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-rFeature(w,z));
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                    volMeOH(1,conditionNo)=rFeature(w,z)-volH2O(1,conditionNo);
                                    RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/rFeature(w,z));
                                    lnTime(1,conditionNo)=log10(rFeature(w,z));
                                end
                            end
                        end
                    end
                    
                    countNo=0;
                    for u=1:conditionNo
                        if lnTime(1,u)~=0
                            countNo=countNo+1;
                            RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                            lnTime_PSS(1,countNo)=lnTime(1,u);
                        end
                    end
                    
                    
                    pSS(w,1:2)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                    
                    for z=1:countNo
                        RatioStrongfit2(1,z)=pSS(w,1)*lnTime_PSS(1,z)+pSS(w,2);
                    end
                    
                    R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                    pSS(w,3)=R2;
                    
                    rFeatureRecorded(w,:)=pSS(w,:);
                    
                    clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on...']);
                
                rNum=zeros(nr,2);
                for g=1:nr
                    for i=1:nMultiply
                        condition=0;
                        vht=0;
                        for j=2:4:CWidth
                            if abs(Multiply(i,j)-269)<1
                                a=1;
                            end
                            condition=condition+1;
                            if abs(Multiply(i,j)-rFeature(g,condition))>TimeDifferTor && Multiply(i,j)*rFeature(g,condition)~=0
                                vht=1;
                            end
                            if Multiply(i,j)~=0 && rFeature(g,condition)==0
                                if (condition==1 && Multiply(i,j)-rFeature(g,condition+1)<=TimeDifferTor && rFeature(g,condition+1)~=0)||...
                                        (condition==CWidth/4 && rFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor && rFeature(g,condition-1)~=0)||...
                                        (condition<CWidth/4 && condition>1 && ((rFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor && ...
                                        rFeature(g,condition-1)~=0) ||...
                                        Multiply(i,j)-rFeature(g,condition+1)<=TimeDifferTor) && rFeature(g,condition+1)~=0)
                                    vht=1;
                                end
                            end
                            if Multiply(i,j)==0 && rFeature(g,condition)~=0
                                if (condition==1 && rFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor && Multiply(i,j+4)~=0)||...
                                        (condition==CWidth/4 && Multiply(i,j-4)-rFeature(g,condition)<=TimeDifferTor && Multiply(i,j-4)~=0)||...
                                        (condition<CWidth/4 && condition>1 && ((Multiply(i,j-4)-rFeature(g,condition)<=TimeDifferTor && ...
                                        Multiply(i,j-4)~=0)||...
                                        rFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor) && Multiply(i,j+4)~=0)
                                    vht=1;
                                end
                            end
                        end
                        if vht==0;
                            rNum(g,1)=rNum(g,1)+1;
                            rAbunTemp=0;
                            countMP=0;
                            for u=4:4:CWidth
                                rAbunTemp=rAbunTemp+Multiply(i,u);
                                if Multiply(i,u)>0
                                    countMP=countMP+1;
                                end
                            end
                            rAbunTemp=rAbunTemp/countMP;
                            if rAbunTemp>rNum(g,2)
                                rNum(g,2)=rAbunTemp;
                            end
                            redIons(rNum(g,1),1:CWidth,g)=Multiply(i,1:CWidth);
                            redIons(rNum(g,1),ConNo*4+1:ConNo*4+3,g)=rFeatureRecorded(g,1:3);
                        end
                    end
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on...']);
                nTapdancer=0;
                nrVisible=0;
                UpperredIonAbun=max(rNum(:,2));
                LowerredIonAbun=min(rNum(:,2));
                GridNumber=nr;
                Interval_UL=(UpperredIonAbun-LowerredIonAbun)/GridNumber;
                redIonAbunSummary=zeros(GridNumber,3);
                for g=1:GridNumber
                    redIonAbunSummary(g,1)=LowerredIonAbun+Interval_UL*(g-1);
                    redIonAbunSummary(g,2)=LowerredIonAbun+Interval_UL*g;
                end
                for g=1:GridNumber
                    for z=1:nr
                        if rNum(z,2)<=redIonAbunSummary(g,2) && rNum(z,2)>=redIonAbunSummary(g,1)
                            redIonAbunSummary(g,3)=redIonAbunSummary(g,3)+1;
                        end
                    end
                end
                if nr>1
                    HorizonNo=max(redIonAbunSummary(1:nr-1,3));
                    for g=GridNumber:-1:1
                        if redIonAbunSummary(g,3)==HorizonNo
                            HorizonAbun=redIonAbunSummary(g,1);
                        end
                    end
                else
                    HorizonAbun=redIonAbunSummary(nr,1);
                end
                
                GILength=size(redIons,1);
                GIWidth=size(redIons,2);
                nTapdancer=0;
                for g=1:nr
                    vht=0;
                    if rNum(g,2)>=HorizonAbun || rNum(g,2)>=0.1
                        DifferIonNumber=0;
                        INTempNo=0;
                        for p=1:GILength
                            for q=1:4:GIWidth-3
                                if redIons(p,q,g)>0
                                    if INTempNo==0
                                        INTempNo=INTempNo+1;
                                        IonNumberTemp(INTempNo,1)=redIons(p,q,g);
                                        IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                    else
                                        vot=0;
                                        for s=1:INTempNo
                                            if abs(IonNumberTemp(INTempNo,1)-redIons(p,q,g))<MassDifferTor
                                                vot=1;
                                                IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                            end
                                        end
                                        if vot==0
                                            INTempNo=INTempNo+1;
                                            IonNumberTemp(INTempNo,1)=redIons(p,q,g);
                                            IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                        end
                                    end
                                end
                            end
                        end
                        
                        if INTempNo>MIMAssocIons
                            for p=1:INTempNo-1
                                nTempDiffer=1;
                                INT_TempDiffer(nTempDiffer,1:size(IonNumberTemp,2))=IonNumberTemp(p,1:size(IonNumberTemp,2));
                                for v=p+1:INTempNo
                                    RepTime=0;
                                    for s=2:size(IonNumberTemp,2);
                                        if INT_TempDiffer(1,s)*IonNumberTemp(v,s)==1
                                            RepTime=RepTime+1;
                                        end
                                    end
                                    if RepTime>=MiMRep
                                        nTempDiffer=nTempDiffer+1;
                                        INT_TempDiffer(nTempDiffer,1:size(IonNumberTemp,2))=IonNumberTemp(v,1:size(IonNumberTemp,2));
                                    end
                                end
                                INT_TempDifferS=unique(INT_TempDiffer,'rows');
                                INT_TempDifferS=sortrows(INT_TempDifferS);
                                INTS=size(INT_TempDifferS,1);
                                if INTS>MIMAssocIons
                                    INT_TempDifferS1(1,1)=INT_TempDifferS(1,1);
                                    DifferIonNumber=1;
                                    for k=2:INTS
                                        if INT_TempDifferS(k,1)-INT_TempDifferS1(DifferIonNumber,1)>3*MassDifferTor
                                            DifferIonNumber=DifferIonNumber+1;
                                            INT_TempDifferS1(DifferIonNumber,1)=INT_TempDifferS(k,1);
                                        end
                                    end
                                    if DifferIonNumber>=MIMAssocIons
                                        vht=1;
                                    end
                                end
                                clear INT_TempDiffer INT_TempDifferS INT_TempDifferS1
                            end
                        end
                        clear IonNumberTemp
                    end
                    if vht==1
                        nTapdancer=nTapdancer+1;
                        TapdancerBYAbun(:,:,nTapdancer)=redIons(:,:,g);
                        Sample_Feature(nTapdancer,1)=g;
                        Sample_Feature(nTapdancer,2)=rNum(g,2);
                    end
                    clear IonNumberTemp IonNumberTempS IonNumberTempS1
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on...']);
                if nTapdancer>0
                    LengthTDBA=size(TapdancerBYAbun,1);
                    WidthTDBA=size(TapdancerBYAbun,2);
                    NoTDBA=size(TapdancerBYAbun,3);
                    save(sprintf('%s%s%s','GRFRSam',num2str(SamID),'N.txt'),'rFeatureRecorded','-ascii');
                    SFLength=size(Sample_Feature,1);
                    dataOutputFull1=Sample_Feature(1:SFLength, 1:2);
                    save(sprintf('%s%s%s','SAFESam',num2str(SamID),'N.txt'),'dataOutputFull1','-ascii');
                    save(sprintf('%s%s%s','TDANSam',num2str(SamID),'N.mat'),'TapdancerBYAbun');
                end
            end
        end
        
        clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo IMI INTDiffer IRT IntensityThreshold MB MBLength MIMAssocIons ...
            MassDifferTor Mats MiMLinearity TimeShortLong SamID SamNoEn SamNoSt TimeDifferTor files iFile ...
            nOfFiles nOfMats t0 t00
        
        t01=cputime-t00;
        disp(['Calculation time = ',num2str(t01), ' seconds', 'Sam',num2str(SamID),'N']);
    end
    LengthRef=0;
    LengthRefMiR=0;
    for ConID=1:ConNo
        for iFile=1:nOfFiles
            if (strcmp( files(iFile).name(1:4),'DENO'))
                MaSuDN(1,1)=0;
                if SamID<10 && ConID<10
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                            && strcmp(files(iFile).name(13),'P')
                        MaSuDN(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                            && strcmp(files(iFile).name(14),'P')
                        MaSuDN(1,1)=2;
                    end
                end
                if SamID>=100 && ConID<10
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                            && strcmp(files(iFile).name(15),'P')
                        MaSuDN(1,1)=3;
                    end
                end
                if SamID<10 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                            && strcmp(files(iFile).name(14),'P')
                        MaSuDN(1,1)=4;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                            && strcmp(files(iFile).name(15),'P')
                        MaSuDN(1,1)=5;
                    end
                end
                if SamID>=100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                            && strcmp(files(iFile).name(16),'P')
                        MaSuDN(1,1)=6;
                    end
                end
                if SamID<10 && ConID>=100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                            && strcmp(files(iFile).name(15),'P')
                        MaSuDN(1,1)=7;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                            && strcmp(files(iFile).name(16),'P')
                        MaSuDN(1,1)=8;
                    end
                end
                if SamID>=100 && ConID>=100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                            && strcmp(files(iFile).name(17),'P')
                        MaSuDN(1,1)=9;
                    end
                end
                if MaSuDN(1,1)>0
                    dataTemp=load(files(iFile).name);
                    LengthTemp=size(dataTemp,1);
                    dataSummary(1:LengthTemp,1,ConID)=dataTemp(1:LengthTemp,1);
                    dataSummary(1:LengthTemp,2,ConID)=dataTemp(1:LengthTemp,2);
                    dataSummary(1:LengthTemp,3,ConID)=dataTemp(1:LengthTemp,7);
                    dataSummary(1:LengthTemp,4,ConID)=dataTemp(1:LengthTemp,12);
                    LengthSummary(ConID,1)=ConID;
                    LengthSummary(ConID,2)=LengthTemp;
                    Ref(LengthRef+1:LengthRef+LengthTemp,1:4)=dataSummary(1:LengthTemp,1:4,ConID);
                    LengthRef=LengthRef+LengthTemp;
                    clear dataTemp;
                end
            end
        end
    end
    t01=cputime-t00;
    disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
        'Con',num2str(ConID),'hold on...']);
    if LengthRef>0
        Ref=sortrows(Ref,1);
        nMultiply=0;
        for i=1:LengthRef
            nFound=0;
            for w=1:size(LengthSummary,1)
                for z=1:LengthSummary(w,2)
                    if abs(dataSummary(z,1,w)-Ref(i,1))<MassDifferTor &&...
                            abs(dataSummary(z,4,w)-Ref(i,4))<1 &&...
                            abs(dataSummary(z,3,w)-Ref(i,3))<INTDiffer
                        
                        nFound=nFound+1;
                        Found(nFound,1:4)=dataSummary(z,1:4,w);
                        Found(nFound,5)=w;
                    end
                end
            end
            if abs(Found(1,1)-326.4)<1
                a=1;
            end
            
            if max(Found(1:nFound,2))>TimeShortLong
                MiMRep=3;
                TimeDiffer=TimeDifferTor;
            else
                MiMRep=3;
                TimeDiffer=TimeDifferTor/2;
            end
            
            if nFound>=MiMRep
                nTimeGood=0;
                for z=1:nFound
                    nSet=1;
                    SetU(nSet,:)=Found(z,:);
                    for z1=1:nFound
                        vot=0;
                        for z2=1:nSet
                            if SetU(z2,5)==Found(z1,5)
                                vot=1;
                            end
                        end
                        if vot==0
                            nSet=nSet+1;
                            SetU(nSet,:)=Found(z1,:);
                        end
                    end
                    for z1=1:nSet
                        nTimeRoutine=1;
                        RefU(nTimeRoutine,:)=SetU(z1,:);
                        for z2=1:nSet
                            if RefU(nTimeRoutine,5)<SetU(z2,5) && RefU(nTimeRoutine,2)-SetU(z2,2)>TimeDiffer
                                nTimeRoutine=nTimeRoutine+1;
                                RefU(nTimeRoutine,:)=SetU(z2,:);
                            end
                        end
                        
                        if max(RefU(1:nTimeRoutine,2))>TimeShortLong
                            MiMRep=3;
                        else
                            MiMRep=3;
                        end
                        
                        if nTimeRoutine>=MiMRep && max(SetU(:,2))-min(SetU(:,2))>2*TimeDiffer
                            nTimeGood=nTimeGood+1;
                            for z3=1:nTimeRoutine
                                TempU(nTimeGood,RefU(z3,5)*4-3:RefU(z3,5)*4)=RefU(z3,1:4);
                            end
                        end
                        clear RefU
                    end
                end
                clear SetU
                if nTimeGood>0
                    nTimeGoodShort=1;
                    TimeGoodWdith=size(TempU,2);
                    TimeGoodShort(nTimeGoodShort,:)=TempU(1,:);
                    for v=2:nTimeGood
                        vot=0;
                        vbt=0;
                        for v1=1:nTimeGoodShort
                            vpt=1;
                            for v2=4:4:TimeGoodWdith
                                if TimeGoodShort(v1,v2-3)*TempU(v,v2-3)~=0
                                    if TimeGoodShort(v1,v2-3)==TempU(v,v2-3) && TimeGoodShort(v1,v2-2)==TempU(v,v2-2) && ...
                                            TimeGoodShort(v1,v2-1)==TempU(v,v2-1) && TimeGoodShort(v1,v2)==TempU(v,v2)
                                        vpt=vpt*2;
                                    else
                                        vpt=vpt*0;
                                    end
                                end
                            end
                            if vpt>1
                                for v3=4:4:TimeGoodWdith
                                    if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                        vbt=1;
                                    end
                                end
                                if vbt==0
                                    for v3=4:4:TimeGoodWdith
                                        if TimeGoodShort(v1,v3-3)==0 && TempU(v,v3-3)~=0
                                            TimeGoodShort(v1,v3-3:v3)=TempU(v,v3-3:v3);
                                        end
                                    end
                                end
                                vot=1;
                            end
                        end
                        if vot==0
                            nTimeGoodShort=nTimeGoodShort+1;
                            TimeGoodShort(nTimeGoodShort,:)=TempU(v,:);
                        end
                    end
                    TGSWidth=size(TimeGoodShort,2);
                    clear TempU;
                    
                    for v=1:nTimeGoodShort
                        Multiply0(nMultiply+v,1:TGSWidth)=TimeGoodShort(v,1:TGSWidth);
                    end
                    nMultiply=nMultiply+nTimeGoodShort;
                    clear TimeGoodShort;
                    
                end
            end
        end
        t01=cputime-t00;
        disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
            'Con',num2str(ConID),'hold on...']);
        if nMultiply>0
            Multiply1=unique(Multiply0,'rows');
            MultiplyLength=size(Multiply1,1);
            MultiplyWidth=size(Multiply1,2);
            nMultiply_Short=0;
            for w=1:MultiplyLength
                for z=2:4:MultiplyWidth
                    if Multiply1(w,z)>0
                        conditionNo=(z+2)/4;
                        for u=2:MBLength
                            if Multiply1(w,z)>MB(u-1,1) && Multiply1(w,z)<=MB(u,1)
                                RatioH2O=(Multiply1(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                u0=u;
                                volH2O(1,conditionNo)=0;
                                for u1=1:u0-1
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                end
                                volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-Multiply1(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-Multiply1(w,z));
                                volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                volMeOH(1,conditionNo)=Multiply1(w,z)-volH2O(1,conditionNo);
                                RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/Multiply1(w,z));
                                lnTime(1,conditionNo)=log10(Multiply1(w,z));
                            end
                        end
                    end
                end
                
                countNo=0;
                for u=1:conditionNo
                    if lnTime(1,u)~=0
                        countNo=countNo+1;
                        RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                        lnTime_PSS(1,countNo)=lnTime(1,u);
                    end
                end
                
                vot=0;
                for z=1:4:MultiplyWidth
                    if Multiply1(w,z)>0 && vot==0
                        pSS(w,1)=Multiply1(w,z);
                        vot=1;
                    end
                end
                pSS(w,2:3)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                
                for z=1:countNo
                    RatioStrongfit2(1,z)=pSS(w,2)*lnTime_PSS(1,z)+pSS(w,3);
                end
                
                R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                pSS(w,4)=R2;
                
                if R2>MiMLinearity
                    nMultiply_Short=nMultiply_Short+1;
                    p2(nMultiply_Short,:)=pSS(w,:);
                    Multiply(nMultiply_Short,:)=Multiply1(w,:);
                end
                
                clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
            end
            t01=cputime-t00;
            disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                'Con',num2str(ConID),'hold on...']);
            if nMultiply_Short>0
                MultiplyTemp=Multiply;
                clear Multiply;
                nMultiply=0;
                BoundaryMinorMajor=0.6;
                for z=1:nMultiply_Short
                    MoM=0;
                    for v=3:4:size(MultiplyTemp,2)
                        if MultiplyTemp(z,v)>=BoundaryMinorMajor
                            MoM=1;
                        end
                    end
                    if MoM==0
                        nMultiply=nMultiply+1;
                        Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                    else
                        oMo=0;
                        NoMass=0;
                        AveMass=0;
                        for v=1:4:size(MultiplyTemp,2)
                            if MultiplyTemp(z,v)>0
                                AveMass=AveMass+MultiplyTemp(z,v);
                                NoMass=NoMass+1;
                            end
                        end
                        AveMass=AveMass/NoMass;
                        
                        for u=1:size(MultiplyTemp,1)
                            if oMo==0
                                for v=1:4:size(MultiplyTemp,2)
                                    if abs(AveMass-MultiplyTemp(u,v))<MassDifferTor && MultiplyTemp(u,v+2)==1
                                        oMo=1;
                                    end
                                end
                            end
                        end
                        
                        if oMo==1
                            nMultiply=nMultiply+1;
                            Multiply(nMultiply,1:size(MultiplyTemp,2))=MultiplyTemp(z,1:size(MultiplyTemp,2));
                        end
                    end
                end
                nMultiply=size(Multiply,1);
                CWidth=size(Multiply,2);
                nr=1;
                condition=0;
                for i=2:4:CWidth
                    condition=condition+1;
                    rFeature(nr,condition)=Multiply(1,i);
                end
                for i=2:nMultiply
                    condition=0;
                    for j=2:4:CWidth
                        condition=condition+1;
                        Temp(1,condition)=Multiply(i,j);
                    end
                    Temp2=Temp';
                    if min(Temp2)<2*t0
                        TimeDiffer=TimeDifferTor/2;
                    else
                        TimeDiffer=TimeDifferTor;
                    end
                    vot=0;
                    vbt=0;
                    
                    for z=1:nr
                        vmt=0;
                        vpt=1;
                        for u=1:condition
                            if Temp(1,u)*rFeature(z,u)~=0
                                if abs(Temp(1,u)-rFeature(z,u))<TimeDiffer
                                    vpt=vpt*2;
                                else
                                    vpt=vpt*0;
                                end
                            end
                            if abs(Temp(1,u)-rFeature(z,u))>=TimeDiffer
                                vmt=1;
                            end
                        end
                        if vmt==0
                            vot=1;
                        end
                        if vpt>1 && vmt==1
                            for u=1:condition
                                if Temp(1,u)~=0 && rFeature(z,u)==0
                                    if (u==1 && Temp(1,u)-rFeature(z,u+1)>TimeDiffer && rFeature(z,u+1)~=0)||...
                                            (u==condition && rFeature(z,u-1)-Temp(1,u)>TimeDiffer) ||...
                                            (u<condition && u>1 && rFeature(z,u-1)-Temp(1,u)>TimeDiffer...
                                            && Temp(1,u)-rFeature(z,u+1)>TimeDiffer && rFeature(z,u+1)~=0)
                                        rFeature(z,u)=Temp(1,u);
                                        vot=1;
                                    end
                                end
                            end
                        end
                    end
                    if vot==0
                        nr=nr+1;
                        condition=0;
                        for v=2:4:CWidth
                            condition=condition+1;
                            rFeature(nr,condition)=Multiply(i,v);
                        end
                    end
                    clear Temp Temp2
                end
                rFeature_Short=unique(rFeature,'rows');
                clear rFeature
                rFeature=rFeature_Short;
                nr=size(rFeature,1);
                
                for w=1:nr
                    for z=1:size(rFeature,2)
                        if rFeature(w,z)>0
                            conditionNo=z;
                            for u=2:MBLength
                                if rFeature(w,z)>MB(u-1,1) && rFeature(w,z)<=MB(u,1)
                                    RatioH2O=(rFeature(w,z)-MB(u-1,1))*((MB(u,conditionNo+1)-MB(u-1,conditionNo+1))/(MB(u,1)-MB(u-1,1)))+MB(u-1,conditionNo+1);
                                    u0=u;
                                    volH2O(1,conditionNo)=0;
                                    for u1=1:u0-1
                                        volH2O(1,conditionNo)=volH2O(1,conditionNo)+MB(u1+1,conditionNo+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,conditionNo+1)-MB(u1,conditionNo+1))*(MB(u1+1,1)-MB(u1,1));
                                    end
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)-(MB(u0,1)-rFeature(w,z))*MB(u0,conditionNo+1)+(MB(u0,conditionNo+1)-RatioH2O)*(MB(u0,1)-rFeature(w,z));
                                    volH2O(1,conditionNo)=volH2O(1,conditionNo)/100;
                                    volMeOH(1,conditionNo)=rFeature(w,z)-volH2O(1,conditionNo);
                                    RatioStrong(1,conditionNo)=log10(volH2O(1,conditionNo)/rFeature(w,z));
                                    lnTime(1,conditionNo)=log10(rFeature(w,z));
                                end
                            end
                        end
                    end
                    
                    countNo=0;
                    for u=1:conditionNo
                        if lnTime(1,u)~=0
                            countNo=countNo+1;
                            RatioStrong_PSS(1,countNo)=RatioStrong(1,u);
                            lnTime_PSS(1,countNo)=lnTime(1,u);
                        end
                    end
                    
                    
                    pSS(w,1:2)=polyfit(lnTime_PSS,RatioStrong_PSS,1);
                    
                    for z=1:countNo
                        RatioStrongfit2(1,z)=pSS(w,1)*lnTime_PSS(1,z)+pSS(w,2);
                    end
                    
                    R2 = norm(RatioStrongfit2 -mean(RatioStrong_PSS))^2/norm(RatioStrong_PSS - mean(RatioStrong_PSS))^2;
                    pSS(w,3)=R2;
                    
                    rFeatureRecorded(w,:)=pSS(w,:);
                    
                    clear lnTime RatioStrong volMeOH volH2O RatioStrong_PSS lnTime_PSS RatioStrongfit2 pSS
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on...']);
                rNum=zeros(nr,2);
                for g=1:nr
                    for i=1:nMultiply
                        condition=0;
                        vht=0;
                        for j=2:4:CWidth
                            condition=condition+1;
                            if abs(Multiply(i,j)-rFeature(g,condition))>TimeDifferTor && Multiply(i,j)*rFeature(g,condition)~=0
                                vht=1;
                            end
                            if Multiply(i,j)~=0 && rFeature(g,condition)==0
                                if (condition==1 && Multiply(i,j)-rFeature(g,condition+1)<=TimeDifferTor)||...
                                        (condition==CWidth/4 && rFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor)||...
                                        (condition<CWidth/4 && condition>1 && (rFeature(g,condition-1)-Multiply(i,j)<=TimeDifferTor ||...
                                        Multiply(i,j)-rFeature(g,condition+1)<=TimeDifferTor))
                                    vht=1;
                                end
                            end
                            if Multiply(i,j)==0 && rFeature(g,condition)~=0
                                if (condition==1 && rFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor)||...
                                        (condition==CWidth/4 && Multiply(i,j-4)-rFeature(g,condition)<=TimeDifferTor)||...
                                        (condition<CWidth/4 && condition>1 && (Multiply(i,j-4)-rFeature(g,condition)<=TimeDifferTor ||...
                                        rFeature(g,condition)-Multiply(i,j+4)<=TimeDifferTor))
                                    vht=1;
                                end
                            end
                        end
                        if vht==0;
                            rNum(g,1)=rNum(g,1)+1;
                            rAbunTemp=0;
                            countMP=0;
                            for u=4:4:CWidth
                                rAbunTemp=rAbunTemp+Multiply(i,u);
                                if Multiply(i,u)>0
                                    countMP=countMP+1;
                                end
                            end
                            rAbunTemp=rAbunTemp/countMP;
                            if rAbunTemp>rNum(g,2)
                                rNum(g,2)=rAbunTemp;
                            end
                            redIons(rNum(g,1),1:CWidth,g)=Multiply(i,1:CWidth);
                            redIons(rNum(g,1),ConNo*4+1:ConNo*4+3,g)=rFeatureRecorded(g,1:3);
                        end
                    end
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on...']);
                nTapdancer=0;
                nrVisible=0;
                UpperredIonAbun=max(rNum(:,2));
                LowerredIonAbun=min(rNum(:,2));
                GridNumber=nr;
                Interval_UL=(UpperredIonAbun-LowerredIonAbun)/GridNumber;
                redIonAbunSummary=zeros(GridNumber,3);
                for g=1:GridNumber
                    redIonAbunSummary(g,1)=LowerredIonAbun+Interval_UL*(g-1);
                    redIonAbunSummary(g,2)=LowerredIonAbun+Interval_UL*g;
                end
                for g=1:GridNumber
                    for z=1:nr
                        if rNum(z,2)<=redIonAbunSummary(g,2) && rNum(z,2)>=redIonAbunSummary(g,1)
                            redIonAbunSummary(g,3)=redIonAbunSummary(g,3)+1;
                        end
                    end
                end
                if nr>1
                    HorizonNo=max(redIonAbunSummary(1:nr-1,3));
                    for g=GridNumber:-1:1
                        if redIonAbunSummary(g,3)==HorizonNo
                            HorizonAbun=redIonAbunSummary(g,1);
                        end
                    end
                else
                    HorizonAbun=redIonAbunSummary(nr,1);
                end
                
                GILength=size(redIons,1);
                GIWidth=size(redIons,2);
                nTapdancer=0;
                for g=1:nr
                    vht=0;
                    if rNum(g,2)>=HorizonAbun || rNum(g,2)>=0.1
                        DifferIonNumber=0;
                        INTempNo=0;
                        for p=1:GILength
                            for q=1:4:GIWidth-3
                                if redIons(p,q,g)>0
                                    if INTempNo==0
                                        INTempNo=INTempNo+1;
                                        IonNumberTemp(INTempNo,1)=redIons(p,q,g);
                                        IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                    else
                                        vot=0;
                                        for s=1:INTempNo
                                            if abs(IonNumberTemp(INTempNo,1)-redIons(p,q,g))<MassDifferTor
                                                vot=1;
                                                IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                            end
                                        end
                                        if vot==0
                                            INTempNo=INTempNo+1;
                                            IonNumberTemp(INTempNo,1)=redIons(p,q,g);
                                            IonNumberTemp(INTempNo,(q-1)/4+2)=1;
                                        end
                                    end
                                end
                            end
                        end
                        
                        if INTempNo>MIMAssocIons
                            for p=1:INTempNo-1
                                nTempDiffer=1;
                                INT_TempDiffer(nTempDiffer,1:size(IonNumberTemp,2))=IonNumberTemp(p,1:size(IonNumberTemp,2));
                                for v=p+1:INTempNo
                                    RepTime=0;
                                    for s=2:size(IonNumberTemp,2);
                                        if INT_TempDiffer(1,s)*IonNumberTemp(v,s)==1
                                            RepTime=RepTime+1;
                                        end
                                    end
                                    if RepTime>=MiMRep
                                        nTempDiffer=nTempDiffer+1;
                                        INT_TempDiffer(nTempDiffer,1:size(IonNumberTemp,2))=IonNumberTemp(v,1:size(IonNumberTemp,2));
                                    end
                                end
                                INT_TempDifferS=unique(INT_TempDiffer,'rows');
                                INT_TempDifferS=sortrows(INT_TempDifferS);
                                INTS=size(INT_TempDifferS,1);
                                if INTS>MIMAssocIons
                                    INT_TempDifferS1(1,1)=INT_TempDifferS(1,1);
                                    DifferIonNumber=1;
                                    for k=2:INTS
                                        if INT_TempDifferS(k,1)-INT_TempDifferS1(DifferIonNumber,1)>3*MassDifferTor
                                            DifferIonNumber=DifferIonNumber+1;
                                            INT_TempDifferS1(DifferIonNumber,1)=INT_TempDifferS(k,1);
                                        end
                                    end
                                    if DifferIonNumber>=MIMAssocIons
                                        vht=1;
                                    end
                                end
                                clear INT_TempDiffer INT_TempDifferS INT_TempDifferS1
                            end
                        end
                        clear IonNumberTemp
                    end
                    if vht==1
                        nTapdancer=nTapdancer+1;
                        TapdancerBYAbun(:,:,nTapdancer)=redIons(:,:,g);
                        Sample_Feature(nTapdancer,1)=g;
                        Sample_Feature(nTapdancer,2)=rNum(g,2);
                    end
                    clear IonNumberTemp IonNumberTempS IonNumberTempS1
                end
                t01=cputime-t00;
                disp(['mass cycling time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID),...
                    'Con',num2str(ConID),'hold on...']);
                if nTapdancer>0
                    LengthTDBA=size(TapdancerBYAbun,1);
                    WidthTDBA=size(TapdancerBYAbun,2);
                    NoTDBA=size(TapdancerBYAbun,3);
                    save(sprintf('%s%s%s','GRFRSam',num2str(SamID),'P.txt'),'rFeatureRecorded','-ascii');
                    SFLength=size(Sample_Feature,1);
                    dataOutputFull1=Sample_Feature(1:SFLength, 1:2);
                    save(sprintf('%s%s%s','SAFESam',num2str(SamID),'P.txt'),'dataOutputFull1','-ascii');
                    save(sprintf('%s%s%s','TDANSam',num2str(SamID),'P.mat'),'TapdancerBYAbun');
                end
            end
        end
        
        clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo IMI INTDiffer IRT IntensityThreshold MB MBLength MIMAssocIons ...
            MassDifferTor Mats MiMLinearity TimeShortLong SamID SamNoEn SamNoSt TimeDifferTor files iFile ...
            nOfFiles nOfMats t0 t00
        
        t01=cputime-t00;
        disp(['Calculation time = ',num2str(t01), ' seconds', 'Sam',num2str(SamID),'P']);
    end
end
t01=cputime-t00;
disp(['Calculation time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);

RedundantIons=4;
NosEliDiffer=IMI;
TimeVariance=TimeDifferTor/ConNo;
rDifferRatioControl=0.5;
files = dir(fullfile('.', '*.txt'));
[nOfFiles,~] = size(files);
Mats = dir(fullfile('.', '*.mat'));
[nOfMats,~]=size(Mats);
for SamID=SamNoSt:SamNoEn
    TIRALength=0;
    for iFile=1:nOfFiles
        for ConID=1:ConNo
            if (strcmp(files(iFile).name(1:3),'Sam'))
                MaSuUV(1,1)=0;
                if SamID<10 && ConID<10
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                            && strcmp(files(iFile).name(9),'.')
                        MaSuUV(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                            && strcmp(files(iFile).name(10),'.')
                        MaSuUV(1,1)=2;
                    end
                end
                if SamID>=100 && ConID<10
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=3;
                    end
                end
                if SamID<10 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                            && strcmp(files(iFile).name(10),'.')
                        MaSuUV(1,1)=4;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=5;
                    end
                end
                if SamID>=100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                            && strcmp(files(iFile).name(12),'.')
                        MaSuUV(1,1)=6;
                    end
                end
                if SamID<10 && ConID>=100
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=7;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=100
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                            && strcmp(files(iFile).name(12),'.')
                        MaSuUV(1,1)=8;
                    end
                end
                if SamID>=100 && ConID>=100
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                            && strcmp(files(iFile).name(13),'.')
                        MaSuUV(1,1)=9;
                    end
                end
                if MaSuUV(1,1)>0
                    UVTemp=load(files(iFile).name);
                    UVTempLS=size(UVTemp,1);
                    TIRA(ConID,1)=ConID;
                    TIRA(ConID,2) =UVTemp(UVTempLS,1);
                    TIRALength=size(TIRA,1);
                end
            end;
        end;
    end;
    if TIRALength>0
        nr=0;nFeature=0;DRLength=0;
        for iFile=1:nOfFiles
            if strcmp( files(iFile).name(1:4),'GRFR')
                MaSuGF(1,1)=0;
                if SamID<10
                    if str2double(files(iFile).name(8))==SamID ...
                            && (strcmp(files(iFile).name(9),'N'))
                        MaSuGF(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID ...
                            && (strcmp(files(iFile).name(10),'N'))
                        MaSuGF(1,1)=2;
                    end
                end
                if SamID>=100
                    if str2double(files(iFile).name(8:10))==SamID ...
                            && (strcmp(files(iFile).name(11),'N'))
                        MaSuGF(1,1)=3;
                    end
                end
                
                if MaSuGF(1,1)>0
                    rFeatureRecord=load(files(iFile).name);
                    nr=size(rFeatureRecord,1);
                end
            end
        end
        
        
        for iFile=1:nOfFiles
            if strcmp( files(iFile).name(1:4),'SAFE')
                MaSuSF(1,1)=0;
                if SamID<10
                    if str2double(files(iFile).name(8))==SamID ...
                            && (strcmp(files(iFile).name(9),'N'))
                        MaSuSF(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID ...
                            && (strcmp(files(iFile).name(10),'N'))
                        MaSuSF(1,1)=2;
                    end
                end
                if SamID>=100
                    if str2double(files(iFile).name(8:10))==SamID ...
                            && (strcmp(files(iFile).name(11),'N'))
                        MaSuSF(1,1)=3;
                    end
                end
                
                if MaSuSF(1,1)>0
                    Sample_Feature=load(files(iFile).name);
                    nFeature=size(Sample_Feature,1);
                end
            end
        end
        
        for iMatRef=1:nOfMats
            rE_Vis_Mark=0;
            if strcmp( Mats(iMatRef).name(1:4),'TDAN')
                MaSuMa(1,1)=0;
                if SamID<10
                    if str2double(Mats(iMatRef).name(8))==SamID ...
                            && (strcmp(Mats(iMatRef).name(9),'N'))
                        MaSuMa(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100
                    if str2double(Mats(iMatRef).name(8:9))==SamID ...
                            && (strcmp(Mats(iMatRef).name(10),'N'))
                        MaSuMa(1,1)=2;
                    end
                end
                if SamID>=100
                    if str2double(Mats(iMatRef).name(8:10))==SamID ...
                            && (strcmp(Mats(iMatRef).name(11),'N'))
                        MaSuMa(1,1)=3;
                    end
                end
                if MaSuMa(1,1)>0
                    dataRef = load(Mats(iMatRef).name);
                    Refdata=dataRef.TapdancerBYAbun;
                    DRLength=size(Refdata);
                    if size(DRLength,2)==2
                        DRLength(1,3)=1;
                    end
                end
            end
        end
        if nr*nFeature*DRLength(1,1)~=0
            rE_Vis_Mark=0;
            con_count=0;
            for d2=1:4:DRLength(1,2)-3
                con_count=con_count+1;
                ion_count_present=0;
                ion_count_table_row=0;
                for d3=1:DRLength(1,3)
                    ion_count=0;
                    ion_count_table=0;
                    for d1=1:DRLength(1,1)
                        if Refdata(d1,d2,d3)>0
                            ion_count=ion_count+1;
                            ionSummary_Temp(ion_count,1:4)=Refdata(d1,d2:d2+3,d3);
                            ionSummary_Temp(ion_count,5:7)=Refdata(d1,ConNo*4+1:ConNo*4+3,d3);
                            ionSummary_Temp(ion_count,8)=d3;
                        end
                        
                    end
                    
                    if ion_count>1
                        ionSummary_Temp00=unique(ionSummary_Temp,'rows');
                        clear ionSummary_Temp
                        ionSummary_Temp00=sortrows(ionSummary_Temp00,1);
                        iTemp=1;
                        ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(1,:);
                        for u=2:size(ionSummary_Temp00,1)
                            vot=0;
                            if ionSummary_Temp00(u,1)-ionSummary_Temp0(iTemp,1)>=IMI && vot==0
                                iTemp=iTemp+1;
                                ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(u,:);
                            end
                        end
                        
                        
                        if iTemp>=MIMAssocIons
                            clear ionSummary_Temp0
                            if iTemp>RedundantIons
                                ionSummary_Temp0(:,1:3)=ionSummary_Temp00(:,1:3);
                                ionSummary_Temp010=unique(ionSummary_Temp0,'rows');
                                GridNumber=size(ionSummary_Temp010,1);
                                ISTHigh=max(ionSummary_Temp010(:,3));
                                ISTLow=min(ionSummary_Temp010(:,3));
                                
                                Interval_UL=(ISTHigh-ISTLow)/GridNumber;
                                redIonAbunSummary=zeros(GridNumber,3);
                                
                                for g=1:GridNumber
                                    redIonAbunSummary(g,1)=ISTLow+Interval_UL*(g-1);
                                    redIonAbunSummary(g,2)=ISTLow+Interval_UL*g;
                                end
                                
                                for g=1:GridNumber
                                    for z=1:size(ionSummary_Temp010,1)
                                        if ionSummary_Temp010(z,3)<=redIonAbunSummary(g,2) ...
                                                && ionSummary_Temp010(z,3)>=redIonAbunSummary(g,1)
                                            redIonAbunSummary(g,3)=redIonAbunSummary(g,3)+1;
                                        end
                                    end
                                end
                                HorizonNo=max(redIonAbunSummary(:,3));
                                for g=GridNumber:-1:1
                                    if redIonAbunSummary(g,3)==HorizonNo
                                        HorizonAbun=redIonAbunSummary(g,1);
                                    end
                                end
                                
                                ThresholdAbun_Presented=HorizonAbun;
                                clear ionSummary_Temp010
                            else
                                ThresholdAbun_Presented=0;
                            end
                            for z=1:size(ionSummary_Temp00,1)
                                if ionSummary_Temp00(z,3)>=ThresholdAbun_Presented
                                    ion_count_table=ion_count_table+1;
                                    ionSummary_Temp1(ion_count_table,:)=ionSummary_Temp00(z,:);
                                end
                            end
                            if ion_count_table>0
                                ion_count_table_row=ion_count_table_row+1;
                                RetentionTime=sum(ionSummary_Temp1(:,2))/ion_count_table;
                                IonInfor_Table(ion_count_table_row,1)=d3;
                                IonInfor_Table(ion_count_table_row,2)=RetentionTime;
                                for z=1:ion_count_table
                                    IonInfor_Table(ion_count_table_row,2+5*z-4)=ionSummary_Temp1(z,1);
                                    IonInfor_Table(ion_count_table_row,2+5*z-3)=ionSummary_Temp1(z,3);
                                    IonInfor_Table(ion_count_table_row,2+5*z-2)=ionSummary_Temp1(z,5);
                                    IonInfor_Table(ion_count_table_row,2+5*z-1)=ionSummary_Temp1(z,6);
                                    IonInfor_Table(ion_count_table_row,2+5*z)=ionSummary_Temp1(z,7);
                                end
                                rE_Vis_Mark=1;
                                
                            end
                        end
                    end
                    clear ionSummary_Temp0 ionSummary_Temp00 RepNosIon ionSummary_Temp ionSummary_Temp1 ...
                        ionSummary_Temp2 ionSummary_Temp3 ionSummary_Temp4 redIonAbunSummary
                end
                if ion_count_table_row>0
                    IonInfor_Table0=unique(IonInfor_Table,'rows');
                    T0Length=size(IonInfor_Table0,1);
                    T0Width=size(IonInfor_Table0,2);
                    IonInfor_Table_Short0(1:T0Length,1:T0Width,con_count)=IonInfor_Table0(1:T0Length,1:T0Width);
                    clear IonInfor_Table0 IonInfor_Table
                end
            end
            if rE_Vis_Mark==1
                ionConNoMax=0;
                TableIndex=size(IonInfor_Table_Short0);
                if size(TableIndex,2)<3
                    TableIndex(1,3)=1;
                end
                GEC=0;ISEC=0;
                for d3=1:TableIndex(1,3)
                    GEC1=0;
                    TTT(1:TableIndex(1,1),1:TableIndex(1,2))=IonInfor_Table_Short0(1:TableIndex(1,1),1:TableIndex(1,2),d3);
                    for k=1:TableIndex(1,1)
                        iTTT=0;
                        if TTT(k,1)>0
                            for u=3:5:TableIndex(1,2)
                                if TTT(k,u)>0
                                    iTTT=iTTT+1;
                                    TTT2(iTTT,1:2)=TTT(k,u:u+1);
                                end
                            end
                            TTT3=unique(TTT2,'rows');
                            iTT=size(TTT3,1);
                            IonInfor_Table_Short_Derep(k,1:2,d3)=IonInfor_Table_Short0(k,1:2,d3);
                            for u=1:iTT
                                IonInfor_Table_Short_Derep(k,u*2+1:u*2+2,d3)=TTT3(u,1:2);
                                GEC1=1;
                            end
                        end
                        clear TTT2 TTT3
                    end
                    clear TTT
                    
                    if GEC1>0
                        TableIndex_Derep=size(IonInfor_Table_Short_Derep);
                        if size(TableIndex_Derep,2)<3
                            TableIndex_Derep(1,3)=1;
                        end
                        
                        
                        ionConNo=0;
                        rNo=0;
                        for d1=1:TableIndex_Derep(1,1)
                            if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                rNo=rNo+1;
                            end
                        end
                        
                        if rNo>0
                            str= sprintf('%s%s%s%s%s%s','GINFSam', num2str(SamID),'Con',num2str(d3),'N','.txt');
                            fid=fopen(str,'w');
                            IonIntNo=0;
                            for d1=1:TableIndex_Derep(1,1)
                                if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                    for d2=3:2:TableIndex_Derep(1,2)
                                        if IonInfor_Table_Short_Derep(d1,d2,d3)>0
                                            Code=Sample_Feature(IonInfor_Table_Short_Derep(d1,1,d3),1);
                                            FeatureWriteHere(1,1:3)=rFeatureRecord(Code,1:3);
                                            fprintf(fid,'%d %.1f ',d1,IonInfor_Table_Short_Derep(d1,2,d3));
                                            for z=1:3
                                                fprintf(fid,'%.4f ',FeatureWriteHere(1,z));
                                            end
                                            ionConNo=ionConNo+1;
                                            ionSummary001(ionConNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                            IonIntNo=IonIntNo+1;
                                            ionSummary0001(IonIntNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                            fprintf(fid,'%.1f %.4f ',IonInfor_Table_Short_Derep(d1,d2,d3),IonInfor_Table_Short_Derep(d1,d2+1,d3));
                                            fprintf(fid,'\n');
                                        end
                                    end
                                    if IonIntNo>0
                                        maxIonInt=max(ionSummary0001(:,2));
                                        maxIon(1,4)=0;
                                        for z=1:IonIntNo
                                            if maxIonInt==ionSummary0001(z,2)
                                                maxIon(1,3)=ionSummary0001(z,1);
                                            end
                                            maxIon(1,4)=maxIon(1,4)+ionSummary0001(z,2);
                                        end
                                        rIntSum(d1,1:2,d3)=IonInfor_Table_Short_Derep(d1,1:2,d3);
                                        rIntSum(d1,3:4,d3)=maxIon(1,3:4);
                                        GEC=1;
                                    end
                                    clear ionSummary0001 maxIon
                                end
                            end
                            fclose(fid);
                            clear IonInfor_Table_Short_Derep
                        end
                        if ionConNo>0
                            ionSummary002=unique(ionSummary001,'rows');
                            ionSummary002=sortrows(ionSummary002,1);
                            ionSummary(1:size(ionSummary002,1),d3)=ionSummary002(:,1);
                            ISEC=1;
                        end
                        clear ionSummary001 ionSummary002 ionSummary003
                        if ionConNo>ionConNoMax
                            ionConNoMax=ionConNo;
                        end
                    end
                end
                clear TableIndex
                if GEC>0
                    TableIndex=size(rIntSum);
                    if size(TableIndex)==2
                        TableIndex(1,3)=1;
                    end
                    
                    str= sprintf('%s%s%s','GREPSam',num2str(SamID),'N.txt');
                    fid=fopen(str,'w');
                    for d3=1:TableIndex(1,3)
                        ionConNo=0;
                        rNo=0;
                        for d1=1:TableIndex(1,1)
                            if rIntSum(d1,1,d3)>0
                                rNo=rNo+1;
                            end
                        end
                        if rNo>0
                            fprintf(fid,'%s%s%s%s','Totally ',num2str(rNo),' rs apparently visible under condition G',num2str(d3));
                            fprintf(fid,'\n');
                            for d1=1:TableIndex(1,1)
                                if rIntSum(d1,1,d3)>0
                                    fprintf(fid,'%d %d ',d1,rIntSum(d1,1,d3));
                                    fprintf(fid,'%.1f ',rIntSum(d1,2,d3));
                                    fprintf(fid,'%.1f %.4f ',rIntSum(d1,3:4,d3));
                                    fprintf(fid,'\n');
                                end
                            end
                        end
                        fprintf(fid,'\n');
                    end
                    fclose(fid);
                    clear rIntSum
                end
                clear IonInfor_Table_Short ionSummary001 ionSummary002
                
                if ISEC>0
                    DCLength=size(ionSummary,1);
                    DCWidth=size(ionSummary,2);
                    nMerge=0;
                    for v=1:DCWidth
                        for u=1:DCLength
                            if ionSummary(u,v)>0
                                nMerge=nMerge+1;
                                MergedIonSummary(nMerge,1)=ionSummary(u,v);
                            end
                        end
                    end
                    MergedIonSummary_Short=unique(MergedIonSummary,'rows');
                    MergedIonSummary_Short=sortrows(MergedIonSummary_Short);
                    DCLength=size(MergedIonSummary_Short,1);
                    
                    clear ionSummary
                    for v=1:DCWidth
                        ionSummary(1:DCLength,v)=MergedIonSummary_Short;
                    end
                end
                if ionConNoMax>0
                    for ConID=1:DCWidth
                        XICSNLength=0;
                        for iMat=1:nOfMats
                            if strcmp( Mats(iMat).name(1:3),'Sam')
                                MaSuMa(1,1)=0;
                                if SamID<10 && ConID<10
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                            && (strcmp(Mats(iMat).name(9),'N'))...
                                            && strcmp(Mats(iMat).name(10),'.')
                                        MaSuMa(1,1)=1;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID<10
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'N'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=2;
                                    end
                                end
                                if SamID>=100 && ConID<10
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=3;
                                    end
                                end
                                if SamID<10 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'N'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=4;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=5;
                                    end
                                end
                                if SamID>=100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'N'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=6;
                                    end
                                end
                                if SamID<10 && ConID>=100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'N'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=7;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'N'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=8;
                                    end
                                end
                                if SamID>=100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                            && (strcmp(Mats(iMat).name(13),'N'))...
                                            && strcmp(Mats(iMat).name(14),'.')
                                        MaSuMa(1,1)=9;
                                    end
                                end
                                if MaSuMa(1,1)>0
                                    data = load(Mats(iMat).name);
                                    Scans=data.Scans;
                                    dataWidth=size(Scans,2);
                                    MergeMass=data.Masses;
                                    dataLength=size(MergeMass,1);
                                    MergeData=data.Data;
                                    Timerange=TIRA(ConID,2);
                                    Data_New=MergeData;
                                    XIC=zeros(dataWidth,2);
                                    MergeTime=Scans(1,:)*Timerange/Scans(1,size(Scans,2));
                                    nCount=0;
                                    for r=1:DCLength
                                        if ionSummary(r,ConID)>0
                                            for h=MassRange+1:dataLength-MassRange
                                                if abs(ionSummary(r,ConID)-MergeMass(h,1))<IMI
                                                    for j=1:dataWidth
                                                        XIC(j,1)=MergeTime(1,j);
                                                        XIC(j,2)=sum(Data_New(h-MassRange:h+MassRange,j));
                                                    end
                                                    XICSN=XIC;
                                                    HighPoint=max(XICSN(:,2));
                                                    LowPoint=min(XICSN(:,2));
                                                    sectionNo=100;
                                                    Incre=(HighPoint-LowPoint)/sectionNo;
                                                    section=zeros(sectionNo,3);
                                                    
                                                    for i=1:sectionNo
                                                        section(i,1)=Incre*(i-1)+LowPoint;
                                                        section(i,2)=Incre*i+LowPoint;
                                                        section(i,3)=0;
                                                    end
                                                    XICSNLength=size(XICSN,1);
                                                    for j=1:XICSNLength
                                                        for u=1:sectionNo
                                                            if XICSN(j,2)>=section(u,1) && XICSN(j,2)<section(u,2)
                                                                section(u,3)=section(u,3)+1;
                                                            end
                                                        end
                                                    end
                                                    chooseSection=max(section(2:sectionNo,3));
                                                    for i=2:sectionNo
                                                        if section(i,3)==chooseSection
                                                            baselineLow=section(i,1);
                                                            baselineHigh=section(i,2);
                                                        end
                                                    end
                                                    BaseLineValue=0;
                                                    count=0;
                                                    for i=1:XICSNLength
                                                        if XICSN(i,2)>=baselineLow && XICSN(i,2)<baselineHigh
                                                            BaseLineValue=BaseLineValue+XICSN(i,2);
                                                            count=count+1;
                                                        end
                                                    end
                                                    BaseLineValue=BaseLineValue/count;
                                                    XICSN=XICSN';
                                                    FH=round(TIRA(ConID,2)*2.5*log10(dataWidth));
                                                    ATH=size(XICSN,2);
                                                    Ratio=round(ATH/FH);
                                                    if Ratio>=1
                                                        iCol=0;
                                                        for k=1:Ratio:ATH-Ratio
                                                            iCol=iCol+1;
                                                            XICSN_New(2,iCol)=sum(XICSN(2,k:k+Ratio-1));
                                                            XICSN_New(1,iCol)=0.5*(XICSN(1,k)+XICSN(1,k+Ratio-1));
                                                        end
                                                    else
                                                        Ratio2=round(FH/ATH);
                                                        iCol=Ratio2*ATH;
                                                        for o=1:dataWidth
                                                            XICSN_New(1,o*Ratio2-Ratio2+1:o*Ratio2)=XICSN(1,o);
                                                            XICSN_New(2,o*Ratio2-Ratio2+1:o*Ratio2)=XICSN(2,o);
                                                        end
                                                    end
                                                    
                                                    XICSN_New=XICSN_New';
                                                    fr = FH/16;
                                                    dt = (16/FH)^2;
                                                    rick = ricker(FH,fr,dt,20);
                                                    rick_smooth = getSmoothRicker(rick);
                                                    smoothXIC0  = conv( rick_smooth(:,1),XICSN_New(:,2) );
                                                    smoothXIC(:,1)=XICSN_New(:,1);
                                                    smoothXIC(:,2)=smoothXIC0( round(length(rick_smooth)/2)+1:length(XICSN_New(:,2))+round(length(rick_smooth)/2));
                                                    smoothXICLength=size(smoothXIC,1);
                                                    EThreshold=0.01;
                                                    EPointGSNo=0;
                                                    HighPoint=max(smoothXIC(:,2));
                                                    for i=2:smoothXICLength-1
                                                        if smoothXIC(i,2)>=smoothXIC(i-1,2) && smoothXIC(i,2)>=smoothXIC(i+1,2) && smoothXIC(i,2)> HighPoint*EThreshold && (smoothXIC(i,2)-smoothXIC(i-1,2))+(smoothXIC(i,2)-smoothXIC(i+1,2))~=0
                                                            EPointGSNo=EPointGSNo+1;
                                                            EPointGS(EPointGSNo,1) = smoothXIC(i,1);
                                                            EPointGS(EPointGSNo,2) = smoothXIC(i,2);
                                                        end;
                                                    end;
                                                    BaseLineTolerance=0.01;
                                                    nEInfor=0;
                                                    if EPointGSNo>0
                                                        for m=1:EPointGSNo
                                                            ETime=EPointGS(m,1);
                                                            EHight=EPointGS(m,2);
                                                            EPosition(1,1)=EPointGS(m,1);
                                                            EPosition(1,2)=EPointGS(m,2);
                                                            halfPH=EHight/2;
                                                            
                                                            for z=1:smoothXICLength
                                                                if smoothXIC(z,1)==ETime
                                                                    PP=z;
                                                                end;
                                                            end;
                                                            
                                                            vbv1=0;
                                                            for z=PP:-1:2
                                                                if smoothXIC(z,2)>=0 && smoothXIC(z-1,2)<=0 && vbv1==0
                                                                    CrossZeroLeft=smoothXIC(z,1);
                                                                    LeftIndex=z;
                                                                    vbv1=1;
                                                                end;
                                                            end;
                                                            
                                                            if vbv1==0
                                                                CrossZeroLeft=0;
                                                                LeftIndex=1;
                                                            end;
                                                            
                                                            vbv2=0;
                                                            for z=PP:smoothXICLength-1
                                                                if smoothXIC(z,2)>=0 && smoothXIC(z+1,2)<=0 && vbv2==0
                                                                    CrossZeroRight=smoothXIC(z,1);
                                                                    RightIndex=z;
                                                                    vbv2=1;
                                                                end;
                                                            end;
                                                            
                                                            if vbv2==0
                                                                CrossZeroRight=smoothXIC(smoothXICLength,1);
                                                                RightIndex=smoothXICLength;
                                                            end;
                                                            
                                                            EPointGS(m,3)=CrossZeroLeft;
                                                            EPointGS(m,4)=CrossZeroRight;
                                                            EPointGS(m,5)=(CrossZeroRight-CrossZeroLeft)/TIRA(ConID,2);
                                                            EPointGS(m,6)=EHight/HighPoint;
                                                            EPointGS(m,7)=EPointGS(m,6)/EPointGS(m,5);
                                                            
                                                            
                                                            if LeftIndex>1 && RightIndex<smoothXICLength
                                                                EPointGS(m,8)=0;
                                                                for z=LeftIndex:RightIndex
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                            if LeftIndex==1 && RightIndex<smoothXICLength
                                                                EPointGS(m,8)=(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                                for z=2:RightIndex
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                            if LeftIndex>1 && RightIndex==smoothXICLength
                                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                                for z=LeftIndex:RightIndex-1
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                            
                                                            if LeftIndex==1 && RightIndex==smoothXICLength
                                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                                EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                                for z=2:smoothXICLength-1
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                        end;
                                                        
                                                        EPointGSShort(1,:)=EPointGS(1,:);
                                                        nPPShort=1;
                                                        for z=1:EPointGSNo
                                                            if EPointGS(z,1)-EPointGSShort(nPPShort,1)<TimeDifferTor
                                                                if EPointGS(z,2)>EPointGSShort(nPPShort,2)
                                                                    EPointGSShort(nPPShort,1)=EPointGS(z,1);
                                                                    EPointGSShort(nPPShort,2)=EPointGS(z,2);
                                                                end;
                                                                if EPointGS(z,3)>EPointGSShort(nPPShort,3)
                                                                    EPointGSShort(nPPShort,3)=EPointGS(z,3);
                                                                end;
                                                                if EPointGS(z,4)<EPointGSShort(nPPShort,4)
                                                                    EPointGSShort(nPPShort,4)=EPointGS(z,4);
                                                                end;
                                                                EPointGSShort(nPPShort,5)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))/TIRA(ConID,2);
                                                                EPointGSShort(nPPShort,6)=EPointGSShort(nPPShort,2)/HighPoint;
                                                                EPointGSShort(nPPShort,7)=EPointGSShort(nPPShort,6)/EPointGSShort(nPPShort,5);
                                                                EPointGSShort(nPPShort,8)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))*EPointGSShort(nPPShort,2)/2;
                                                            else
                                                                nPPShort=nPPShort+1;
                                                                EPointGSShort(nPPShort,:)=EPointGS(z,:);
                                                            end;
                                                        end;
                                                        
                                                        LargestE=max(EPointGSShort(:,8));
                                                        
                                                        EPointGSShort(:,9)=EPointGSShort(:,8)/LargestE;
                                                        
                                                        nERange=0;
                                                        for z=1:nPPShort
                                                            if EPointGSShort(z,9)>RelArea
                                                                nERange=nERange+1;
                                                                ERange(nERange,:)=EPointGSShort(z,:);
                                                            end
                                                        end
                                                        
                                                        clear EPointGS LeftPoint RightPoint EPointGSShort ...
                                                            width EPosition XICSN_New;
                                                    end;
                                                    clear XIC smoothXIC section;
                                                    
                                                    
                                                    if nERange<PXSet
                                                        XICSN=XICSN';
                                                        for i=1:XICSNLength
                                                            if XICSN(i,2)>BaseLineValue
                                                                AMP=abs(1/log10(XICSN(i,2)/BaseLineValue))^0.2;
                                                                XICSN(i,2)=XICSN(i,2)*AMP*(XICSN(i,2)/BaseLineValue)-BaseLineValue;
                                                            else
                                                                XICSN(i,2)=0;
                                                            end
                                                        end
                                                        nCount=nCount+1;
                                                        MassInfor(1,nCount)=ionSummary(r,ConID);
                                                        
                                                        for j=1:dataWidth
                                                            XICSNSummary(j,1)=XICSN(j,1);
                                                            XICSNSummary(j,nCount+1)=XICSN(j,2);
                                                        end
                                                    end
                                                    clear ERange
                                                end
                                            end
                                            clear XIC XICSN section
                                        end
                                    end
                                    
                                    if XICSNLength>0
                                        TICAppear=zeros(dataWidth,3);
                                        for i=1:dataWidth
                                            TICAppear(i,1)=XICSNSummary(i,1);
                                            TICAppear(i,2)=sum(XICSNSummary(i,2:nCount+1));
                                            TICAppear(i,3)=sum(Data_New(:,i));
                                        end
                                        TICAppear_Rel(:,1)=TICAppear(:,1);
                                        TICAppear_Rel(:,2)=TICAppear(:,2)./max(TICAppear(:,2));
                                        TICAppear_Rel(:,3)=TICAppear(:,3)./max(TICAppear(:,3));
                                        
                                        str= sprintf('%s%s%s%s%s','TICSSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                        fid=fopen(str,'w');
                                        for u=1:dataWidth
                                            for v=1:3
                                                fprintf(fid,'%.4f ',TICAppear_Rel(u,v));
                                            end
                                            fprintf(fid,'\n');
                                        end
                                        fclose(fid);
                                        
                                        str= sprintf('%s%s%s%s%s','MassSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                        fid=fopen(str,'w');
                                        for v=1:nCount
                                            fprintf(fid,'%.4f ',MassInfor(1,v));
                                        end
                                        fclose(fid);
                                        
                                        str= sprintf('%s%s%s%s%s','XICSSam',num2str(SamID),'Con',num2str(ConID),'N.txt');
                                        fid=fopen(str,'w');
                                        for u=1:dataWidth
                                            for v=1:nCount+1
                                                fprintf(fid,'%.4f ',XICSNSummary(u,v));
                                            end
                                            fprintf(fid,'\n');
                                        end
                                        fclose(fid);
                                        
                                        clear TICAppear XICSNSummary MassInfor TICAppear_Rel
                                    end
                                end
                            end
                        end
                    end
                    clear ionSummary
                end
            end
        end
        clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo rDifferRatioControl IMI INTDiffer IRT ...
            IntensityThreshold MB MBLength MIMAssocIons MassDiffer MassDifferTor Mats ...
            MiMLinearity NosEliDiffer RedundantIons SamID SamNoEn SamNoSt TIRALength ...
            TimeDifferTor TimeVariance files iFile nOfFiles nOfMats ...
            rFeatureRecord nr Sample_Feature nFeature Refdata DRLength t0 t00
    end
    clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo rDifferRatioControl IMI INTDiffer IRT ...
        IntensityThreshold MB MBLength MIMAssocIons MassDiffer MassDifferTor Mats ...
        MiMLinearity NosEliDiffer RedundantIons SamID SamNoEn SamNoSt TIRALength ...
        TimeDifferTor TimeVariance files iFile nOfFiles nOfMats t0 t00
    
    t01 = cputime-t00;
    disp(['Calculation time = ',num2str(t01), 'Sam', num2str(SamID) ]);
end
t01=cputime-t00;
disp(['Calculation time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
for SamID=SamNoSt:SamNoEn
    TIRALength=0;
    for iFile=1:nOfFiles
        for ConID=1:ConNo
            if (strcmp(files(iFile).name(1:3),'Sam'))
                MaSuUV(1,1)=0;
                if SamID<10 && ConID<10
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8))==ConID...
                            && strcmp(files(iFile).name(9),'.')
                        MaSuUV(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9))==ConID...
                            && strcmp(files(iFile).name(10),'.')
                        MaSuUV(1,1)=2;
                    end
                end
                if SamID>=100 && ConID<10
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=3;
                    end
                end
                if SamID<10 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:9))==ConID...
                            && strcmp(files(iFile).name(10),'.')
                        MaSuUV(1,1)=4;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=5;
                    end
                end
                if SamID>=100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:11))==ConID...
                            && strcmp(files(iFile).name(12),'.')
                        MaSuUV(1,1)=6;
                    end
                end
                if SamID<10 && ConID>=100
                    if str2double(files(iFile).name(4))==SamID && str2double(files(iFile).name(8:10))==ConID...
                            && strcmp(files(iFile).name(11),'.')
                        MaSuUV(1,1)=7;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=100
                    if str2double(files(iFile).name(4:5))==SamID && str2double(files(iFile).name(9:11))==ConID...
                            && strcmp(files(iFile).name(12),'.')
                        MaSuUV(1,1)=8;
                    end
                end
                if SamID>=100 && ConID>=100
                    if str2double(files(iFile).name(4:6))==SamID && str2double(files(iFile).name(10:12))==ConID...
                            && strcmp(files(iFile).name(13),'.')
                        MaSuUV(1,1)=9;
                    end
                end
                if MaSuUV(1,1)>0
                    UVTemp=load(files(iFile).name);
                    UVTempLS=size(UVTemp,1);
                    TIRA(ConID,1)=ConID;
                    TIRA(ConID,2) =UVTemp(UVTempLS,1);
                    TIRALength=size(TIRA,1);
                end
            end;
        end;
    end;
    if TIRALength>0
        nr=0;nFeature=0;DRLength=0;
        for iFile=1:nOfFiles
            if strcmp( files(iFile).name(1:4),'GRFR')
                MaSuGF(1,1)=0;
                if SamID<10
                    if str2double(files(iFile).name(8))==SamID ...
                            && (strcmp(files(iFile).name(9),'P'))
                        MaSuGF(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID ...
                            && (strcmp(files(iFile).name(10),'P'))
                        MaSuGF(1,1)=2;
                    end
                end
                if SamID>=100
                    if str2double(files(iFile).name(8:10))==SamID ...
                            && (strcmp(files(iFile).name(11),'P'))
                        MaSuGF(1,1)=3;
                    end
                end
                
                if MaSuGF(1,1)>0
                    rFeatureRecord=load(files(iFile).name);
                    nr=size(rFeatureRecord,1);
                end
            end
        end
        
        
        for iFile=1:nOfFiles
            if strcmp( files(iFile).name(1:4),'SAFE')
                MaSuSF(1,1)=0;
                if SamID<10
                    if str2double(files(iFile).name(8))==SamID ...
                            && (strcmp(files(iFile).name(9),'P'))
                        MaSuSF(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID ...
                            && (strcmp(files(iFile).name(10),'P'))
                        MaSuSF(1,1)=2;
                    end
                end
                if SamID>=100
                    if str2double(files(iFile).name(8:10))==SamID ...
                            && (strcmp(files(iFile).name(11),'P'))
                        MaSuSF(1,1)=3;
                    end
                end
                if MaSuSF(1,1)>0
                    Sample_Feature=load(files(iFile).name);
                    nFeature=size(Sample_Feature,1);
                end
            end
        end
        for iMatRef=1:nOfMats
            rE_Vis_Mark=0;
            if strcmp( Mats(iMatRef).name(1:4),'TDAN')
                MaSuMa(1,1)=0;
                if SamID<10
                    if str2double(Mats(iMatRef).name(8))==SamID ...
                            && (strcmp(Mats(iMatRef).name(9),'P'))
                        MaSuMa(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100
                    if str2double(Mats(iMatRef).name(8:9))==SamID ...
                            && (strcmp(Mats(iMatRef).name(10),'P'))
                        MaSuMa(1,1)=2;
                    end
                end
                if SamID>=100
                    if str2double(Mats(iMatRef).name(8:10))==SamID ...
                            && (strcmp(Mats(iMatRef).name(11),'P'))
                        MaSuMa(1,1)=3;
                    end
                end
                if MaSuMa(1,1)>0
                    dataRef = load(Mats(iMatRef).name);
                    Refdata=dataRef.TapdancerBYAbun;
                    DRLength=size(Refdata);
                    if size(DRLength,2)==2
                        DRLength(1,3)=1;
                    end
                end
            end
        end
        if nr*nFeature*DRLength(1,1)~=0
            rE_Vis_Mark=0;
            con_count=0;
            for d2=1:4:DRLength(1,2)-3
                con_count=con_count+1;
                ion_count_present=0;
                ion_count_table_row=0;
                for d3=1:DRLength(1,3)
                    ion_count=0;
                    ion_count_table=0;
                    for d1=1:DRLength(1,1)
                        if Refdata(d1,d2,d3)>0
                            ion_count=ion_count+1;
                            ionSummary_Temp(ion_count,1:4)=Refdata(d1,d2:d2+3,d3);
                            ionSummary_Temp(ion_count,5:7)=Refdata(d1,ConNo*4+1:ConNo*4+3,d3);
                            ionSummary_Temp(ion_count,8)=d3;
                        end
                    end
                    if ion_count>1
                        ionSummary_Temp00=unique(ionSummary_Temp,'rows');
                        clear ionSummary_Temp
                        ionSummary_Temp00=sortrows(ionSummary_Temp00,1);
                        iTemp=1;
                        ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(1,:);
                        for u=2:size(ionSummary_Temp00,1)
                            vot=0;
                            if ionSummary_Temp00(u,1)-ionSummary_Temp0(iTemp,1)>=IMI && vot==0
                                iTemp=iTemp+1;
                                ionSummary_Temp0(iTemp,:)=ionSummary_Temp00(u,:);
                            end
                        end
                        
                        
                        if iTemp>=MIMAssocIons
                            clear ionSummary_Temp0
                            if iTemp>RedundantIons
                                ionSummary_Temp0(:,1:3)=ionSummary_Temp00(:,1:3);
                                ionSummary_Temp010=unique(ionSummary_Temp0,'rows');
                                GridNumber=size(ionSummary_Temp010,1);
                                ISTHigh=max(ionSummary_Temp010(:,3));
                                ISTLow=min(ionSummary_Temp010(:,3));
                                Interval_UL=(ISTHigh-ISTLow)/GridNumber;
                                redIonAbunSummary=zeros(GridNumber,3);
                                
                                for g=1:GridNumber
                                    redIonAbunSummary(g,1)=ISTLow+Interval_UL*(g-1);
                                    redIonAbunSummary(g,2)=ISTLow+Interval_UL*g;
                                end
                                
                                for g=1:GridNumber
                                    for z=1:size(ionSummary_Temp010,1)
                                        if ionSummary_Temp010(z,3)<=redIonAbunSummary(g,2) ...
                                                && ionSummary_Temp010(z,3)>=redIonAbunSummary(g,1)
                                            redIonAbunSummary(g,3)=redIonAbunSummary(g,3)+1;
                                        end
                                    end
                                end
                                HorizonNo=max(redIonAbunSummary(:,3));
                                for g=GridNumber:-1:1
                                    if redIonAbunSummary(g,3)==HorizonNo
                                        HorizonAbun=redIonAbunSummary(g,1);
                                    end
                                end
                                
                                ThresholdAbun_Presented=HorizonAbun;
                                clear ionSummary_Temp010
                            else
                                ThresholdAbun_Presented=0;
                            end
                            for z=1:size(ionSummary_Temp00,1)
                                if ionSummary_Temp00(z,3)>=ThresholdAbun_Presented
                                    ion_count_table=ion_count_table+1;
                                    ionSummary_Temp1(ion_count_table,:)=ionSummary_Temp00(z,:);
                                end
                            end
                            if ion_count_table>0
                                ion_count_table_row=ion_count_table_row+1;
                                RetentionTime=sum(ionSummary_Temp1(:,2))/ion_count_table;
                                IonInfor_Table(ion_count_table_row,1)=d3;
                                IonInfor_Table(ion_count_table_row,2)=RetentionTime;
                                for z=1:ion_count_table
                                    IonInfor_Table(ion_count_table_row,2+5*z-4)=ionSummary_Temp1(z,1);
                                    IonInfor_Table(ion_count_table_row,2+5*z-3)=ionSummary_Temp1(z,3);
                                    IonInfor_Table(ion_count_table_row,2+5*z-2)=ionSummary_Temp1(z,5);
                                    IonInfor_Table(ion_count_table_row,2+5*z-1)=ionSummary_Temp1(z,6);
                                    IonInfor_Table(ion_count_table_row,2+5*z)=ionSummary_Temp1(z,7);
                                end
                                rE_Vis_Mark=1;
                            end
                        end
                    end
                    clear ionSummary_Temp0 ionSummary_Temp00 RepNosIon ionSummary_Temp ionSummary_Temp1 ...
                        ionSummary_Temp2 ionSummary_Temp3 ionSummary_Temp4 redIonAbunSummary
                end
                if ion_count_table_row>0
                    IonInfor_Table0=unique(IonInfor_Table,'rows');
                    T0Length=size(IonInfor_Table0,1);
                    T0Width=size(IonInfor_Table0,2);
                    IonInfor_Table_Short0(1:T0Length,1:T0Width,con_count)=IonInfor_Table0(1:T0Length,1:T0Width);
                    clear IonInfor_Table0 IonInfor_Table
                end
            end
            if rE_Vis_Mark==1
                ionConNoMax=0;
                TableIndex=size(IonInfor_Table_Short0);
                if size(TableIndex,2)<3
                    TableIndex(1,3)=1;
                end
                GEC=0;ISEC=0;
                for d3=1:TableIndex(1,3)
                    GEC1=0;
                    TTT(1:TableIndex(1,1),1:TableIndex(1,2))=IonInfor_Table_Short0(1:TableIndex(1,1),1:TableIndex(1,2),d3);
                    for k=1:TableIndex(1,1)
                        iTTT=0;
                        if TTT(k,1)>0
                            for u=3:5:TableIndex(1,2)
                                if TTT(k,u)>0
                                    iTTT=iTTT+1;
                                    TTT2(iTTT,1:2)=TTT(k,u:u+1);
                                end
                            end
                            TTT3=unique(TTT2,'rows');
                            iTT=size(TTT3,1);
                            IonInfor_Table_Short_Derep(k,1:2,d3)=IonInfor_Table_Short0(k,1:2,d3);
                            GEC1=1;
                            for u=1:iTT
                                IonInfor_Table_Short_Derep(k,u*2+1:u*2+2,d3)=TTT3(u,1:2);
                            end
                        end
                        clear TTT2 TTT3
                    end
                    clear TTT
                    
                    if GEC1>0
                        TableIndex_Derep=size(IonInfor_Table_Short_Derep);
                        if size(TableIndex_Derep,2)<3
                            TableIndex_Derep(1,3)=1;
                        end
                        
                        
                        ionConNo=0;
                        rNo=0;
                        for d1=1:TableIndex_Derep(1,1)
                            if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                rNo=rNo+1;
                            end
                        end
                        
                        if rNo>0
                            str= sprintf('%s%s%s%s%s%s','GINFSam', num2str(SamID),'Con',num2str(d3),'P','.txt');
                            fid=fopen(str,'w');
                            IonIntNo=0;
                            for d1=1:TableIndex_Derep(1,1)
                                if IonInfor_Table_Short_Derep(d1,1,d3)>0
                                    for d2=3:2:TableIndex_Derep(1,2)
                                        if IonInfor_Table_Short_Derep(d1,d2,d3)>0
                                            Code=Sample_Feature(IonInfor_Table_Short_Derep(d1,1,d3),1);
                                            FeatureWriteHere(1,1:3)=rFeatureRecord(Code,1:3);
                                            fprintf(fid,'%d %.1f ',d1,IonInfor_Table_Short_Derep(d1,2,d3));
                                            for z=1:3
                                                fprintf(fid,'%.4f ',FeatureWriteHere(1,z));
                                            end
                                            ionConNo=ionConNo+1;
                                            ionSummary001(ionConNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                            IonIntNo=IonIntNo+1;
                                            ionSummary0001(IonIntNo,1:2)=IonInfor_Table_Short_Derep(d1,d2:d2+1,d3);
                                            fprintf(fid,'%.1f %.4f ',IonInfor_Table_Short_Derep(d1,d2,d3),IonInfor_Table_Short_Derep(d1,d2+1,d3));
                                            fprintf(fid,'\n');
                                        end
                                    end
                                    if IonIntNo>0
                                        maxIonInt=max(ionSummary0001(:,2));
                                        maxIon(1,4)=0;
                                        for z=1:IonIntNo
                                            if maxIonInt==ionSummary0001(z,2)
                                                maxIon(1,3)=ionSummary0001(z,1);
                                            end
                                            maxIon(1,4)=maxIon(1,4)+ionSummary0001(z,2);
                                        end
                                        rIntSum(d1,1:2,d3)=IonInfor_Table_Short_Derep(d1,1:2,d3);
                                        rIntSum(d1,3:4,d3)=maxIon(1,3:4);
                                        GEC=1;
                                    end
                                    clear ionSummary0001 maxIon
                                end
                            end
                            fclose(fid);
                            clear IonInfor_Table_Short_Derep
                        end
                        if ionConNo>0
                            ionSummary002=unique(ionSummary001,'rows');
                            ionSummary002=sortrows(ionSummary002,1);
                            ionSummary(1:size(ionSummary002,1),d3)=ionSummary002(:,1);
                            ISEC=1;
                        end
                        clear ionSummary001 ionSummary002 ionSummary003
                        if ionConNo>ionConNoMax
                            ionConNoMax=ionConNo;
                        end
                    end
                end
                clear TableIndex
                
                if GEC>0
                    TableIndex=size(rIntSum);
                    if size(TableIndex)==2
                        TableIndex(1,3)=1;
                    end
                    
                    str= sprintf('%s%s%s','GREPSam',num2str(SamID),'P.txt');
                    fid=fopen(str,'w');
                    for d3=1:TableIndex(1,3)
                        ionConNo=0;
                        rNo=0;
                        for d1=1:TableIndex(1,1)
                            if rIntSum(d1,1,d3)>0
                                rNo=rNo+1;
                            end
                        end
                        if rNo>0
                            fprintf(fid,'%s%s%s%s','Totally ',num2str(rNo),' rs apparently visible under condition G',num2str(d3));
                            fprintf(fid,'\n');
                            for d1=1:TableIndex(1,1)
                                if rIntSum(d1,1,d3)>0
                                    fprintf(fid,'%d %d ',d1,rIntSum(d1,1,d3));
                                    fprintf(fid,'%.1f ',rIntSum(d1,2,d3));
                                    fprintf(fid,'%.1f %.4f ',rIntSum(d1,3:4,d3));
                                    fprintf(fid,'\n');
                                end
                            end
                        end
                        fprintf(fid,'\n');
                    end
                    fclose(fid);
                    clear rIntSum
                end
                clear IonInfor_Table_Short ionSummary001 ionSummary002
                
                if ISEC>0
                    DCLength=size(ionSummary,1);
                    DCWidth=size(ionSummary,2);
                end
                if ionConNoMax>0
                    for ConID=1:DCWidth
                        XICSNLength=0;
                        for iMat=1:nOfMats
                            if strcmp( Mats(iMat).name(1:3),'Sam')
                                MaSuMa(1,1)=0;
                                if SamID<10 && ConID<10
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==ConID...
                                            && (strcmp(Mats(iMat).name(9),'P'))...
                                            && strcmp(Mats(iMat).name(10),'.')
                                        MaSuMa(1,1)=1;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID<10
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'P'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=2;
                                    end
                                end
                                if SamID>=100 && ConID<10
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=3;
                                    end
                                end
                                if SamID<10 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:9))==ConID...
                                            && (strcmp(Mats(iMat).name(10),'P'))...
                                            && strcmp(Mats(iMat).name(11),'.')
                                        MaSuMa(1,1)=4;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=5;
                                    end
                                end
                                if SamID>=100 && ConID>=10 && ConID<100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'P'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=6;
                                    end
                                end
                                if SamID<10 && ConID>=100
                                    if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8:10))==ConID...
                                            && (strcmp(Mats(iMat).name(11),'P'))...
                                            && strcmp(Mats(iMat).name(12),'.')
                                        MaSuMa(1,1)=7;
                                    end
                                end
                                if SamID>=10 && SamID<100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9:11))==ConID...
                                            && (strcmp(Mats(iMat).name(12),'P'))...
                                            && strcmp(Mats(iMat).name(13),'.')
                                        MaSuMa(1,1)=8;
                                    end
                                end
                                if SamID>=100 && ConID>=100
                                    if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10:12))==ConID...
                                            && (strcmp(Mats(iMat).name(13),'P'))...
                                            && strcmp(Mats(iMat).name(14),'.')
                                        MaSuMa(1,1)=9;
                                    end
                                end
                                if MaSuMa(1,1)>0
                                    data = load(Mats(iMat).name);
                                    Scans=data.Scans;
                                    dataWidth=size(Scans,2);
                                    MergeMass=data.Masses;
                                    dataLength=size(MergeMass,1);
                                    MergeData=data.Data;
                                    Timerange=TIRA(ConID,2);
                                    Data_New=MergeData;
                                    XIC=zeros(dataWidth,2);
                                    MergeTime=Scans(1,:)*Timerange/Scans(1,size(Scans,2));
                                    nCount=0;
                                    for r=1:DCLength
                                        if ionSummary(r,ConID)>0
                                            for h=MassRange+1:dataLength-MassRange
                                                if abs(ionSummary(r,ConID)-MergeMass(h,1))<IMI
                                                    for j=1:dataWidth
                                                        XIC(j,1)=MergeTime(1,j);
                                                        XIC(j,2)=sum(Data_New(h-MassRange:h+MassRange,j));
                                                    end
                                                    XICSN=XIC;
                                                    HighPoint=max(XICSN(:,2));
                                                    LowPoint=min(XICSN(:,2));
                                                    sectionNo=100;
                                                    Incre=(HighPoint-LowPoint)/sectionNo;
                                                    section=zeros(sectionNo,3);
                                                    
                                                    for i=1:sectionNo
                                                        section(i,1)=Incre*(i-1)+LowPoint;
                                                        section(i,2)=Incre*i+LowPoint;
                                                        section(i,3)=0;
                                                    end
                                                    XICSNLength=size(XICSN,1);
                                                    for j=1:XICSNLength
                                                        for u=1:sectionNo
                                                            if XICSN(j,2)>=section(u,1) && XICSN(j,2)<section(u,2)
                                                                section(u,3)=section(u,3)+1;
                                                            end
                                                        end
                                                    end
                                                    chooseSection=max(section(2:sectionNo,3));
                                                    for i=2:sectionNo
                                                        if section(i,3)==chooseSection
                                                            baselineLow=section(i,1);
                                                            baselineHigh=section(i,2);
                                                        end
                                                    end
                                                    BaseLineValue=0;
                                                    count=0;
                                                    for i=1:XICSNLength
                                                        if XICSN(i,2)>=baselineLow && XICSN(i,2)<baselineHigh
                                                            BaseLineValue=BaseLineValue+XICSN(i,2);
                                                            count=count+1;
                                                        end
                                                    end
                                                    BaseLineValue=BaseLineValue/count;
                                                    XICSN=XICSN';
                                                    FH=round(TIRA(ConID,2)*2.5*log10(dataWidth));
                                                    ATH=size(XICSN,2);
                                                    Ratio=round(ATH/FH);
                                                    if Ratio>=1
                                                        iCol=0;
                                                        for k=1:Ratio:ATH-Ratio
                                                            iCol=iCol+1;
                                                            XICSN_New(2,iCol)=sum(XICSN(2,k:k+Ratio-1));
                                                            XICSN_New(1,iCol)=0.5*(XICSN(1,k)+XICSN(1,k+Ratio-1));
                                                        end
                                                    else
                                                        Ratio2=round(FH/ATH);
                                                        iCol=Ratio2*ATH;
                                                        for o=1:dataWidth
                                                            XICSN_New(1,o*Ratio2-Ratio2+1:o*Ratio2)=XICSN(1,o);
                                                            XICSN_New(2,o*Ratio2-Ratio2+1:o*Ratio2)=XICSN(2,o);
                                                        end
                                                    end
                                                    XICSN_New=XICSN_New';
                                                    fr = FH/16;
                                                    dt = (16/FH)^2;
                                                    rick = ricker(FH,fr,dt,20);
                                                    rick_smooth = getSmoothRicker(rick);
                                                    smoothXIC0  = conv( rick_smooth(:,1),XICSN_New(:,2) );
                                                    smoothXIC(:,1)=XICSN_New(:,1);
                                                    smoothXIC(:,2)=smoothXIC0( round(length(rick_smooth)/2)+1:length(XICSN_New(:,2))+round(length(rick_smooth)/2));
                                                    smoothXICLength=size(smoothXIC,1);
                                                    EThreshold=0.01;
                                                    EPointGSNo=0;
                                                    HighPoint=max(smoothXIC(:,2));
                                                    for i=2:smoothXICLength-1
                                                        if smoothXIC(i,2)>=smoothXIC(i-1,2) && smoothXIC(i,2)>=smoothXIC(i+1,2) && smoothXIC(i,2)> HighPoint*EThreshold && (smoothXIC(i,2)-smoothXIC(i-1,2))+(smoothXIC(i,2)-smoothXIC(i+1,2))~=0
                                                            EPointGSNo=EPointGSNo+1;
                                                            EPointGS(EPointGSNo,1) = smoothXIC(i,1);
                                                            EPointGS(EPointGSNo,2) = smoothXIC(i,2);
                                                        end;
                                                    end;
                                                    BaseLineTolerance=0.01;
                                                    nEInfor=0;
                                                    if EPointGSNo>0
                                                        for m=1:EPointGSNo
                                                            ETime=EPointGS(m,1);
                                                            EHight=EPointGS(m,2);
                                                            EPosition(1,1)=EPointGS(m,1);
                                                            EPosition(1,2)=EPointGS(m,2);
                                                            halfPH=EHight/2;
                                                            for z=1:smoothXICLength
                                                                if smoothXIC(z,1)==ETime
                                                                    PP=z;
                                                                end;
                                                            end;
                                                            vbv1=0;
                                                            for z=PP:-1:2
                                                                if smoothXIC(z,2)>=0 && smoothXIC(z-1,2)<=0 && vbv1==0
                                                                    CrossZeroLeft=smoothXIC(z,1);
                                                                    LeftIndex=z;
                                                                    vbv1=1;
                                                                end;
                                                            end;
                                                            
                                                            if vbv1==0
                                                                CrossZeroLeft=0;
                                                                LeftIndex=1;
                                                            end;
                                                            
                                                            vbv2=0;
                                                            for z=PP:smoothXICLength-1
                                                                if smoothXIC(z,2)>=0 && smoothXIC(z+1,2)<=0 && vbv2==0
                                                                    CrossZeroRight=smoothXIC(z,1);
                                                                    RightIndex=z;
                                                                    vbv2=1;
                                                                end;
                                                            end;
                                                            
                                                            if vbv2==0
                                                                CrossZeroRight=smoothXIC(smoothXICLength,1);
                                                                RightIndex=smoothXICLength;
                                                            end;
                                                            
                                                            EPointGS(m,3)=CrossZeroLeft;
                                                            EPointGS(m,4)=CrossZeroRight;
                                                            EPointGS(m,5)=(CrossZeroRight-CrossZeroLeft)/TIRA(ConID,2);
                                                            EPointGS(m,6)=EHight/HighPoint;
                                                            EPointGS(m,7)=EPointGS(m,6)/EPointGS(m,5);
                                                            if LeftIndex>1 && RightIndex<smoothXICLength
                                                                EPointGS(m,8)=0;
                                                                for z=LeftIndex:RightIndex
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                            if LeftIndex==1 && RightIndex<smoothXICLength
                                                                EPointGS(m,8)=(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                                for z=2:RightIndex
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                            if LeftIndex>1 && RightIndex==smoothXICLength
                                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                                for z=LeftIndex:RightIndex-1
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                            
                                                            if LeftIndex==1 && RightIndex==smoothXICLength
                                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                                EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                                for z=2:smoothXICLength-1
                                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                                end
                                                            end
                                                        end;
                                                        
                                                        EPointGSShort(1,:)=EPointGS(1,:);
                                                        nPPShort=1;
                                                        for z=1:EPointGSNo
                                                            if EPointGS(z,1)-EPointGSShort(nPPShort,1)<TimeDifferTor
                                                                if EPointGS(z,2)>EPointGSShort(nPPShort,2)
                                                                    EPointGSShort(nPPShort,1)=EPointGS(z,1);
                                                                    EPointGSShort(nPPShort,2)=EPointGS(z,2);
                                                                end;
                                                                if EPointGS(z,3)>EPointGSShort(nPPShort,3)
                                                                    EPointGSShort(nPPShort,3)=EPointGS(z,3);
                                                                end;
                                                                if EPointGS(z,4)<EPointGSShort(nPPShort,4)
                                                                    EPointGSShort(nPPShort,4)=EPointGS(z,4);
                                                                end;
                                                                EPointGSShort(nPPShort,5)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))/TIRA(ConID,2);
                                                                EPointGSShort(nPPShort,6)=EPointGSShort(nPPShort,2)/HighPoint;
                                                                EPointGSShort(nPPShort,7)=EPointGSShort(nPPShort,6)/EPointGSShort(nPPShort,5);
                                                                EPointGSShort(nPPShort,8)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))*EPointGSShort(nPPShort,2)/2;
                                                            else
                                                                nPPShort=nPPShort+1;
                                                                EPointGSShort(nPPShort,:)=EPointGS(z,:);
                                                            end;
                                                        end;
                                                        
                                                        LargestE=max(EPointGSShort(:,8));
                                                        
                                                        EPointGSShort(:,9)=EPointGSShort(:,8)/LargestE;
                                                        
                                                        nERange=0;
                                                        for z=1:nPPShort
                                                            if EPointGSShort(z,9)>RelArea
                                                                nERange=nERange+1;
                                                                ERange(nERange,:)=EPointGSShort(z,:);
                                                            end
                                                        end
                                                        
                                                        clear EPointGS LeftPoint RightPoint EPointGSShort ...
                                                            width EPosition XICSN_New;
                                                    end;
                                                    clear XIC smoothXIC section;
                                                    if nERange<PXSet
                                                        XICSN=XICSN';
                                                        for i=1:XICSNLength
                                                            if XICSN(i,2)>BaseLineValue
                                                                AMP=abs(1/log10(XICSN(i,2)/BaseLineValue))^0.2;
                                                                XICSN(i,2)=XICSN(i,2)*AMP*(XICSN(i,2)/BaseLineValue)-BaseLineValue;
                                                            else
                                                                XICSN(i,2)=0;
                                                            end
                                                        end
                                                        nCount=nCount+1;
                                                        MassInfor(1,nCount)=ionSummary(r,ConID);
                                                        for j=1:dataWidth
                                                            XICSNSummary(j,1)=XICSN(j,1);
                                                            XICSNSummary(j,nCount+1)=XICSN(j,2);
                                                        end
                                                    end
                                                    clear ERange
                                                end
                                            end
                                            clear XIC XICSN section
                                        end
                                    end
                                    
                                    if XICSNLength>0
                                        TICAppear=zeros(dataWidth,3);
                                        for i=1:dataWidth
                                            TICAppear(i,1)=XICSNSummary(i,1);
                                            TICAppear(i,2)=sum(XICSNSummary(i,2:nCount+1));
                                            TICAppear(i,3)=sum(Data_New(:,i));
                                        end
                                        TICAppear_Rel(:,1)=TICAppear(:,1);
                                        TICAppear_Rel(:,2)=TICAppear(:,2)./max(TICAppear(:,2));
                                        TICAppear_Rel(:,3)=TICAppear(:,3)./max(TICAppear(:,3));
                                        
                                        str= sprintf('%s%s%s%s%s','TICSSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                        fid=fopen(str,'w');
                                        for u=1:dataWidth
                                            for v=1:3
                                                fprintf(fid,'%.4f ',TICAppear_Rel(u,v));
                                            end
                                            fprintf(fid,'\n');
                                        end
                                        fclose(fid);
                                        
                                        str= sprintf('%s%s%s%s%s','MassSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                        fid=fopen(str,'w');
                                        for v=1:nCount
                                            fprintf(fid,'%.4f ',MassInfor(1,v));
                                        end
                                        fclose(fid);
                                        
                                        str= sprintf('%s%s%s%s%s','XICSSam',num2str(SamID),'Con',num2str(ConID),'P.txt');
                                        fid=fopen(str,'w');
                                        for u=1:dataWidth
                                            for v=1:nCount+1
                                                fprintf(fid,'%.4f ',XICSNSummary(u,v));
                                            end
                                            fprintf(fid,'\n');
                                        end
                                        fclose(fid);
                                        
                                        clear TICAppear XICSNSummary MassInfor TICAppear_Rel
                                    end
                                end
                            end
                        end
                    end
                    clear ionSummary
                end
            end
        end
        clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo rDifferRatioControl IMI INTDiffer IRT ...
            IntensityThreshold MB MBLength MIMAssocIons MassDiffer MassDifferTor Mats ...
            MiMLinearity NosEliDiffer RedundantIons SamID SamNoEn SamNoSt TIRALength ...
            TimeDifferTor TimeVariance files iFile nOfFiles nOfMats ...
            rFeatureRecord nr Sample_Feature nFeature Refdata DRLength t0 t00
    end
    clearvars -except PXSet RelArea MassRange MassResolution ConID ConNo rDifferRatioControl IMI INTDiffer IRT ...
        IntensityThreshold MB MBLength MIMAssocIons MassDiffer MassDifferTor Mats ...
        MiMLinearity NosEliDiffer RedundantIons SamID SamNoEn SamNoSt TIRALength ...
        TimeDifferTor TimeVariance files iFile nOfFiles nOfMats t0 t00
    
    t01 = cputime-t00;
    disp(['Calculation time = ',num2str(t01), 'Sam', num2str(SamID) ]);
end
t01=cputime-t00;
disp(['Calculation time = ',num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
SlopeDifferTolerance=0.05;
IntersectDifferTolerance=0.1;
IsotopeVariance=0.2;
MaxIsotopeRatio=0.95;
MiMRep=3;
files = dir(fullfile('.', '*.txt'));
[nOfFiles,~] = size(files);
load Mobile_Phase.txt
MB=Mobile_Phase;
MBLength=size(MB,1);
MBWidth=size(MB,2);

ConsideredConditionNo=ConNo-MiMRep+1;
for u=2:MBWidth
    volH2O=0;
    for u1=1:MBLength-1
        volH2O=volH2O+MB(u1+1,u)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,u)-MB(u1,u))*(MB(u1+1,1)-MB(u1,1));
    end
    volH2OArrayTemp(u-1,1)=u-1;
    volH2OArrayTemp(u-1,2)=volH2O;
end
volH2OArrayTemp=sortrows(volH2OArrayTemp,2);
SlowestID(1:ConsideredConditionNo,1)=volH2OArrayTemp(1:ConsideredConditionNo,1);
SlowestID=SlowestID';
clear volH2OArrayTemp

for SamID=SamNoSt:SamNoEn
    new_folder=['IDP_HILIC_Sam',num2str(SamID)];
    mkdir(new_folder)
    AddedLength=0;
    for SlowestIDNo=1:ConsideredConditionNo
        ConID=SlowestID(1,SlowestIDNo);
        GINFCode=0;
        for iFile=1:nOfFiles
            if (strcmp(files(iFile).name(1:4),'GINF'))
                MaSuGI(1,1)=0;
                if SamID<10 && ConID<10
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                            && strcmp(files(iFile).name(13),'N')
                        MaSuGI(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                            && strcmp(files(iFile).name(14),'N')
                        MaSuGI(1,1)=2;
                    end
                end
                if SamID>=100 && ConID<10
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                            && strcmp(files(iFile).name(15),'N')
                        MaSuGI(1,1)=3;
                    end
                end
                if SamID<10 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                            && strcmp(files(iFile).name(14),'N')
                        MaSuGI(1,1)=4;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                            && strcmp(files(iFile).name(15),'N')
                        MaSuGI(1,1)=5;
                    end
                end
                if SamID>=100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                            && strcmp(files(iFile).name(16),'N')
                        MaSuGI(1,1)=6;
                    end
                end
                if SamID<10 && ConID>=100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                            && strcmp(files(iFile).name(15),'N')
                        MaSuGI(1,1)=7;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                            && strcmp(files(iFile).name(16),'N')
                        MaSuGI(1,1)=8;
                    end
                end
                if SamID>=100 && ConID>=100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                            && strcmp(files(iFile).name(17),'N')
                        MaSuGI(1,1)=9;
                    end
                end
                if MaSuGI(1,1)>0
                    GISumTemp=load(files(iFile).name);
                    GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),1)=ConID;
                    GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),2:size(GISumTemp,2)+1)=GISumTemp;
                    GINFCode=1;
                end
            end
        end
        if GINFCode==1
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:4),'DENO'))
                    MaSuDN(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'N')
                            MaSuDN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuDN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'N')
                            MaSuDN(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuDN(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'N')
                            MaSuDN(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'N')
                            MaSuDN(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'N')
                            MaSuDN(1,1)=9;
                        end
                    end
                    if MaSuDN(1,1)>0
                        IntSumTemp=load(files(iFile).name);
                        for u=AddedLength+1:AddedLength+size(GISumTemp,1)
                            OiO=0;
                            for z=1:size(IntSumTemp,1)
                                if abs(GISumTemp2(u,7)-IntSumTemp(z,1))<=MassDifferTor && ...
                                        abs(GISumTemp2(u,3)-IntSumTemp(z,2))<TimeDifferTor*4
                                    if GISumTemp2(u,8)==IntSumTemp(z,10);
                                        OiO=OiO+1;
                                        Temp_OiO(OiO,1)=abs(GISumTemp2(u,7)-IntSumTemp(z,1));
                                        Temp_OiO(OiO,2)=abs(GISumTemp2(u,3)-IntSumTemp(z,2));
                                        Temp_OiO(OiO,3)=IntSumTemp(z,11);
                                        Temp_OiO(OiO,4)=IntSumTemp(z,2);
                                    end
                                end
                            end
                            if OiO>0
                                Temp_OiO=sortrows(Temp_OiO,-3);
                                GISumTemp2(u,3)=Temp_OiO(1,4);
                                GISumTemp2(u,8)=Temp_OiO(1,3);
                            else
                                GISumTemp2(u,8)=0;
                            end
                        end
                        AddedLength=AddedLength+size(GISumTemp,1);
                        clear GISumTemp
                    end
                end
            end
        end
    end
    if AddedLength>0
        GISumTemp2=sortrows(GISumTemp2,[1,7]);
        GISumTemp3=GISumTemp2;
        clear GISumTemp2
        nGISumTemp2=0;
        for h=1:size(GISumTemp3,1)
            tR_Assume=0.1:0.1:100;
            tR_Assume=tR_Assume';
            solutionCount=0;
            for o=1:size(tR_Assume,1)
                tR=tR_Assume(o,1);
                for ut=2:MBLength
                    if tR>MB(ut-1,1) && tR<MB(ut,1)
                        RatioH2O=(tR-MB(ut-1,1))*((MB(ut,GISumTemp3(h,1)+1)-MB(ut-1,GISumTemp3(h,1)+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,GISumTemp3(h,1)+1);
                        u0=ut;
                        volH2O=0;
                        for u1=1:u0-1
                            volH2O=volH2O+MB(u1+1,GISumTemp3(h,1)+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,GISumTemp3(h,1)+1)-MB(u1,GISumTemp3(h,1)+1))*(MB(u1+1,1)-MB(u1,1));
                        end
                        volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,GISumTemp3(h,1)+1)+(MB(u0,GISumTemp3(h,1)+1)-RatioH2O)*(MB(u0,1)-tR);
                        volH2O=volH2O/100;
                        volMeOH(1,GISumTemp3(h,1))=tR-volH2O;
                        RatioStrong=log10(volH2O/tR);
                    end
                end
                
                tR0=10^((RatioStrong-GISumTemp3(h,5))/GISumTemp3(h,4));
                if abs(tR-tR0)<TimeDifferTor*4
                    solutionCount=solutionCount+1;
                    solutionSet(solutionCount,1)=tR;
                    solutionSet(solutionCount,3)=abs(tR-tR0);
                    solutionSet(solutionCount,2)=RatioStrong;
                end
            end
            for o=1:solutionCount
                if solutionSet(o,3)==min(solutionSet(:,3))
                    GISumTemp3(h,9)=solutionSet(o,1);
                    if abs(GISumTemp3(h,9)-GISumTemp3(h,3))<TimeDifferTor*2
                        nGISumTemp2=nGISumTemp2+1;
                        GISumTemp2(nGISumTemp2,1:8)=GISumTemp3(h,1:8);
                    end
                end
            end
            clear solutionSet
        end
        clear GISumTemp3
    end
    t01=cputime-t00;
    disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
    if AddedLength>0
        RetentionBehavior(:,1:3)=GISumTemp2(:,4:6);
        ShortBehavior=unique(RetentionBehavior,'rows');
        ShortBehavior=sortrows(ShortBehavior,3);
        for s=1:size(ShortBehavior,1)
            tR_Assume=0.1:0.1:100;
            tR_Assume=tR_Assume';
            solutionCount=0;
            for o=1:size(tR_Assume,1)
                tR=tR_Assume(o,1);
                for ut=2:MBLength
                    if tR>MB(ut-1,1) && tR<MB(ut,1)
                        RatioH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                        u0=ut;
                        volH2O=0;
                        for u1=1:u0-1
                            volH2O=volH2O+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                        end
                        volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-RatioH2O)*(MB(u0,1)-tR);
                        volH2O=volH2O/100;
                        volMeOH(1,1)=tR-volH2O;
                        RatioStrong=log10(volH2O/tR);
                    end
                end
                
                tR0=10^((RatioStrong-ShortBehavior(s,2))/ShortBehavior(s,1));
                
                solutionCount=solutionCount+1;
                solutionSet(solutionCount,1)=tR;
                solutionSet(solutionCount,3)=abs(tR-tR0);
                solutionSet(solutionCount,2)=RatioStrong;
            end
            for o=1:solutionCount
                if solutionSet(o,3)==min(solutionSet(:,3))
                    ShortBehavior(s,4)=solutionSet(o,1);
                end
            end
            clear solutionSet
        end
        nDSBehavior=1;
        SP=0;
        WidthCode=zeros(size(ShortBehavior,1),1);
        for z=1:size(ShortBehavior,1)
            if ShortBehavior(z,3)>=MiMLinearity-0.05 && SP==0
                DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                z1=z;
                SP=1;
                WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                BehaviorTimeInspect(nDSBehavior,1)=ShortBehavior(z,4);
            end
        end
        if size(ShortBehavior,1)>1
            for z=z1+1:size(ShortBehavior,1)
                if ShortBehavior(z,3)>=MiMLinearity-0.05
                    Rep=0;
                    for u=1:nDSBehavior
                        for v=1:3:WidthCode(u,1)-1
                            if abs(ShortBehavior(z,1)-DSBehavior(u,v))<SlopeDifferTolerance ...
                                    && abs(ShortBehavior(z,2)-DSBehavior(u,v+1))<IntersectDifferTolerance...
                                    && Rep==0
                                if max(BehaviorTimeInspect(nDSBehavior,:))<2*t0
                                    TimeDiffer=TimeDifferTor/2;
                                else
                                    TimeDiffer=TimeDifferTor;
                                end
                                
                                BehaviorTimeInspectTemp=BehaviorTimeInspect(u,:)';
                                BTT1=sortrows(BehaviorTimeInspectTemp,1);
                                for m=1:size(BTT1,1)
                                    if BTT1(m,1)~=0
                                        minTime=BTT1(m,1);
                                        break
                                    end
                                end
                                
                                if abs(ShortBehavior(z,4)-max(BehaviorTimeInspect(u,:)))<=TimeDiffer*2 ...
                                        && abs(ShortBehavior(z,4)-minTime)<=TimeDiffer*2
                                    DSBehavior(u,WidthCode(u,1)+1:WidthCode(u,1)+3)=ShortBehavior(z,1:3);
                                    WidthCode(u,1)=WidthCode(u,1)+3;
                                    Rep=1;
                                    BehaviorTimeInspect(u,WidthCode(u,1)/3)=ShortBehavior(z,4);
                                end
                            end
                        end
                    end
                    if Rep==0
                        nDSBehavior=nDSBehavior+1;
                        DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                        WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                        BehaviorTimeInspect(nDSBehavior,1)=ShortBehavior(z,4);
                    end
                end
            end
        end
        nDSBehavior_Extended=0;
        for p=1:nDSBehavior
            nBahavioredRetentionTime=zeros(ConNo,1);
            for v=1:3:size(DSBehavior,2)
                if DSBehavior(p,v)~=0
                    for q=1:size(GISumTemp2,1)
                        if GISumTemp2(q,4:6)==DSBehavior(p,v:v+2)
                            nBahavioredRetentionTime(GISumTemp2(q,1),1)=nBahavioredRetentionTime(GISumTemp2(q,1),1)+1;
                            BRT_temp(nBahavioredRetentionTime(GISumTemp2(q,1),1),GISumTemp2(q,1))=GISumTemp2(q,3);
                        end
                    end
                end
            end
            for de=1:size(BRT_temp,2)
                BRT_temp2=BRT_temp(:,de);
                BRT_temp3=unique(BRT_temp2,'rows');
                BRT_temp3=sortrows(BRT_temp3,-1);
                nBRT_Short3=1;
                BRT_Short3(nBRT_Short3,1)=BRT_temp3(nBRT_Short3,1);
                if size(BRT_temp3,1)>1
                    for u=2:size(BRT_temp3,1)
                        if BRT_Short3(nBRT_Short3,1)-BRT_temp3(u,1)>TimeDifferTor && BRT_temp3(u,1)>0
                            nBRT_Short3=nBRT_Short3+1;
                            BRT_Short3(nBRT_Short3,1)=BRT_temp3(u,1);
                        end
                    end
                end
                BRT(1:size(BRT_Short3,1),de)=BRT_Short3(1:size(BRT_Short3,1),1);
                clear BRT_temp2 BRT_temp3 BRT_Short3
            end
            SeeTime=0;
            for s=1:size(SlowestID,2)
                for k=1:size(BRT,2)
                    if k==SlowestID(1,s)
                        if BRT(1,k)>0 && SeeTime==0
                            SeeTime=1;
                            if k==SlowestID(1,1)
                                for z=1:size(BRT,1)
                                    if BRT(z,k)>0
                                        nDSBehavior_Extended=nDSBehavior_Extended+1;
                                        DSBehavior_Extended(nDSBehavior_Extended,1)=BRT(z,k);
                                        DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                        DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                    end
                                end
                            else
                                tR_Assume=0.1:0.1:100;
                                tR_Assume=tR_Assume';
                                solutionCount=0;
                                for o=1:size(tR_Assume,1)
                                    tR=tR_Assume(o,1);
                                    for ut=2:MBLength
                                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                                            RatioH2O=(tR-MB(ut-1,1))*((MB(ut,k+1)-MB(ut-1,k+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,k+1);
                                            u0=ut;
                                            volH2O=0;
                                            for u1=1:u0-1
                                                volH2O=volH2O+MB(u1+1,k+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,k+1)-MB(u1,k+1))*(MB(u1+1,1)-MB(u1,1))/2;
                                            end
                                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,k+1)+(MB(u0,k+1)-RatioH2O)*(MB(u0,1)-tR)/2;
                                            volH2O=volH2O/100;
                                            volMeOH(1,k)=tR-volH2O;
                                            RatioStrong=log10(volH2O/tR);
                                        end
                                    end
                                    tR0=10^((RatioStrong-DSBehavior(p,2))/DSBehavior(p,1));
                                    if abs(tR-tR0)<TimeDifferTor*4
                                        solutionCount=solutionCount+1;
                                        solutionSet(solutionCount,1)=tR;
                                        solutionSet(solutionCount,3)=abs(tR-tR0);
                                        solutionSet(solutionCount,2)=RatioStrong;
                                    end
                                end
                                if solutionCount>0
                                    for o=1:solutionCount
                                        if solutionSet(o,3)==min(solutionSet(:,3))
                                            nDSBehavior_Extended=nDSBehavior_Extended+1;
                                            DSBehavior_Extended(nDSBehavior_Extended,1)=solutionSet(o,1);
                                            DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                            DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                        end
                                    end
                                end
                                clear solutionSet
                            end
                        end
                    end
                end
            end
            
            clear BRT clear BRT_temp
        end
        t01=cputime-t00;
        disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
        Error_Tor=0.05;
        DSBehavior_Extended=sortrows(DSBehavior_Extended,1);
        DSBehavior_Extended_Temp=DSBehavior_Extended;
        clear DSBehavior_Extended;
        nDSBehavior_Extended=1;
        DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
            DSBehavior_Extended_Temp(1,1:size(DSBehavior_Extended_Temp,2));
        nSlope_View1=0;
        for v=3:3:size(DSBehavior_Extended,2);
            if DSBehavior_Extended(nDSBehavior_Extended,v)~=0;
                nSlope_View1=nSlope_View1+1;
                Slope_View1(nSlope_View1,1:2)=DSBehavior_Extended(nDSBehavior_Extended,1:2);
                Slope_View1(nSlope_View1,3:5)=DSBehavior_Extended(nDSBehavior_Extended,v:v+2);
            end
        end
        Slope_View1=sortrows(Slope_View1,3);
        for z=2:size(DSBehavior_Extended_Temp,1)
            nSlope_View2=0;
            for v=3:3:size(DSBehavior_Extended_Temp,2);
                if DSBehavior_Extended_Temp(z,v)~=0;
                    nSlope_View2=nSlope_View2+1;
                    Slope_View2(nSlope_View2,1:2)=DSBehavior_Extended_Temp(z,1:2);
                    Slope_View2(nSlope_View2,3:5)=DSBehavior_Extended_Temp(z,v:v+2);
                end
            end
            Slope_View2=sortrows(Slope_View2,3);
            
            if max(Slope_View1(:,1))*(1+Error_Tor)>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor) && ...
                    min(Slope_View1(:,1))*(1+Error_Tor)+TimeDifferTor*4>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor)
                Slope_View=[Slope_View1;Slope_View2];
                Slope_View=sortrows(Slope_View,3);
                clear Slope_View1
                Slope_View1=Slope_View;
                nSlope_View1=size(Slope_View,1);
                clear Slope_View
                DSBehavior_Extended(nDSBehavior_Extended,1:2)=Slope_View1(1,1:2);
                
                for v=1:nSlope_View1
                    if v~=1
                        vot=0;
                        for o=3:3:size(DSBehavior_Extended,2)
                            if Slope_View1(v,3)==DSBehavior_Extended(nDSBehavior_Extended,o) && ...
                                    Slope_View1(v,4)==DSBehavior_Extended(nDSBehavior_Extended,o+1) && ...
                                    Slope_View1(v,5)==DSBehavior_Extended(nDSBehavior_Extended,o+2)
                                vot=1;
                            end
                        end
                        if vot==0
                            nRow=nRow+1;
                            DSBehavior_Extended(nDSBehavior_Extended,2+3*nRow-2:2+3*nRow)=Slope_View1(v,3:5);
                        end
                    else
                        DSBehavior_Extended(nDSBehavior_Extended,2+3*v-2:2+3*v)=Slope_View1(v,3:5);
                        nRow=v;
                    end
                end
            else
                nDSBehavior_Extended=nDSBehavior_Extended+1;
                DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
                    DSBehavior_Extended_Temp(z,1:size(DSBehavior_Extended_Temp,2));
                clear Slope_View1
                Slope_View1=Slope_View2;
                nSlope_View1=nSlope_View2;
            end
            clear Slope_View2
        end
        clear DSBehavior_Extended_Temp;
        IonNumber=zeros(nDSBehavior_Extended,1);
        if nDSBehavior_Extended>0
            for p=1:nDSBehavior_Extended
                for v=3:3:size(DSBehavior_Extended,2)
                    for q=1:size(GISumTemp2,1)
                        if (abs(DSBehavior_Extended(p,1)-GISumTemp2(q,3))<TimeDifferTor*8 && GISumTemp2(q,1)==SlowestID(1,1)) ||...
                                (GISumTemp2(q,1)~=SlowestID(1,1))
                            if GISumTemp2(q,4)==DSBehavior_Extended(p,v) && ...
                                    GISumTemp2(q,5)==DSBehavior_Extended(p,v+1) && ...
                                    GISumTemp2(q,6)==DSBehavior_Extended(p,v+2)
                                IonNumber(p,1)=IonNumber(p,1)+1;
                                IonSummary(IonNumber(p,1),1:size(GISumTemp2,2),p)=GISumTemp2(q,:);
                                IonSummary(IonNumber(p,1),1+size(GISumTemp2,2),p)=p;
                            end
                        end
                    end
                end
            end
            nIonSummaryShort=0;
            for p=1:nDSBehavior_Extended
                if IonSummary(1,1,p)>0
                    nIonSummaryShort=nIonSummaryShort+1;
                    IonSummaryShort(:,:,nIonSummaryShort)=IonSummary(:,:,p);
                end
            end
            clear IonSummary
            IonSummary=IonSummaryShort;
        end
        t01=cputime-t00;
        disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
        if sum(IonNumber(:,1))>0
            for z=1:nDSBehavior_Extended
                nIonDerep=1;
                IonSummaryDerepTemp(nIonDerep,:)=IonSummary(1,:,z);
                if size(IonSummary,1)>1
                    for u=2:size(IonSummary,1)
                        if IonSummary(u,7,z)>0
                            if abs(IonSummary(u,7,z)-IonSummaryDerepTemp(nIonDerep,7))<=MassDifferTor
                                if IonSummary(u,8,z)>IonSummaryDerepTemp(nIonDerep,8)
                                    IonSummaryDerepTemp(nIonDerep,:)=IonSummary(u,:,z);
                                end
                            else
                                nIonDerep=nIonDerep+1;
                                IonSummaryDerepTemp(nIonDerep,:)=IonSummary(u,:,z);
                            end
                        end
                    end
                end
                IonSummaryDerep(1:nIonDerep,1:9,z)=IonSummaryDerepTemp(1:nIonDerep,1:9);
                clear IonSummaryDerepTemp
            end
            clear IonNumber
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            nIonSummaryTS=1;
            IonSummaryTS(1:size(IonSummaryDerep,1),1,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,1);
            IonSummaryTS(1:size(IonSummaryDerep,1),2:8,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,1);
            if nDSBehavior_Extended>1
                for g=2:nDSBehavior_Extended
                    Tereplicate=0;
                    Replicate=0;
                    for h=1:nIonSummaryTS
                        if abs(IonSummaryTS(1,2,h)-IonSummaryDerep(1,3,g))<TimeDifferTor && IonSummaryTS(1,2,h)*IonSummaryDerep(1,3,g)~=0
                            Tereplicate=1;
                            Tereplicate_hit=0;
                            for u1=1:size(IonSummaryDerep,1)
                                if IonSummaryDerep(u1,7,g)~=0
                                    vot=0;
                                    for u2=1:size(IonSummaryTS,1)
                                        if abs(IonSummaryDerep(u1,7,g)-IonSummaryTS(u2,6,h))<MassDifferTor
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        Tereplicate_hit=1;
                                    end
                                end
                            end
                            Tereplicate_hot=0;
                            for u1=1:size(IonSummaryTS,1)
                                if IonSummaryDerep(u2,7,g)~=0
                                    vot=0;
                                    for u2=1:size(IonSummaryDerep,1)
                                        if abs(IonSummaryDerep(u2,7,g)-IonSummaryTS(u1,6,h))<MassDifferTor
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        Tereplicate_hot=1;
                                    end
                                end
                            end
                            if Tereplicate_hit==0
                                Replicate=1;
                                if Tereplicate_hot==1
                                    Replicate=2;
                                    h_Code=h;
                                end
                            end
                        end
                    end
                    if Tereplicate==1
                        if Replicate==0
                            nIonSummaryTS=nIonSummaryTS+1;
                            IonSummaryTS(1:size(IonSummaryDerep,1),1,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,g);
                            IonSummaryTS(1:size(IonSummaryDerep,1),2:8,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,g);
                        else if Replicate==2
                                IonSummaryTS(1:size(IonSummaryDerep,1),1,h_Code)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,g);
                                IonSummaryTS(1:size(IonSummaryDerep,1),2:8,h_Code)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,g);
                            end
                        end
                    end
                    
                    if Tereplicate==0
                        nIonSummaryTS=nIonSummaryTS+1;
                        IonSummaryTS(1:size(IonSummaryDerep,1),1,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,g);
                        IonSummaryTS(1:size(IonSummaryDerep,1),2:8,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,g);
                    end
                    
                end
            end
            for rID=1:size(IonSummaryTS,3)
                TimeTableTemp(rID,1)=IonSummaryTS(1,2,rID);
                TimeTableTemp(rID,2)=0;
            end
            TimeTableTemp=sortrows(TimeTableTemp,1);
            for TTT=1:size(IonSummaryTS,3)
                for rID=1:size(IonSummaryTS,3)
                    if TimeTableTemp(TTT,1)==IonSummaryTS(1,2,rID) && rID~=TimeTableTemp(TTT,2)
                        IonSummaryTS2(:,:,TTT)=IonSummaryTS(:,:,rID);
                        TimeTableTemp(TTT,2)=rID;
                    end
                end
            end
            clear IonSummaryTS
            IonSummaryTS=IonSummaryTS2;
            clear IonSummaryTS2 TimeTableTemp
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            for rID=1:size(IonSummaryTS,3)
                ConID=IonSummaryTS(1,1,rID);
                for iFile=1:nOfFiles
                    if (strcmp(files(iFile).name(1:4),'DENO'))
                        MaSuDN(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                    && strcmp(files(iFile).name(13),'N')
                                MaSuDN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                    && strcmp(files(iFile).name(14),'N')
                                MaSuDN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=3;
                            end
                        end
                        if SamID<10 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                    && strcmp(files(iFile).name(14),'N')
                                MaSuDN(1,1)=4;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=5;
                            end
                        end
                        if SamID>=100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                    && strcmp(files(iFile).name(16),'N')
                                MaSuDN(1,1)=6;
                            end
                        end
                        if SamID<10 && ConID>=100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                    && strcmp(files(iFile).name(15),'N')
                                MaSuDN(1,1)=7;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                    && strcmp(files(iFile).name(16),'N')
                                MaSuDN(1,1)=8;
                            end
                        end
                        if SamID>=100 && ConID>=100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                    && strcmp(files(iFile).name(17),'N')
                                MaSuDN(1,1)=9;
                            end
                        end
                        if MaSuDN(1,1)>0
                            IntSumTemp=load(files(iFile).name);
                            
                            for r=1:size(IonSummaryTS,1)
                                OiO=0;
                                for w=1:size(IntSumTemp,1)
                                    if abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1))<MassDifferTor
                                        if OiO==0
                                            IonSummaryTS(r,9,rID)=IntSumTemp(w,12);
                                            TDSet=abs(IonSummaryTS(r,2,rID)-IntSumTemp(w,2));
                                            MDSet=abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1));
                                            IntSet=IntSumTemp(w,11);
                                            OiO=1;
                                            if IntSet>IonSummaryTS(r,7,rID)
                                                IonSummaryTS(r,7,rID)=IntSet;
                                            end
                                        else
                                            if abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1))<MDSet
                                                if IonSummaryTS(r,7,rID)>IntSet
                                                    TDSet=abs(IonSummaryTS(r,2,rID)-IntSumTemp(w,2));
                                                    MDSet=abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1));
                                                    IntSet=IntSumTemp(w,11);
                                                    IonSummaryTS(r,7,rID)=IntSet;
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            nIsoSummary=0;
            for rID=1:size(IonSummaryTS,3)
                nIsoSummary=nIsoSummary+1;
                
                IonSummaryTemp=IonSummaryTS(:,:,rID);
                IonSummaryTemp=sortrows(IonSummaryTemp,-7);
                
                IsoSummary(nIsoSummary,1:3)=DSBehavior_Extended(IonSummaryTemp(1,8),3:5);
                
                tR_Assume=0.1:0.1:100;
                tR_Assume=tR_Assume';
                solutionCount=0;
                for o=1:size(tR_Assume,1)
                    tR=tR_Assume(o,1);
                    for ut=2:MBLength
                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                            RatioH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                            u0=ut;
                            volH2O=0;
                            for u1=1:u0-1
                                volH2O=volH2O+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                            end
                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-RatioH2O)*(MB(u0,1)-tR);
                            volH2O=volH2O/100;
                            volMeOH(1,1)=tR-volH2O;
                            RatioStrong=log10(volH2O/tR);
                        end
                    end
                    tR0=10^((RatioStrong-IsoSummary(nIsoSummary,2))/IsoSummary(nIsoSummary,1));
                    solutionCount=solutionCount+1;
                    solutionSet(solutionCount,1)=tR;
                    solutionSet(solutionCount,3)=abs(tR-tR0);
                    solutionSet(solutionCount,2)=RatioStrong;
                end
                if solutionCount>0
                    for o=1:solutionCount
                        if solutionSet(o,3)==min(solutionSet(:,3))
                            IsoSummary(nIsoSummary,4)=solutionSet(o,1);
                        end
                    end
                end
                clear solutionSet
                IsoSummary(nIsoSummary,5)=0;
                IntThreshold=0.8;
                nIon=0;
                for z=1:size(IonSummaryTemp,1)
                    if IonSummaryTemp(z,7)/max(IonSummaryTemp(:,7))>=IntThreshold
                        IsoSummary(nIsoSummary,5)=IsoSummary(nIsoSummary,5)+IonSummaryTemp(z,7);
                        nIon=nIon+1;
                    end
                end
                IsoSummary(nIsoSummary,5)=IsoSummary(nIsoSummary,5)/nIon;
                IsoSummary(nIsoSummary,6)=IonSummaryTemp(1,9);
                nCount=1;
                nCountRem=0;
                IsoSummary(nIsoSummary,6+nCount)=IonSummaryTemp(1,6);
                if size(IonSummaryTS,1)>1
                    for u=2:size(IonSummaryTS,1)
                        if IonSummaryTemp(u,9)>0
                            if abs(IonSummaryTemp(u,9)-IsoSummary(nIsoSummary,6))<0.2
                                vot=0;
                                for z=1:nCount
                                    if abs(IonSummaryTemp(u,6)-IsoSummary(nIsoSummary,6+z))<IMI
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    nCount=nCount+1;
                                    IsoSummary(nIsoSummary,6+nCount)=IonSummaryTemp(u,6);
                                end
                            else if IonSummaryTemp(u,9)>0
                                    nCountRem=nCountRem+1;
                                    IsoTempRem(nCountRem,:)=IonSummaryTemp(u,:);
                                end
                            end
                        end
                    end
                    if nCountRem>0
                        nIsoSummary=nIsoSummary+1;
                        IsoSummary(nIsoSummary,6)=IsoTempRem(1,9);
                        nCountRemPlus=1;
                        IsoSummary(nIsoSummary,6+nCountRemPlus)=IsoTempRem(1,6);
                        for u=1:nCountRem
                            vot=0;
                            for z=1:nCountRemPlus
                                if abs(IsoTempRem(u,6)-IsoSummary(nIsoSummary,6+z))<IMI
                                    vot=1;
                                end
                            end
                            if vot==0
                                nCountRemPlus=nCountRemPlus+1;
                                IsoSummary(nIsoSummary,6+nCountRemPlus)=IsoTempRem(u,6);
                            end
                        end
                        clear IsoTempRem
                    end
                end
                clear IonSummaryTemp
            end
            
            MostAbundantIon=max(IsoSummary(:,5));
            IsoSummary(:,5)=IsoSummary(:,5)./MostAbundantIon;
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            nMassList=0;
            for u=1:size(IsoSummary,1)
                for v=7:size(IsoSummary,2)
                    if IsoSummary(u,v)>0
                        nMassList=nMassList+1;
                        MassList(nMassList,1)=IsoSummary(u,v);
                        MassList(nMassList,3)=IsoSummary(u,6);
                        if IsoSummary(u,4)>0
                            MassList(nMassList,2)=IsoSummary(u,4);
                        else
                            MassList(nMassList,2)=IsoSummary(u-1,4);
                        end
                    end
                end
            end
            
            for iUV=1:nOfFiles
                MaSuUV(1,1)=0;
                if (strcmp(files(iUV).name(1:3),'Sam'))
                    if SamID<10
                        if str2double(files(iUV).name(4))==SamID && str2double(files(iUV).name(8))==SlowestID(1,1) && ...
                                strcmp(files(iUV).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100
                        if str2double(files(iUV).name(4:5))==SamID && str2double(files(iUV).name(9))==SlowestID(1,1) && ...
                                strcmp(files(iUV).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iUV).name(4:6))==SamID && str2double(files(iUV).name(10))==SlowestID(1,1) && ...
                                strcmp(files(iUV).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iUV).name);
                        TIRA=UVTemp(size(UVTemp,1),1);
                    end
                end
            end
            for iMat=1:nOfMats
                if strcmp( Mats(iMat).name(1:3),'Sam')
                    nEInforSummaryGS=0;
                    MaSuMa(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==SlowestID(1,1)...
                                && (strcmp(Mats(iMat).name(9),'N'))...
                                && strcmp(Mats(iMat).name(10),'.')
                            MaSuMa(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==SlowestID(1,1)...
                                && (strcmp(Mats(iMat).name(10),'N'))...
                                && strcmp(Mats(iMat).name(11),'.')
                            MaSuMa(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==SlowestID(1,1)...
                                && (strcmp(Mats(iMat).name(11),'N'))...
                                && strcmp(Mats(iMat).name(12),'.')
                            MaSuMa(1,1)=3;
                        end
                    end
                    if MaSuMa(1,1)>0
                        data = load(Mats(iMat).name);
                        Scans=data.Scans;
                        dataWidth=size(Scans,2);
                        MergeMass=data.Masses;
                        dataLength=size(MergeMass,1);
                        MergeData=data.Data;
                        FH=round(TIRA*2.5*log10(dataWidth));
                        ATH=dataWidth;
                        Ratio=round(ATH/FH);
                        if Ratio>=1
                            iCol=0;
                            for k=1:Ratio:ATH-Ratio
                                iCol=iCol+1;
                                dataTemp(1:dataLength,1:Ratio)=MergeData(1:dataLength,k:k+Ratio-1);
                                for o=1:dataLength
                                    Data_New(o,iCol)=sum(dataTemp(o,1:Ratio));
                                end
                                MergeTime(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+Ratio-1))/Scans(1,dataWidth)*TIRA;
                            end
                        else
                            Ratio2=round(FH/ATH);
                            iCol=Ratio2*ATH;
                            for o=1:dataWidth
                                MergeTime(1,o*Ratio2-Ratio2+1:o*Ratio2)=Scans(1,o)/Scans(1,dataWidth)*TIRA;
                                for k=1:dataLength
                                    Data_New(k,o*Ratio2-Ratio2+1:o*Ratio2)=MergeData(k,o);
                                end
                            end
                        end
                        dataWidth=iCol;
                        XIC=zeros(dataWidth,2);
                        nEInforSummaryGS=0;
                        fr = FH/16;
                        dt = (16/FH)^2;
                        rick = ricker(FH,fr,dt,20);
                        rick_smooth = getSmoothRicker(rick);
                        for r=1:nMassList
                            for h=MassRange+1:dataLength-MassRange
                                if abs(MergeMass(h,1)-MassList(r,1))<MassDifferTor
                                    for j=1:dataWidth
                                        XIC(j,1)=MergeTime(1,j);
                                        XIC(j,2)=sum(Data_New(h-MassRange:h+MassRange,j));
                                    end
                                    smoothXIC0  = conv( rick_smooth(:,1),XIC(:,2) );
                                    smoothXIC(:,1)=XIC(:,1);
                                    smoothXIC(:,2)=smoothXIC0( round(length(rick_smooth)/2)+1:length(XIC(:,2))+round(length(rick_smooth)/2));
                                    smoothXICLength=size(smoothXIC,1);
                                    EThreshold=0.01;
                                    EPointGSNo=0;
                                    HighPoint=max(smoothXIC(:,2));
                                    for i=2:smoothXICLength-1
                                        if smoothXIC(i,2)>=smoothXIC(i-1,2) && smoothXIC(i,2)>=smoothXIC(i+1,2) && smoothXIC(i,2)> HighPoint*EThreshold && (smoothXIC(i,2)-smoothXIC(i-1,2))+(smoothXIC(i,2)-smoothXIC(i+1,2))~=0
                                            EPointGSNo=EPointGSNo+1;
                                            EPointGS(EPointGSNo,1) = smoothXIC(i,1);
                                            EPointGS(EPointGSNo,2) = smoothXIC(i,2);
                                        end;
                                    end;
                                    
                                    BaseLineTolerance=0.01;
                                    nEInfor=0;
                                    
                                    if EPointGSNo>0
                                        for m=1:EPointGSNo
                                            ETime=EPointGS(m,1);
                                            EHight=EPointGS(m,2);
                                            EPosition(1,1)=EPointGS(m,1);
                                            EPosition(1,2)=EPointGS(m,2);
                                            halfPH=EHight/2;
                                            
                                            for z=1:smoothXICLength
                                                if smoothXIC(z,1)==ETime
                                                    PP=z;
                                                end;
                                            end;
                                            
                                            vbv1=0;
                                            for z=PP:-1:2
                                                if smoothXIC(z,2)>=0 && smoothXIC(z-1,2)<=0 && vbv1==0
                                                    CrossZeroLeft=smoothXIC(z,1);
                                                    LeftIndex=z;
                                                    vbv1=1;
                                                end;
                                            end;
                                            
                                            if vbv1==0
                                                CrossZeroLeft=0;
                                                LeftIndex=1;
                                            end;
                                            
                                            vbv2=0;
                                            for z=PP:smoothXICLength-1
                                                if smoothXIC(z,2)>=0 && smoothXIC(z+1,2)<=0 && vbv2==0
                                                    CrossZeroRight=smoothXIC(z,1);
                                                    RightIndex=z;
                                                    vbv2=1;
                                                end;
                                            end;
                                            
                                            if vbv2==0
                                                CrossZeroRight=smoothXIC(smoothXICLength,1);
                                                RightIndex=smoothXICLength;
                                            end;
                                            
                                            EPointGS(m,3)=CrossZeroLeft;
                                            EPointGS(m,4)=CrossZeroRight;
                                            EPointGS(m,5)=(CrossZeroRight-CrossZeroLeft)/TIRA;
                                            EPointGS(m,6)=EHight/HighPoint;
                                            EPointGS(m,7)=EPointGS(m,6)/EPointGS(m,5);
                                            
                                            
                                            if LeftIndex>1 && RightIndex<smoothXICLength
                                                EPointGS(m,8)=0;
                                                for z=LeftIndex:RightIndex
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            if LeftIndex==1 && RightIndex<smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                for z=2:RightIndex
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            if LeftIndex>1 && RightIndex==smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                for z=LeftIndex:RightIndex-1
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            
                                            if LeftIndex==1 && RightIndex==smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                for z=2:smoothXICLength-1
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                        end;
                                        
                                        EPointGSShort(1,:)=EPointGS(1,:);
                                        nPPShort=1;
                                        for z=1:EPointGSNo
                                            if EPointGS(z,1)-EPointGSShort(nPPShort,1)<TimeDifferTor
                                                if EPointGS(z,2)>EPointGSShort(nPPShort,2)
                                                    EPointGSShort(nPPShort,1)=EPointGS(z,1);
                                                    EPointGSShort(nPPShort,2)=EPointGS(z,2);
                                                end;
                                                if EPointGS(z,3)>EPointGSShort(nPPShort,3)
                                                    EPointGSShort(nPPShort,3)=EPointGS(z,3);
                                                end;
                                                if EPointGS(z,4)<EPointGSShort(nPPShort,4)
                                                    EPointGSShort(nPPShort,4)=EPointGS(z,4);
                                                end;
                                                EPointGSShort(nPPShort,5)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))/TIRA;
                                                EPointGSShort(nPPShort,6)=EPointGSShort(nPPShort,2)/HighPoint;
                                                EPointGSShort(nPPShort,7)=EPointGSShort(nPPShort,6)/EPointGSShort(nPPShort,5);
                                                EPointGSShort(nPPShort,8)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))*EPointGSShort(nPPShort,2)/2;
                                            else
                                                nPPShort=nPPShort+1;
                                                EPointGSShort(nPPShort,:)=EPointGS(z,:);
                                            end;
                                        end;
                                        
                                        LargestE=max(EPointGSShort(:,8));
                                        
                                        EPointGSShort(:,9)=EPointGSShort(:,8)/LargestE;
                                        
                                        
                                        
                                        if nPPShort>0
                                            for s=1:nPPShort
                                                if abs(EPointGSShort(s,1)-MassList(r,2))<TimeDifferTor*4 && EPointGSShort(s,9)>RelArea
                                                    if size(MassList,2)==3 || MassList(r,3)==0
                                                        MassList(r,4)=EPointGSShort(s,1);
                                                        MassList(r,5)=EPointGSShort(s,8);
                                                        MassList(r,6)=MergeMass(h,1);
                                                        
                                                    else
                                                        if abs(MassList(r,3)-MassList(r,2))>TimeDifferTor*2
                                                            if abs(EPointGSShort(s,1)-MassList(r,2))<abs(MassList(r,3)-MassList(r,2))
                                                                MassList(r,4)=EPointGSShort(s,1);
                                                                MassList(r,5)=EPointGSShort(s,8);
                                                                MassList(r,6)=MergeMass(h,1);
                                                            end
                                                        else
                                                            if MassList(r,4)<EPointGSShort(s,8)
                                                                MassList(r,4)=EPointGSShort(s,1);
                                                                MassList(r,5)=EPointGSShort(s,8);
                                                                MassList(r,6)=MergeMass(h,1);
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                            
                                            
                                            clear EPointGS LeftPoint RightPoint EPointGSShort ...
                                                width EPosition;
                                            
                                        end
                                        
                                        
                                    end
                                    
                                    clear XIC smoothXIC section;
                                end
                            end
                        end
                    end
                end
            end
            
            MassList=sortrows(MassList,4);
            
            
            nCRAD_Es=0;
            nr=0;
            nredIsomer=0;
            for z=1:size(MassList,1)
                if MassList(z,4)>0
                    
                    nCRAD_Es=nCRAD_Es+1;
                    CRAD_Es(nCRAD_Es,1)=MassList(z,6);
                    CRAD_Es(nCRAD_Es,2)=MassList(z,4);
                    CRAD_Es(nCRAD_Es,3)=MassList(z,5);
                    CRAD_Es(nCRAD_Es,4)=MassList(z,3);
                    
                    if nredIsomer==0
                        nredIsomer=nredIsomer+1;
                        redIsomers(nredIsomer,:)=MassList(z,:);
                    else
                        if redIsomers(nredIsomer,2)==MassList(z,2) &&...
                                MassList(z,4)-redIsomers(nredIsomer,4)<=TimeDifferTor
                            nredIsomer=nredIsomer+1;
                            redIsomers(nredIsomer,:)=MassList(z,:);
                        else
                            redIsomers_short=unique(redIsomers,'rows');
                            clear redIsomers
                            redIsomers=redIsomers_short;
                            redIsomers=sortrows(redIsomers,3);
                            nredIsomer=size(redIsomers,1);
                            nr=nr+1;
                            if nredIsomer>1
                                o=nredIsomer;
                                for k=1:nredIsomer-1
                                    if redIsomers(k,3)~=redIsomers(k+1,3)
                                        o=k;
                                    end
                                end
                                if o<nredIsomer
                                    redIsomers1=redIsomers(1:o,1:6);
                                    redIsomers1=sortrows(redIsomers1,-5);
                                    IsoSummary2(nr,6,1)=redIsomers1(1,3);
                                    IsoSummary2(nr,4,1)=redIsomers1(1,4);
                                    IsoSummary2(nr,5,1)=0;
                                    for p=1:o
                                        if size(IsoSummary2,2)>6
                                            vot=0;
                                            for v=7:size(IsoSummary2,2)
                                                if IsoSummary2(nr,v,1)==redIsomers1(p,6)
                                                    vot=1;
                                                end
                                            end
                                            if vot==0
                                                IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                                if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                                end
                                            end
                                        else
                                            IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                            if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                                IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                            end
                                        end
                                    end
                                    
                                    redIsomers2=redIsomers(o+1:nredIsomer,1:6);
                                    redIsomers2=sortrows(redIsomers2,-5);
                                    IsoSummary2(nr,6,2)=redIsomers2(1,3);
                                    IsoSummary2(nr,5,2)=0;
                                    for p=1:nredIsomer-o
                                        if size(IsoSummary2,2)>6
                                            vot=0;
                                            for v=7:size(IsoSummary2,2)
                                                if IsoSummary2(nr,v,2)==redIsomers2(p,6)
                                                    vot=1;
                                                end
                                            end
                                            if vot==0
                                                IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                                if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                                    IsoSummary2(nr,5,2)=IsoSummary2(nr,5,1)+redIsomers2(p,5);
                                                end
                                            end
                                        else
                                            IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                            if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                                IsoSummary2(nr,5,2)=IsoSummary2(nr,5,2)+redIsomers2(p,5);
                                            end
                                        end
                                    end
                                    
                                    clear redIsomers1 redIsomers2
                                else
                                    redIsomers=sortrows(redIsomers,-5);
                                    IsoSummary2(nr,6,1)=redIsomers(1,3);
                                    IsoSummary2(nr,4,1)=redIsomers(1,4);
                                    IsoSummary2(nr,5,1)=0;
                                    for p=1:o
                                        if size(IsoSummary2,2)>6
                                            vot=0;
                                            for v=7:size(IsoSummary2,2)
                                                if IsoSummary2(nr,v,1)==redIsomers(p,6)
                                                    vot=1;
                                                end
                                            end
                                            if vot==0
                                                IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                                if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                                end
                                            end
                                        else
                                            IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                            if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                                IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                            end
                                        end
                                    end
                                end
                                
                            else
                                IsoSummary2(nr,7,1)=redIsomers(nredIsomer,6);
                                IsoSummary2(nr,6,1)=redIsomers(nredIsomer,3);
                                IsoSummary2(nr,5,1)=redIsomers(nredIsomer,5);
                                IsoSummary2(nr,4,1)=redIsomers(nredIsomer,4);
                            end
                            clear redIsomers
                            nredIsomer=1;
                            redIsomers(nredIsomer,:)=MassList(z,:);
                        end
                    end
                end
            end
            
            if nredIsomer>0
                redIsomers_short=unique(redIsomers,'rows');
                clear redIsomers
                redIsomers=redIsomers_short;
                redIsomers=sortrows(redIsomers,3);
                nredIsomer=size(redIsomers,1);
                nr=nr+1;
                if nredIsomer>1
                    o=nredIsomer;
                    for k=1:nredIsomer-1
                        if redIsomers(k,3)~=redIsomers(k+1,3)
                            o=k;
                        end
                    end
                    if o<nredIsomer
                        redIsomers1=redIsomers(1:o,1:6);
                        redIsomers1=sortrows(redIsomers1,-5);
                        IsoSummary2(nr,6,1)=redIsomers1(1,3);
                        IsoSummary2(nr,4,1)=redIsomers1(1,4);
                        IsoSummary2(nr,5,1)=0;
                        for p=1:o
                            if size(IsoSummary2,2)>6
                                vot=0;
                                for v=7:size(IsoSummary2,2)
                                    if IsoSummary2(nr,v,1)==redIsomers1(p,6)
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                    if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                        IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                    end
                                end
                            else
                                IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                end
                            end
                        end
                        
                        redIsomers2=redIsomers(o+1:nredIsomer,1:6);
                        redIsomers2=sortrows(redIsomers2,-5);
                        IsoSummary2(nr,6,2)=redIsomers2(1,3);
                        IsoSummary2(nr,5,2)=0;
                        for p=1:nredIsomer-o
                            if size(IsoSummary2,2)>6
                                vot=0;
                                for v=7:size(IsoSummary2,2)
                                    if IsoSummary2(nr,v,2)==redIsomers2(p,6)
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                    if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                        IsoSummary2(nr,5,2)=IsoSummary2(nr,5,1)+redIsomers2(p,5);
                                    end
                                end
                            else
                                IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                    IsoSummary2(nr,5,2)=IsoSummary2(nr,5,2)+redIsomers2(p,5);
                                end
                            end
                        end
                        
                        clear redIsomers1 redIsomers2
                    else
                        redIsomers=sortrows(redIsomers,-5);
                        IsoSummary2(nr,6,1)=redIsomers(1,3);
                        IsoSummary2(nr,4,1)=redIsomers(1,4);
                        IsoSummary2(nr,5,1)=0;
                        for p=1:o
                            if size(IsoSummary2,2)>6
                                vot=0;
                                for v=7:size(IsoSummary2,2)
                                    if IsoSummary2(nr,v,1)==redIsomers(p,6)
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                    if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                        IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                    end
                                end
                            else
                                IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                end
                            end
                        end
                    end
                    
                else
                    IsoSummary2(nr,7,1)=redIsomers(nredIsomer,6);
                    IsoSummary2(nr,6,1)=redIsomers(nredIsomer,3);
                    IsoSummary2(nr,5,1)=redIsomers(nredIsomer,5);
                    IsoSummary2(nr,4,1)=redIsomers(nredIsomer,4);
                end
                clear redIsomers
            end
            
            nIsoSummary3=0;
            if nr>0
                for z=1:nr
                    nIsoSummary3=nIsoSummary3+1;
                    IsoSummary3(nIsoSummary3,1:size(IsoSummary2,2))=IsoSummary2(z,:,1);
                    if IsoSummary2(z,7,2)>0
                        nIsoSummary3=nIsoSummary3+1;
                        IsoSummary3(nIsoSummary3,1:size(IsoSummary2,2))=IsoSummary2(z,:,2);
                    end
                end
            end
            
            for iMat=1:nOfMats
                MaSuTN(1,1)=0;
                if (strcmp(Mats(iMat).name(1:4),'TDAN'))
                    if SamID<10
                        if str2double(Mats(iMat).name(8))==SamID && strcmp(Mats(iMat).name(9),'N')
                            MaSuTN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(Mats(iMat).name(8:9))==SamID && strcmp(Mats(iMat).name(10),'N')
                            MaSuTN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(Mats(iMat).name(8:10))==SamID && strcmp(Mats(iMat).name(11),'N')
                            MaSuTN(1,1)=3;
                        end
                    end
                    if MaSuTN(1,1)>0
                        data = load(Mats(iMat).name);
                        TDAN=data.TapdancerBYAbun;
                    end
                end
            end
            
            for z=1:size(IsoSummary3,1)
                if z==1
                    MassTime1(1,1)=IsoSummary3(z,7);
                    MassTime1(1,2)=IsoSummary3(z,4);
                    SlopeLine=1;
                    if IsoSummary3(z+1,4)==0
                        No1=0;
                        for v=7:size(IsoSummary3,2)
                            if IsoSummary3(z,v)>0
                                No1=No1+1;
                            end
                        end
                        No2=0;
                        for v=7:size(IsoSummary3,2)
                            if IsoSummary3(z+1,v)>0
                                No2=No2+1;
                            end
                        end
                        if No2>No1
                            MassTime1(1,1)=IsoSummary3(z+1,7);
                        end
                        if No2==No1 && IsoSummary3(z+1,5)>IsoSummary3(z,5)
                            MassTime1(1,1)=IsoSummary3(z+1,7);
                        end
                    end
                end
                if z>1 && z<size(IsoSummary3,1) && IsoSummary3(z,4)~=0
                    MassTime1(1,1)=IsoSummary3(z,7);
                    MassTime1(1,2)=IsoSummary3(z,4);
                    SlopeLine=z;
                    if IsoSummary3(z+1,4)==0
                        if IsoSummary3(z+1,4)==0
                            No1=0;
                            for v=7:size(IsoSummary3,2)
                                if IsoSummary3(z,v)>0
                                    No1=No1+1;
                                end
                            end
                            No2=0;
                            for v=7:size(IsoSummary3,2)
                                if IsoSummary3(z+1,v)>0
                                    No2=No2+1;
                                end
                            end
                            if No2>No1
                                MassTime1(1,1)=IsoSummary3(z+1,7);
                            end
                            if No2==No1 && IsoSummary3(z+1,5)>IsoSummary3(z,5)
                                MassTime1(1,1)=IsoSummary3(z+1,7);
                            end
                        end
                    end
                end
                if z==size(IsoSummary3,1)
                    if IsoSummary3(z,4)~=0
                        SlopeLine=z;
                        MassTime1(1,1)=IsoSummary3(z,7);
                        MassTime1(1,2)=IsoSummary3(z,4);
                    end
                end
                
                nMatch=0;
                for v=1:size(TDAN,3)
                    MatchTime=0;
                    for w=1:4:size(TDAN,2)
                        for u=1:size(TDAN,1)
                            if abs(MassTime1(1,2)-TDAN(u,w+1,v))>TimeDifferTor*2 && TDAN(u,w+1,v)~=0 ...
                                    && w==1
                                MatchTime=MatchTime-0.25;
                            end
                            if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDifferTor*2
                                if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDifferTor*2 && w==1
                                    MatchTime=MatchTime+1;
                                end
                                if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                    MatchTime=MatchTime+0.25;
                                end
                            end
                        end
                    end
                    if MatchTime>0
                        nMatch=nMatch+1;
                        MatchMatrix(nMatch,1)=MatchTime;
                        MatchMatrix(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                        MatchMatrix(nMatch,5)=v;
                    end
                end
                if nMatch>0
                    nMatchShort=0;
                    for u=1:nMatch
                        if MatchMatrix(u,1)==max(MatchMatrix(:,1))
                            nMatchShort=nMatchShort+1;
                            MatchMatrixShort(nMatchShort,:)=MatchMatrix(u,:);
                        end
                    end
                    
                    MatchMatrixShort=sortrows(MatchMatrixShort,2);
                    IsoSummary3(SlopeLine,1:3)=MatchMatrixShort(1,2:4);
                    clear MatchMatrix MatchMatrixShort
                else
                    for v=1:size(TDAN,3)
                        MatchTime=0;
                        for w=1:4:size(TDAN,2)
                            for u=1:size(TDAN,1)
                                if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDifferTor
                                    if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDifferTor*8 && w==1
                                        MatchTime=MatchTime+1;
                                    end
                                    if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                        MatchTime=MatchTime+0.25;
                                    end
                                end
                            end
                        end
                        
                        if MatchTime>0
                            nMatch=nMatch+1;
                            MatchMatrix(nMatch,1)=MatchTime;
                            MatchMatrix(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                            MatchMatrix(nMatch,5)=v;
                        end
                    end
                    if nMatch>0
                        nMatchShort=0;
                        for u=1:nMatch
                            if MatchMatrix(u,1)==max(MatchMatrix(:,1))
                                nMatchShort=nMatchShort+1;
                                MatchMatrixShort(nMatchShort,:)=MatchMatrix(u,:);
                            end
                        end
                        MatchMatrixShort=sortrows(MatchMatrixShort,2);
                        IsoSummary3(SlopeLine,1:2)=MatchMatrixShort(1,2:3);
                        clear MatchMatrix MatchMatrixShort
                    end
                end
            end
            
            nIsoSummary4=0;
            for z=1:size(IsoSummary3,1)
                if IsoSummary3(z,3)==0 && IsoSummary3(z,4)~=0
                    if IsoSummary3(z,1)~=0
                        for u=1:size(IsoSummary3,1)
                            if IsoSummary3(z,1)==IsoSummary3(u,1) && ...
                                    IsoSummary3(z,2)==IsoSummary3(u,2) && ...
                                    IsoSummary3(u,3)~=0
                                if IsoSummary3(u+1,4)~=0
                                    for v=7:size(IsoSummary3,2)
                                        if IsoSummary3(u,v)==0
                                            v0=v-1;
                                            break
                                        end
                                    end
                                    for v=7:size(IsoSummary3,2)
                                        if IsoSummary3(z,v)>0
                                            IsoSummary3(u,v0+v-6)=IsoSummary3(z,v);
                                        end
                                    end
                                else
                                    if abs(IsoSummary3(u,6)-IsoSummary3(z,6))<abs(IsoSummary3(u+1,6)-IsoSummary3(z,6))
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(u,v)==0
                                                v0=v-1;
                                                break
                                            end
                                        end
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(z,v)>0
                                                IsoSummary3(u,v0+v-6)=IsoSummary3(z,v);
                                            end
                                        end
                                    else
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(u+1,v)==0
                                                v0=v-1;
                                                break
                                            end
                                        end
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(z,v)>0
                                                IsoSummary3(u+1,v0+v-6)=IsoSummary3(z,v);
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            for z=1:size(IsoSummary3,1)
                if IsoSummary3(z,3)>0 || (IsoSummary3(z,3)==0 && IsoSummary3(z,4)==0 && IsoSummary3(z-1,3)>0)
                    nIsoSummary4=nIsoSummary4+1;
                    IsoSummary4(nIsoSummary4,1:size(IsoSummary3,2))=IsoSummary3(z,1:size(IsoSummary3,2));
                end
            end
            
            clear IsoSummary IsoSummary2 IsoSummary3
            
            IsoSummary=IsoSummary4;
            EInt=max(IsoSummary(:,5));
            IsoSummary(:,5)=IsoSummary(:,5)./EInt;
            nIsoSummary=size(IsoSummary,1);
            clear IsoSummary4
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            if nIsoSummary>0
                for u1=1:nIsoSummary
                    for u2=u1:nIsoSummary
                        if u1~=u2 && IsoSummary(u1,4)*IsoSummary(u2,4)~=0 && ...
                                IsoSummary(u1,4)==IsoSummary(u2,4) && ...
                                IsoSummary(u1,3)==IsoSummary(u2,3) && ...
                                IsoSummary(u1,2)==IsoSummary(u2,2) && ...
                                IsoSummary(u1,1)==IsoSummary(u2,1)
                            
                            RefIon1=IsoSummary(u1,7:size(IsoSummary,2))';
                            RefIon2=IsoSummary(u2,7:size(IsoSummary,2))';
                            RefIon=[RefIon1;RefIon2];
                            if u1<nIsoSummary
                                if IsoSummary(u1+1,4)==0;
                                    RefIon3=IsoSummary(u1+1,7:size(IsoSummary,2))';
                                    RefIon_A=[RefIon;RefIon3];
                                    clear RefIon
                                    RefIon=RefIon_A;
                                    clear RefIon_A
                                end
                            end
                            if u2<nIsoSummary
                                if IsoSummary(u2+1,4)==0;
                                    RefIon4=IsoSummary(u2+1,7:size(IsoSummary,2))';
                                    RefIon_A=[RefIon;RefIon4];
                                    clear RefIon
                                    RefIon=RefIon_A;
                                    clear RefIon_A
                                end
                            end
                            
                            RefIonShort=unique(RefIon,'rows');
                            RefIonShort=sortrows(RefIonShort,1);
                            nRefIonDS=0;
                            for j=1:size(RefIonShort,1)
                                for z=1:size(CRAD_Es,1)
                                    if RefIonShort(j,1)~=0 && RefIonShort(j,1)==CRAD_Es(z,1) ...
                                            && abs(IsoSummary(u1,4)-CRAD_Es(z,2))<TimeDifferTor
                                        nRefIonDS=nRefIonDS+1;
                                        RefIonDS(nRefIonDS,1:4)=CRAD_Es(z,1:4);
                                    end
                                end
                            end
                            RefIonDS=sortrows(RefIonDS,-3);
                            RefIonDSS=RefIonDS(:,1)';
                            IsoSummary(u1,7:nRefIonDS+6)=RefIonDSS;
                            IsoSummary(u2,7:nRefIonDS+6)=RefIonDSS;
                            
                            clear RefIonDS RefIonDSS
                        end
                    end
                end
            end
            if nIsoSummary>1
                nIsoSummaryShort=1;
                IsoSummaryShort(nIsoSummaryShort,:)=IsoSummary(1,:);
                for u1=2:nIsoSummary
                    vot=0;
                    for u2=1:nIsoSummaryShort
                        if isequal(IsoSummaryShort(u2,1:4),IsoSummary(u1,1:4))==1 && ...
                                isequal(IsoSummaryShort(u2,7:size(IsoSummaryShort,2)),IsoSummary(u1,7:size(IsoSummary,2)))==1
                            vot=1;
                        end
                    end
                    if vot==0
                        nIsoSummaryShort=nIsoSummaryShort+1;
                        IsoSummaryShort(nIsoSummaryShort,:)=IsoSummary(u1,:);
                    end
                end
            end
            clear IsoSummary
            IsoSummary=IsoSummaryShort;
            nIsoSummary=nIsoSummaryShort;
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'N']);
            
            str= sprintf('%s/%s%s%s%s',new_folder,'IDCS','Sam',num2str(SamID),'N.txt');
            fid=fopen(str,'w');
            for u=1:nIsoSummary
                fprintf(fid,'%.4f ',IsoSummary(u,1));
                fprintf(fid,'%.4f ',IsoSummary(u,2));
                if IsoSummary(u,3)<MiMLinearity && IsoSummary(u,2)~=0
                    IsoSummary(u,3)=MiMLinearity;
                end
                fprintf(fid,'%.2f ',IsoSummary(u,3));
                fprintf(fid,'%.1f ',IsoSummary(u,4));
                fprintf(fid,'%.4f ',IsoSummary(u,5));
                fprintf(fid,'%.3f ',IsoSummary(u,6));
                
                for v=7:size(IsoSummary,2)
                    fprintf(fid,'%.2f ',IsoSummary(u,v));
                end
                fprintf(fid,'\n');
            end
            fclose(fid);
            clear IsoSummary
            
            
            
            str= sprintf('%s/%s%s%s%s',new_folder,'CRPL','Sam',num2str(SamID),'N.txt');
            fid=fopen(str,'w');
            for u=1:nCRAD_Es
                for v=1:4
                    fprintf(fid,'%.4f ',CRAD_Es(u,v));
                end
                fprintf(fid,'\n');
            end
            fclose(fid);
            clear CRAD_Es
            
        end
    end
    clearvars -except t0 IntensityThreshold_Positive IntensityThreshold_Negative ionMode PXSet RelArea MassRange MassResolution ...
        rDifferRatioControl IMI INTDiffer IRT IntensityThreshold IntersectDifferTolerance...
        IsotopeVariance MB MBLength MBWidth MIMAssocIons MassDifferTor Mats MaxIsotopeRatio MiMLinearity MiMRep NosEliDiffer...
        PXSet RedundantIons RelArea SamID SamNoEn SamNoSt SlopeDifferTolerance SlowestID TimeDifferTor TimeVariance files ...
        nOfFiles nOfMats new_folder t00 ConNo ConsideredConditionNo
    
    t01=cputime-t00;
    disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
    AddedLength=0;
    for SlowestIDNo=1:ConsideredConditionNo
        ConID=SlowestID(1,SlowestIDNo);
        GINFCode=0;
        for iFile=1:nOfFiles
            if (strcmp(files(iFile).name(1:4),'GINF'))
                MaSuGI(1,1)=0;
                if SamID<10 && ConID<10
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                            && strcmp(files(iFile).name(13),'P')
                        MaSuGI(1,1)=1;
                    end
                end
                if SamID>=10 && SamID<100 && ConID<10
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                            && strcmp(files(iFile).name(14),'P')
                        MaSuGI(1,1)=2;
                    end
                end
                if SamID>=100 && ConID<10
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                            && strcmp(files(iFile).name(15),'P')
                        MaSuGI(1,1)=3;
                    end
                end
                if SamID<10 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                            && strcmp(files(iFile).name(14),'P')
                        MaSuGI(1,1)=4;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                            && strcmp(files(iFile).name(15),'P')
                        MaSuGI(1,1)=5;
                    end
                end
                if SamID>=100 && ConID>=10 && ConID<100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                            && strcmp(files(iFile).name(16),'P')
                        MaSuGI(1,1)=6;
                    end
                end
                if SamID<10 && ConID>=100
                    if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                            && strcmp(files(iFile).name(15),'P')
                        MaSuGI(1,1)=7;
                    end
                end
                if SamID>=10 && SamID<100 && ConID>=100
                    if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                            && strcmp(files(iFile).name(16),'P')
                        MaSuGI(1,1)=8;
                    end
                end
                if SamID>=100 && ConID>=100
                    if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                            && strcmp(files(iFile).name(17),'P')
                        MaSuGI(1,1)=9;
                    end
                end
                if MaSuGI(1,1)>0
                    GISumTemp=load(files(iFile).name);
                    GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),1)=ConID;
                    GISumTemp2(AddedLength+1:AddedLength+size(GISumTemp,1),2:size(GISumTemp,2)+1)=GISumTemp;
                    GINFCode=1;
                end
            end
        end
        if GINFCode==1
            for iFile=1:nOfFiles
                if (strcmp(files(iFile).name(1:4),'DENO'))
                    MaSuDN(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                && strcmp(files(iFile).name(13),'P')
                            MaSuDN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuDN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=3;
                        end
                    end
                    if SamID<10 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                && strcmp(files(iFile).name(14),'P')
                            MaSuDN(1,1)=4;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=5;
                        end
                    end
                    if SamID>=100 && ConID>=10 && ConID<100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuDN(1,1)=6;
                        end
                    end
                    if SamID<10 && ConID>=100
                        if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                && strcmp(files(iFile).name(15),'P')
                            MaSuDN(1,1)=7;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID>=100
                        if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                && strcmp(files(iFile).name(16),'P')
                            MaSuDN(1,1)=8;
                        end
                    end
                    if SamID>=100 && ConID>=100
                        if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                && strcmp(files(iFile).name(17),'P')
                            MaSuDN(1,1)=9;
                        end
                    end
                    if MaSuDN(1,1)>0
                        IntSumTemp=load(files(iFile).name);
                        for u=AddedLength+1:AddedLength+size(GISumTemp,1)
                            OiO=0;
                            for z=1:size(IntSumTemp,1)
                                if abs(GISumTemp2(u,7)-IntSumTemp(z,1))<=MassDifferTor && ...
                                        abs(GISumTemp2(u,3)-IntSumTemp(z,2))<TimeDifferTor*4
                                    if GISumTemp2(u,8)==IntSumTemp(z,10);
                                        OiO=OiO+1;
                                        Temp_OiO(OiO,1)=abs(GISumTemp2(u,7)-IntSumTemp(z,1));
                                        Temp_OiO(OiO,2)=abs(GISumTemp2(u,3)-IntSumTemp(z,2));
                                        Temp_OiO(OiO,3)=IntSumTemp(z,11);
                                        Temp_OiO(OiO,4)=IntSumTemp(z,2);
                                    end
                                end
                            end
                            if OiO>0
                                Temp_OiO=sortrows(Temp_OiO,-3);
                                GISumTemp2(u,3)=Temp_OiO(1,4);
                                GISumTemp2(u,8)=Temp_OiO(1,3);
                            else
                                GISumTemp2(u,8)=0;
                            end
                        end
                        AddedLength=AddedLength+size(GISumTemp,1);
                        clear GISumTemp
                    end
                end
            end
        end
    end
    if AddedLength>0
        GISumTemp2=sortrows(GISumTemp2,[1,7]);
        GISumTemp3=GISumTemp2;
        clear GISumTemp2
        nGISumTemp2=0;
        for h=1:size(GISumTemp3,1)
            tR_Assume=0.1:0.1:100;
            tR_Assume=tR_Assume';
            solutionCount=0;
            for o=1:size(tR_Assume,1)
                tR=tR_Assume(o,1);
                for ut=2:MBLength
                    if tR>MB(ut-1,1) && tR<MB(ut,1)
                        RatioH2O=(tR-MB(ut-1,1))*((MB(ut,GISumTemp3(h,1)+1)-MB(ut-1,GISumTemp3(h,1)+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,GISumTemp3(h,1)+1);
                        u0=ut;
                        volH2O=0;
                        for u1=1:u0-1
                            volH2O=volH2O+MB(u1+1,GISumTemp3(h,1)+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,GISumTemp3(h,1)+1)-MB(u1,GISumTemp3(h,1)+1))*(MB(u1+1,1)-MB(u1,1));
                        end
                        volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,GISumTemp3(h,1)+1)+(MB(u0,GISumTemp3(h,1)+1)-RatioH2O)*(MB(u0,1)-tR);
                        volH2O=volH2O/100;
                        volMeOH(1,GISumTemp3(h,1))=tR-volH2O;
                        RatioStrong=log10(volH2O/tR);
                    end
                end
                
                tR0=10^((RatioStrong-GISumTemp3(h,5))/GISumTemp3(h,4));
                if abs(tR-tR0)<TimeDifferTor*4
                    solutionCount=solutionCount+1;
                    solutionSet(solutionCount,1)=tR;
                    solutionSet(solutionCount,3)=abs(tR-tR0);
                    solutionSet(solutionCount,2)=RatioStrong;
                end
            end
            for o=1:solutionCount
                if solutionSet(o,3)==min(solutionSet(:,3))
                    GISumTemp3(h,9)=solutionSet(o,1);
                    if abs(GISumTemp3(h,9)-GISumTemp3(h,3))<TimeDifferTor*2
                        nGISumTemp2=nGISumTemp2+1;
                        GISumTemp2(nGISumTemp2,1:8)=GISumTemp3(h,1:8);
                    end
                end
            end
            clear solutionSet
        end
        clear GISumTemp3
    end
    t01=cputime-t00;
    disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
    if AddedLength>0
        RetentionBehavior(:,1:3)=GISumTemp2(:,4:6);
        ShortBehavior=unique(RetentionBehavior,'rows');
        ShortBehavior=sortrows(ShortBehavior,3);
        
        for s=1:size(ShortBehavior,1)
            tR_Assume=0.1:0.1:100;
            tR_Assume=tR_Assume';
            solutionCount=0;
            for o=1:size(tR_Assume,1)
                tR=tR_Assume(o,1);
                for ut=2:MBLength
                    if tR>MB(ut-1,1) && tR<MB(ut,1)
                        RatioH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                        u0=ut;
                        volH2O=0;
                        for u1=1:u0-1
                            volH2O=volH2O+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                        end
                        volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-RatioH2O)*(MB(u0,1)-tR);
                        volH2O=volH2O/100;
                        volMeOH(1,1)=tR-volH2O;
                        RatioStrong=log10(volH2O/tR);
                    end
                end
                
                tR0=10^((RatioStrong-ShortBehavior(s,2))/ShortBehavior(s,1));
                
                solutionCount=solutionCount+1;
                solutionSet(solutionCount,1)=tR;
                solutionSet(solutionCount,3)=abs(tR-tR0);
                solutionSet(solutionCount,2)=RatioStrong;
            end
            for o=1:solutionCount
                if solutionSet(o,3)==min(solutionSet(:,3))
                    ShortBehavior(s,4)=solutionSet(o,1);
                end
            end
            clear solutionSet
        end
        
        
        nDSBehavior=1;
        SP=0;
        WidthCode=zeros(size(ShortBehavior,1),1);
        for z=1:size(ShortBehavior,1)
            if ShortBehavior(z,3)>=MiMLinearity-0.05 && SP==0
                DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                z1=z;
                SP=1;
                WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                BehaviorTimeInspect(nDSBehavior,1)=ShortBehavior(z,4);
            end
        end
        if size(ShortBehavior,1)>1
            for z=z1+1:size(ShortBehavior,1)
                if ShortBehavior(z,3)>=MiMLinearity-0.05
                    Rep=0;
                    for u=1:nDSBehavior
                        for v=1:3:WidthCode(u,1)-1
                            if abs(ShortBehavior(z,1)-DSBehavior(u,v))<SlopeDifferTolerance ...
                                    && abs(ShortBehavior(z,2)-DSBehavior(u,v+1))<IntersectDifferTolerance...
                                    && Rep==0
                                if max(BehaviorTimeInspect(nDSBehavior,:))<2*t0
                                    TimeDiffer=TimeDifferTor/2;
                                else
                                    TimeDiffer=TimeDifferTor;
                                end
                                
                                BehaviorTimeInspectTemp=BehaviorTimeInspect(u,:)';
                                BTT1=sortrows(BehaviorTimeInspectTemp,1);
                                for m=1:size(BTT1,1)
                                    if BTT1(m,1)~=0
                                        minTime=BTT1(m,1);
                                        break
                                    end
                                end
                                
                                if abs(ShortBehavior(z,4)-max(BehaviorTimeInspect(u,:)))<=TimeDiffer*2 ...
                                        && abs(ShortBehavior(z,4)-minTime)<=TimeDiffer*2
                                    DSBehavior(u,WidthCode(u,1)+1:WidthCode(u,1)+3)=ShortBehavior(z,1:3);
                                    WidthCode(u,1)=WidthCode(u,1)+3;
                                    Rep=1;
                                    BehaviorTimeInspect(u,WidthCode(u,1)/3)=ShortBehavior(z,4);
                                end
                            end
                        end
                    end
                    if Rep==0
                        nDSBehavior=nDSBehavior+1;
                        DSBehavior(nDSBehavior,1:3)=ShortBehavior(z,1:3);
                        WidthCode(nDSBehavior,1)=WidthCode(nDSBehavior,1)+3;
                        BehaviorTimeInspect(nDSBehavior,1)=ShortBehavior(z,4);
                    end
                end
            end
        end
        
        
        nDSBehavior_Extended=0;
        for p=1:nDSBehavior
            nBahavioredRetentionTime=zeros(ConNo,1);
            for v=1:3:size(DSBehavior,2)
                if DSBehavior(p,v)~=0
                    for q=1:size(GISumTemp2,1)
                        if GISumTemp2(q,4:6)==DSBehavior(p,v:v+2)
                            nBahavioredRetentionTime(GISumTemp2(q,1),1)=nBahavioredRetentionTime(GISumTemp2(q,1),1)+1;
                            BRT_temp(nBahavioredRetentionTime(GISumTemp2(q,1),1),GISumTemp2(q,1))=GISumTemp2(q,3);
                        end
                    end
                end
            end
            for de=1:size(BRT_temp,2)
                BRT_temp2=BRT_temp(:,de);
                BRT_temp3=unique(BRT_temp2,'rows');
                BRT_temp3=sortrows(BRT_temp3,-1);
                nBRT_Short3=1;
                BRT_Short3(nBRT_Short3,1)=BRT_temp3(nBRT_Short3,1);
                if size(BRT_temp3,1)>1
                    for u=2:size(BRT_temp3,1)
                        if BRT_Short3(nBRT_Short3,1)-BRT_temp3(u,1)>TimeDifferTor && BRT_temp3(u,1)>0
                            nBRT_Short3=nBRT_Short3+1;
                            BRT_Short3(nBRT_Short3,1)=BRT_temp3(u,1);
                        end
                    end
                end
                BRT(1:size(BRT_Short3,1),de)=BRT_Short3(1:size(BRT_Short3,1),1);
                clear BRT_temp2 BRT_temp3 BRT_Short3
            end
            SeeTime=0;
            for s=1:size(SlowestID,2)
                for k=1:size(BRT,2)
                    if k==SlowestID(1,s)
                        if BRT(1,k)>0 && SeeTime==0
                            SeeTime=1;
                            if k==SlowestID(1,1)
                                for z=1:size(BRT,1)
                                    if BRT(z,k)>0
                                        nDSBehavior_Extended=nDSBehavior_Extended+1;
                                        DSBehavior_Extended(nDSBehavior_Extended,1)=BRT(z,k);
                                        DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                        DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                    end
                                end
                            else
                                tR_Assume=0.1:0.1:100;
                                tR_Assume=tR_Assume';
                                solutionCount=0;
                                for o=1:size(tR_Assume,1)
                                    tR=tR_Assume(o,1);
                                    for ut=2:MBLength
                                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                                            RatioH2O=(tR-MB(ut-1,1))*((MB(ut,k+1)-MB(ut-1,k+1))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,k+1);
                                            u0=ut;
                                            volH2O=0;
                                            for u1=1:u0-1
                                                volH2O=volH2O+MB(u1+1,k+1)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,k+1)-MB(u1,k+1))*(MB(u1+1,1)-MB(u1,1))/2;
                                            end
                                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,k+1)+(MB(u0,k+1)-RatioH2O)*(MB(u0,1)-tR)/2;
                                            volH2O=volH2O/100;
                                            volMeOH(1,k)=tR-volH2O;
                                            RatioStrong=log10(volH2O/tR);
                                        end
                                    end
                                    tR0=10^((RatioStrong-DSBehavior(p,2))/DSBehavior(p,1));
                                    if abs(tR-tR0)<TimeDifferTor*4
                                        solutionCount=solutionCount+1;
                                        solutionSet(solutionCount,1)=tR;
                                        solutionSet(solutionCount,3)=abs(tR-tR0);
                                        solutionSet(solutionCount,2)=RatioStrong;
                                    end
                                end
                                if solutionCount>0
                                    for o=1:solutionCount
                                        if solutionSet(o,3)==min(solutionSet(:,3))
                                            nDSBehavior_Extended=nDSBehavior_Extended+1;
                                            DSBehavior_Extended(nDSBehavior_Extended,1)=solutionSet(o,1);
                                            DSBehavior_Extended(nDSBehavior_Extended,2)=SlowestID(1,s);
                                            DSBehavior_Extended(nDSBehavior_Extended,3:2+size(DSBehavior,2))=DSBehavior(p,1:size(DSBehavior,2));
                                        end
                                    end
                                end
                                clear solutionSet
                            end
                        end
                    end
                end
            end
            
            clear BRT clear BRT_temp
        end
        t01=cputime-t00;
        disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
        Error_Tor=0.05;
        DSBehavior_Extended=sortrows(DSBehavior_Extended,1);
        DSBehavior_Extended_Temp=DSBehavior_Extended;
        clear DSBehavior_Extended;
        nDSBehavior_Extended=1;
        DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
            DSBehavior_Extended_Temp(1,1:size(DSBehavior_Extended_Temp,2));
        nSlope_View1=0;
        for v=3:3:size(DSBehavior_Extended,2);
            if DSBehavior_Extended(nDSBehavior_Extended,v)~=0;
                nSlope_View1=nSlope_View1+1;
                Slope_View1(nSlope_View1,1:2)=DSBehavior_Extended(nDSBehavior_Extended,1:2);
                Slope_View1(nSlope_View1,3:5)=DSBehavior_Extended(nDSBehavior_Extended,v:v+2);
            end
        end
        Slope_View1=sortrows(Slope_View1,3);
        for z=2:size(DSBehavior_Extended_Temp,1)
            nSlope_View2=0;
            for v=3:3:size(DSBehavior_Extended_Temp,2);
                if DSBehavior_Extended_Temp(z,v)~=0;
                    nSlope_View2=nSlope_View2+1;
                    Slope_View2(nSlope_View2,1:2)=DSBehavior_Extended_Temp(z,1:2);
                    Slope_View2(nSlope_View2,3:5)=DSBehavior_Extended_Temp(z,v:v+2);
                end
            end
            Slope_View2=sortrows(Slope_View2,3);
            
            if max(Slope_View1(:,1))*(1+Error_Tor)>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor) && ...
                    min(Slope_View1(:,1))*(1+Error_Tor)+TimeDifferTor*4>=DSBehavior_Extended_Temp(z,1)*(1-Error_Tor)
                Slope_View=[Slope_View1;Slope_View2];
                Slope_View=sortrows(Slope_View,3);
                clear Slope_View1
                Slope_View1=Slope_View;
                nSlope_View1=size(Slope_View,1);
                clear Slope_View
                DSBehavior_Extended(nDSBehavior_Extended,1:2)=Slope_View1(1,1:2);
                
                for v=1:nSlope_View1
                    if v~=1
                        vot=0;
                        for o=3:3:size(DSBehavior_Extended,2)
                            if Slope_View1(v,3)==DSBehavior_Extended(nDSBehavior_Extended,o) && ...
                                    Slope_View1(v,4)==DSBehavior_Extended(nDSBehavior_Extended,o+1) && ...
                                    Slope_View1(v,5)==DSBehavior_Extended(nDSBehavior_Extended,o+2)
                                vot=1;
                            end
                        end
                        if vot==0
                            nRow=nRow+1;
                            DSBehavior_Extended(nDSBehavior_Extended,2+3*nRow-2:2+3*nRow)=Slope_View1(v,3:5);
                        end
                    else
                        DSBehavior_Extended(nDSBehavior_Extended,2+3*v-2:2+3*v)=Slope_View1(v,3:5);
                        nRow=v;
                    end
                end
            else
                nDSBehavior_Extended=nDSBehavior_Extended+1;
                DSBehavior_Extended(nDSBehavior_Extended,1:size(DSBehavior_Extended_Temp,2))=...
                    DSBehavior_Extended_Temp(z,1:size(DSBehavior_Extended_Temp,2));
                clear Slope_View1
                Slope_View1=Slope_View2;
                nSlope_View1=nSlope_View2;
            end
            clear Slope_View2
        end
        clear DSBehavior_Extended_Temp;
        IonNumber=zeros(nDSBehavior_Extended,1);
        if nDSBehavior_Extended>0
            for p=1:nDSBehavior_Extended
                for v=3:3:size(DSBehavior_Extended,2)
                    for q=1:size(GISumTemp2,1)
                        if (abs(DSBehavior_Extended(p,1)-GISumTemp2(q,3))<TimeDifferTor*8 && GISumTemp2(q,1)==SlowestID(1,1)) ||...
                                (GISumTemp2(q,1)~=SlowestID(1,1))
                            if GISumTemp2(q,4)==DSBehavior_Extended(p,v) && ...
                                    GISumTemp2(q,5)==DSBehavior_Extended(p,v+1) && ...
                                    GISumTemp2(q,6)==DSBehavior_Extended(p,v+2)
                                IonNumber(p,1)=IonNumber(p,1)+1;
                                IonSummary(IonNumber(p,1),1:size(GISumTemp2,2),p)=GISumTemp2(q,:);
                                IonSummary(IonNumber(p,1),1+size(GISumTemp2,2),p)=p;
                            end
                        end
                    end
                end
            end
            nIonSummaryShort=0;
            for p=1:nDSBehavior_Extended
                if IonSummary(1,1,p)>0
                    nIonSummaryShort=nIonSummaryShort+1;
                    IonSummaryShort(:,:,nIonSummaryShort)=IonSummary(:,:,p);
                end
            end
            clear IonSummary
            IonSummary=IonSummaryShort;
        end
        t01=cputime-t00;
        disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
        if sum(IonNumber(:,1))>0
            for z=1:nDSBehavior_Extended
                nIonDerep=1;
                IonSummaryDerepTemp(nIonDerep,:)=IonSummary(1,:,z);
                if size(IonSummary,1)>1
                    for u=2:size(IonSummary,1)
                        if IonSummary(u,7,z)>0
                            if abs(IonSummary(u,7,z)-IonSummaryDerepTemp(nIonDerep,7))<=MassDifferTor
                                if IonSummary(u,8,z)>IonSummaryDerepTemp(nIonDerep,8)
                                    IonSummaryDerepTemp(nIonDerep,:)=IonSummary(u,:,z);
                                end
                            else
                                nIonDerep=nIonDerep+1;
                                IonSummaryDerepTemp(nIonDerep,:)=IonSummary(u,:,z);
                            end
                        end
                    end
                end
                IonSummaryDerep(1:nIonDerep,1:9,z)=IonSummaryDerepTemp(1:nIonDerep,1:9);
                clear IonSummaryDerepTemp
            end
            clear IonNumber
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            nIonSummaryTS=1;
            IonSummaryTS(1:size(IonSummaryDerep,1),1,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,1);
            IonSummaryTS(1:size(IonSummaryDerep,1),2:8,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,1);
            if nDSBehavior_Extended>1
                for g=2:nDSBehavior_Extended
                    Tereplicate=0;
                    Replicate=0;
                    for h=1:nIonSummaryTS
                        if abs(IonSummaryTS(1,2,h)-IonSummaryDerep(1,3,g))<TimeDifferTor && IonSummaryTS(1,2,h)*IonSummaryDerep(1,3,g)~=0
                            Tereplicate=1;
                            Tereplicate_hit=0;
                            for u1=1:size(IonSummaryDerep,1)
                                if IonSummaryDerep(u1,7,g)~=0
                                    vot=0;
                                    for u2=1:size(IonSummaryTS,1)
                                        if abs(IonSummaryDerep(u1,7,g)-IonSummaryTS(u2,6,h))<MassDifferTor
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        Tereplicate_hit=1;
                                    end
                                end
                            end
                            Tereplicate_hot=0;
                            for u1=1:size(IonSummaryTS,1)
                                if IonSummaryDerep(u2,7,g)~=0
                                    vot=0;
                                    for u2=1:size(IonSummaryDerep,1)
                                        if abs(IonSummaryDerep(u2,7,g)-IonSummaryTS(u1,6,h))<MassDifferTor
                                            vot=1;
                                        end
                                    end
                                    if vot==0
                                        Tereplicate_hot=1;
                                    end
                                end
                            end
                            if Tereplicate_hit==0
                                Replicate=1;
                                if Tereplicate_hot==1
                                    Replicate=2;
                                    h_Code=h;
                                end
                            end
                        end
                    end
                    if Tereplicate==1
                        if Replicate==0
                            nIonSummaryTS=nIonSummaryTS+1;
                            IonSummaryTS(1:size(IonSummaryDerep,1),1,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,g);
                            IonSummaryTS(1:size(IonSummaryDerep,1),2:8,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,g);
                        else if Replicate==2
                                IonSummaryTS(1:size(IonSummaryDerep,1),1,h_Code)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,g);
                                IonSummaryTS(1:size(IonSummaryDerep,1),2:8,h_Code)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,g);
                            end
                        end
                    end
                    
                    if Tereplicate==0
                        nIonSummaryTS=nIonSummaryTS+1;
                        IonSummaryTS(1:size(IonSummaryDerep,1),1,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),1,g);
                        IonSummaryTS(1:size(IonSummaryDerep,1),2:8,nIonSummaryTS)=IonSummaryDerep(1:size(IonSummaryDerep,1),3:9,g);
                    end
                    
                end
            end
            for rID=1:size(IonSummaryTS,3)
                TimeTableTemp(rID,1)=IonSummaryTS(1,2,rID);
                TimeTableTemp(rID,2)=0;
            end
            TimeTableTemp=sortrows(TimeTableTemp,1);
            for TTT=1:size(IonSummaryTS,3)
                for rID=1:size(IonSummaryTS,3)
                    if TimeTableTemp(TTT,1)==IonSummaryTS(1,2,rID) && rID~=TimeTableTemp(TTT,2)
                        IonSummaryTS2(:,:,TTT)=IonSummaryTS(:,:,rID);
                        TimeTableTemp(TTT,2)=rID;
                    end
                end
            end
            clear IonSummaryTS
            IonSummaryTS=IonSummaryTS2;
            clear IonSummaryTS2 TimeTableTemp
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            for rID=1:size(IonSummaryTS,3)
                ConID=IonSummaryTS(1,1,rID);
                for iFile=1:nOfFiles
                    if (strcmp(files(iFile).name(1:4),'DENO'))
                        MaSuDN(1,1)=0;
                        if SamID<10 && ConID<10
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12))==ConID...
                                    && strcmp(files(iFile).name(13),'P')
                                MaSuDN(1,1)=1;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID<10
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13))==ConID...
                                    && strcmp(files(iFile).name(14),'P')
                                MaSuDN(1,1)=2;
                            end
                        end
                        if SamID>=100 && ConID<10
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=3;
                            end
                        end
                        if SamID<10 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:13))==ConID...
                                    && strcmp(files(iFile).name(14),'P')
                                MaSuDN(1,1)=4;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=5;
                            end
                        end
                        if SamID>=100 && ConID>=10 && ConID<100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:15))==ConID...
                                    && strcmp(files(iFile).name(16),'P')
                                MaSuDN(1,1)=6;
                            end
                        end
                        if SamID<10 && ConID>=100
                            if str2double(files(iFile).name(8))==SamID && str2double(files(iFile).name(12:14))==ConID...
                                    && strcmp(files(iFile).name(15),'P')
                                MaSuDN(1,1)=7;
                            end
                        end
                        if SamID>=10 && SamID<100 && ConID>=100
                            if str2double(files(iFile).name(8:9))==SamID && str2double(files(iFile).name(13:15))==ConID...
                                    && strcmp(files(iFile).name(16),'P')
                                MaSuDN(1,1)=8;
                            end
                        end
                        if SamID>=100 && ConID>=100
                            if str2double(files(iFile).name(8:10))==SamID && str2double(files(iFile).name(14:16))==ConID...
                                    && strcmp(files(iFile).name(17),'P')
                                MaSuDN(1,1)=9;
                            end
                        end
                        if MaSuDN(1,1)>0
                            IntSumTemp=load(files(iFile).name);
                            for r=1:size(IonSummaryTS,1)
                                OiO=0;
                                for w=1:size(IntSumTemp,1)
                                    if abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1))<MassDifferTor
                                        if OiO==0
                                            IonSummaryTS(r,9,rID)=IntSumTemp(w,12);
                                            TDSet=abs(IonSummaryTS(r,2,rID)-IntSumTemp(w,2));
                                            MDSet=abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1));
                                            IntSet=IntSumTemp(w,11);
                                            OiO=1;
                                            if IntSet>IonSummaryTS(r,7,rID)
                                                IonSummaryTS(r,7,rID)=IntSet;
                                            end
                                        else
                                            if abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1))<MDSet
                                                if IonSummaryTS(r,7,rID)>IntSet
                                                    TDSet=abs(IonSummaryTS(r,2,rID)-IntSumTemp(w,2));
                                                    MDSet=abs(IonSummaryTS(r,6,rID)-IntSumTemp(w,1));
                                                    IntSet=IntSumTemp(w,11);
                                                    IonSummaryTS(r,7,rID)=IntSet;
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            nIsoSummary=0;
            for rID=1:size(IonSummaryTS,3)
                nIsoSummary=nIsoSummary+1;
                
                IonSummaryTemp=IonSummaryTS(:,:,rID);
                IonSummaryTemp=sortrows(IonSummaryTemp,-7);
                
                IsoSummary(nIsoSummary,1:3)=DSBehavior_Extended(IonSummaryTemp(1,8),3:5);
                
                tR_Assume=0.1:0.1:100;
                tR_Assume=tR_Assume';
                solutionCount=0;
                for o=1:size(tR_Assume,1)
                    tR=tR_Assume(o,1);
                    for ut=2:MBLength
                        if tR>MB(ut-1,1) && tR<MB(ut,1)
                            RatioH2O=(tR-MB(ut-1,1))*((MB(ut,2)-MB(ut-1,2))/(MB(ut,1)-MB(ut-1,1)))+MB(ut-1,2);
                            u0=ut;
                            volH2O=0;
                            for u1=1:u0-1
                                volH2O=volH2O+MB(u1+1,2)*(MB(u1+1,1)-MB(u1,1))-(MB(u1+1,2)-MB(u1,2))*(MB(u1+1,1)-MB(u1,1));
                            end
                            volH2O=volH2O-(MB(u0,1)-tR)*MB(u0,2)+(MB(u0,2)-RatioH2O)*(MB(u0,1)-tR);
                            volH2O=volH2O/100;
                            volMeOH(1,1)=tR-volH2O;
                            RatioStrong=log10(volH2O/tR);
                        end
                    end
                    
                    tR0=10^((RatioStrong-IsoSummary(nIsoSummary,2))/IsoSummary(nIsoSummary,1));
                    solutionCount=solutionCount+1;
                    solutionSet(solutionCount,1)=tR;
                    solutionSet(solutionCount,3)=abs(tR-tR0);
                    solutionSet(solutionCount,2)=RatioStrong;
                end
                if solutionCount>0
                    for o=1:solutionCount
                        if solutionSet(o,3)==min(solutionSet(:,3))
                            IsoSummary(nIsoSummary,4)=solutionSet(o,1);
                        end
                    end
                end
                clear solutionSet
                IsoSummary(nIsoSummary,5)=0;
                IntThreshold=0.8;
                nIon=0;
                for z=1:size(IonSummaryTemp,1)
                    if IonSummaryTemp(z,7)/max(IonSummaryTemp(:,7))>=IntThreshold
                        IsoSummary(nIsoSummary,5)=IsoSummary(nIsoSummary,5)+IonSummaryTemp(z,7);
                        nIon=nIon+1;
                    end
                end
                IsoSummary(nIsoSummary,5)=IsoSummary(nIsoSummary,5)/nIon;
                IsoSummary(nIsoSummary,6)=IonSummaryTemp(1,9);
                nCount=1;
                nCountRem=0;
                IsoSummary(nIsoSummary,6+nCount)=IonSummaryTemp(1,6);
                if size(IonSummaryTS,1)>1
                    for u=2:size(IonSummaryTS,1)
                        if IonSummaryTemp(u,9)>0
                            if abs(IonSummaryTemp(u,9)-IsoSummary(nIsoSummary,6))<0.2
                                vot=0;
                                for z=1:nCount
                                    if abs(IonSummaryTemp(u,6)-IsoSummary(nIsoSummary,6+z))<IMI
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    nCount=nCount+1;
                                    IsoSummary(nIsoSummary,6+nCount)=IonSummaryTemp(u,6);
                                end
                            else if IonSummaryTemp(u,9)>0
                                    nCountRem=nCountRem+1;
                                    IsoTempRem(nCountRem,:)=IonSummaryTemp(u,:);
                                end
                            end
                        end
                    end
                    if nCountRem>0
                        nIsoSummary=nIsoSummary+1;
                        IsoSummary(nIsoSummary,6)=IsoTempRem(1,9);
                        nCountRemPlus=1;
                        IsoSummary(nIsoSummary,6+nCountRemPlus)=IsoTempRem(1,6);
                        for u=1:nCountRem
                            vot=0;
                            for z=1:nCountRemPlus
                                if abs(IsoTempRem(u,6)-IsoSummary(nIsoSummary,6+z))<IMI
                                    vot=1;
                                end
                            end
                            if vot==0
                                nCountRemPlus=nCountRemPlus+1;
                                IsoSummary(nIsoSummary,6+nCountRemPlus)=IsoTempRem(u,6);
                            end
                        end
                        clear IsoTempRem
                    end
                end
                clear IonSummaryTemp
            end
            
            MostAbundantIon=max(IsoSummary(:,5));
            IsoSummary(:,5)=IsoSummary(:,5)./MostAbundantIon;
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            nMassList=0;
            for u=1:size(IsoSummary,1)
                for v=7:size(IsoSummary,2)
                    if IsoSummary(u,v)>0
                        nMassList=nMassList+1;
                        MassList(nMassList,1)=IsoSummary(u,v);
                        MassList(nMassList,3)=IsoSummary(u,6);
                        if IsoSummary(u,4)>0
                            MassList(nMassList,2)=IsoSummary(u,4);
                        else
                            MassList(nMassList,2)=IsoSummary(u-1,4);
                        end
                    end
                end
            end
            
            for iUV=1:nOfFiles
                MaSuUV(1,1)=0;
                if (strcmp(files(iUV).name(1:3),'Sam'))
                    if SamID<10
                        if str2double(files(iUV).name(4))==SamID && str2double(files(iUV).name(8))==SlowestID(1,1) && ...
                                strcmp(files(iUV).name(9),'.')
                            MaSuUV(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100
                        if str2double(files(iUV).name(4:5))==SamID && str2double(files(iUV).name(9))==SlowestID(1,1) && ...
                                strcmp(files(iUV).name(10),'.')
                            MaSuUV(1,1)=2;
                        end
                    end
                    if SamID>=100
                        if str2double(files(iUV).name(4:6))==SamID && str2double(files(iUV).name(10))==SlowestID(1,1) && ...
                                strcmp(files(iUV).name(11),'.')
                            MaSuUV(1,1)=3;
                        end
                    end
                    if MaSuUV(1,1)>0
                        UVTemp=load(files(iUV).name);
                        TIRA=UVTemp(size(UVTemp,1),1);
                    end
                end
            end
            for iMat=1:nOfMats
                if strcmp( Mats(iMat).name(1:3),'Sam')
                    nEInforSummaryGS=0;
                    MaSuMa(1,1)=0;
                    if SamID<10 && ConID<10
                        if str2double(Mats(iMat).name(4))==SamID && str2double(Mats(iMat).name(8))==SlowestID(1,1)...
                                && (strcmp(Mats(iMat).name(9),'P'))...
                                && strcmp(Mats(iMat).name(10),'.')
                            MaSuMa(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(Mats(iMat).name(4:5))==SamID && str2double(Mats(iMat).name(9))==SlowestID(1,1)...
                                && (strcmp(Mats(iMat).name(10),'P'))...
                                && strcmp(Mats(iMat).name(11),'.')
                            MaSuMa(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(Mats(iMat).name(4:6))==SamID && str2double(Mats(iMat).name(10))==SlowestID(1,1)...
                                && (strcmp(Mats(iMat).name(11),'P'))...
                                && strcmp(Mats(iMat).name(12),'.')
                            MaSuMa(1,1)=3;
                        end
                    end
                    if MaSuMa(1,1)>0
                        data = load(Mats(iMat).name);
                        Scans=data.Scans;
                        dataWidth=size(Scans,2);
                        MergeMass=data.Masses;
                        dataLength=size(MergeMass,1);
                        MergeData=data.Data;
                        FH=round(TIRA*2.5*log10(dataWidth));
                        ATH=dataWidth;
                        Ratio=round(ATH/FH);
                        if Ratio>=1
                            iCol=0;
                            for k=1:Ratio:ATH-Ratio
                                iCol=iCol+1;
                                dataTemp(1:dataLength,1:Ratio)=MergeData(1:dataLength,k:k+Ratio-1);
                                for o=1:dataLength
                                    Data_New(o,iCol)=sum(dataTemp(o,1:Ratio));
                                end
                                MergeTime(1,iCol)=0.5*(Scans(1,k)+Scans(1,k+Ratio-1))/Scans(1,dataWidth)*TIRA;
                            end
                        else
                            Ratio2=round(FH/ATH);
                            iCol=Ratio2*ATH;
                            for o=1:dataWidth
                                MergeTime(1,o*Ratio2-Ratio2+1:o*Ratio2)=Scans(1,o)/Scans(1,dataWidth)*TIRA;
                                for k=1:dataLength
                                    Data_New(k,o*Ratio2-Ratio2+1:o*Ratio2)=MergeData(k,o);
                                end
                            end
                        end
                        dataWidth=iCol;
                        XIC=zeros(dataWidth,2);
                        nEInforSummaryGS=0;
                        fr = FH/16;
                        dt = (16/FH)^2;
                        rick = ricker(FH,fr,dt,20);
                        rick_smooth = getSmoothRicker(rick);
                        for r=1:nMassList
                            for h=MassRange+1:dataLength-MassRange
                                if abs(MergeMass(h,1)-MassList(r,1))<MassDifferTor
                                    for j=1:dataWidth
                                        XIC(j,1)=MergeTime(1,j);
                                        XIC(j,2)=sum(Data_New(h-MassRange:h+MassRange,j));
                                    end
                                    smoothXIC0  = conv( rick_smooth(:,1),XIC(:,2) );
                                    smoothXIC(:,1)=XIC(:,1);
                                    smoothXIC(:,2)=smoothXIC0( round(length(rick_smooth)/2)+1:length(XIC(:,2))+round(length(rick_smooth)/2));
                                    smoothXICLength=size(smoothXIC,1);
                                    EThreshold=0.01;
                                    EPointGSNo=0;
                                    HighPoint=max(smoothXIC(:,2));
                                    for i=2:smoothXICLength-1
                                        if smoothXIC(i,2)>=smoothXIC(i-1,2) && smoothXIC(i,2)>=smoothXIC(i+1,2) && smoothXIC(i,2)> HighPoint*EThreshold && (smoothXIC(i,2)-smoothXIC(i-1,2))+(smoothXIC(i,2)-smoothXIC(i+1,2))~=0
                                            EPointGSNo=EPointGSNo+1;
                                            EPointGS(EPointGSNo,1) = smoothXIC(i,1);
                                            EPointGS(EPointGSNo,2) = smoothXIC(i,2);
                                        end;
                                    end;
                                    BaseLineTolerance=0.01;
                                    nEInfor=0;
                                    if EPointGSNo>0
                                        for m=1:EPointGSNo
                                            ETime=EPointGS(m,1);
                                            EHight=EPointGS(m,2);
                                            EPosition(1,1)=EPointGS(m,1);
                                            EPosition(1,2)=EPointGS(m,2);
                                            halfPH=EHight/2;
                                            
                                            for z=1:smoothXICLength
                                                if smoothXIC(z,1)==ETime
                                                    PP=z;
                                                end;
                                            end;
                                            
                                            vbv1=0;
                                            for z=PP:-1:2
                                                if smoothXIC(z,2)>=0 && smoothXIC(z-1,2)<=0 && vbv1==0
                                                    CrossZeroLeft=smoothXIC(z,1);
                                                    LeftIndex=z;
                                                    vbv1=1;
                                                end;
                                            end;
                                            
                                            if vbv1==0
                                                CrossZeroLeft=0;
                                                LeftIndex=1;
                                            end;
                                            
                                            vbv2=0;
                                            for z=PP:smoothXICLength-1
                                                if smoothXIC(z,2)>=0 && smoothXIC(z+1,2)<=0 && vbv2==0
                                                    CrossZeroRight=smoothXIC(z,1);
                                                    RightIndex=z;
                                                    vbv2=1;
                                                end;
                                            end;
                                            
                                            if vbv2==0
                                                CrossZeroRight=smoothXIC(smoothXICLength,1);
                                                RightIndex=smoothXICLength;
                                            end;
                                            
                                            EPointGS(m,3)=CrossZeroLeft;
                                            EPointGS(m,4)=CrossZeroRight;
                                            EPointGS(m,5)=(CrossZeroRight-CrossZeroLeft)/TIRA;
                                            EPointGS(m,6)=EHight/HighPoint;
                                            EPointGS(m,7)=EPointGS(m,6)/EPointGS(m,5);
                                            
                                            
                                            if LeftIndex>1 && RightIndex<smoothXICLength
                                                EPointGS(m,8)=0;
                                                for z=LeftIndex:RightIndex
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            if LeftIndex==1 && RightIndex<smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                for z=2:RightIndex
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            if LeftIndex>1 && RightIndex==smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                for z=LeftIndex:RightIndex-1
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                            
                                            if LeftIndex==1 && RightIndex==smoothXICLength
                                                EPointGS(m,8)=(smoothXIC(smoothXICLength,1)-smoothXIC(smoothXICLength-1,1))/2*smoothXIC(smoothXICLength,2);
                                                EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(2,1)-smoothXIC(1,1))/2*smoothXIC(1,2);
                                                for z=2:smoothXICLength-1
                                                    EPointGS(m,8)=EPointGS(m,8)+(smoothXIC(z+1,1)-smoothXIC(z-1,1))/2*smoothXIC(z,2);
                                                end
                                            end
                                        end;
                                        
                                        EPointGSShort(1,:)=EPointGS(1,:);
                                        nPPShort=1;
                                        for z=1:EPointGSNo
                                            if EPointGS(z,1)-EPointGSShort(nPPShort,1)<TimeDifferTor
                                                if EPointGS(z,2)>EPointGSShort(nPPShort,2)
                                                    EPointGSShort(nPPShort,1)=EPointGS(z,1);
                                                    EPointGSShort(nPPShort,2)=EPointGS(z,2);
                                                end;
                                                if EPointGS(z,3)>EPointGSShort(nPPShort,3)
                                                    EPointGSShort(nPPShort,3)=EPointGS(z,3);
                                                end;
                                                if EPointGS(z,4)<EPointGSShort(nPPShort,4)
                                                    EPointGSShort(nPPShort,4)=EPointGS(z,4);
                                                end;
                                                EPointGSShort(nPPShort,5)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))/TIRA;
                                                EPointGSShort(nPPShort,6)=EPointGSShort(nPPShort,2)/HighPoint;
                                                EPointGSShort(nPPShort,7)=EPointGSShort(nPPShort,6)/EPointGSShort(nPPShort,5);
                                                EPointGSShort(nPPShort,8)=(EPointGSShort(nPPShort,4)-EPointGSShort(nPPShort,3))*EPointGSShort(nPPShort,2)/2;
                                            else
                                                nPPShort=nPPShort+1;
                                                EPointGSShort(nPPShort,:)=EPointGS(z,:);
                                            end;
                                        end;
                                        
                                        LargestE=max(EPointGSShort(:,8));
                                        
                                        EPointGSShort(:,9)=EPointGSShort(:,8)/LargestE;
                                        
                                        
                                        
                                        if nPPShort>0
                                            for s=1:nPPShort
                                                if abs(EPointGSShort(s,1)-MassList(r,2))<TimeDifferTor*4 && EPointGSShort(s,9)>RelArea
                                                    if size(MassList,2)==3 || MassList(r,3)==0
                                                        MassList(r,4)=EPointGSShort(s,1);
                                                        MassList(r,5)=EPointGSShort(s,8);
                                                        MassList(r,6)=MergeMass(h,1);
                                                        
                                                    else
                                                        if abs(MassList(r,3)-MassList(r,2))>TimeDifferTor*2
                                                            if abs(EPointGSShort(s,1)-MassList(r,2))<abs(MassList(r,3)-MassList(r,2))
                                                                MassList(r,4)=EPointGSShort(s,1);
                                                                MassList(r,5)=EPointGSShort(s,8);
                                                                MassList(r,6)=MergeMass(h,1);
                                                            end
                                                        else
                                                            if MassList(r,4)<EPointGSShort(s,8)
                                                                MassList(r,4)=EPointGSShort(s,1);
                                                                MassList(r,5)=EPointGSShort(s,8);
                                                                MassList(r,6)=MergeMass(h,1);
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                            
                                            
                                            clear EPointGS LeftPoint RightPoint EPointGSShort ...
                                                width EPosition;
                                            
                                        end
                                        
                                        
                                    end
                                    
                                    clear XIC smoothXIC section;
                                end
                            end
                        end
                    end
                end
            end
            
            MassList=sortrows(MassList,4);
            
            
            nCRAD_Es=0;
            nr=0;
            nredIsomer=0;
            for z=1:size(MassList,1)
                if MassList(z,4)>0
                    
                    nCRAD_Es=nCRAD_Es+1;
                    CRAD_Es(nCRAD_Es,1)=MassList(z,6);
                    CRAD_Es(nCRAD_Es,2)=MassList(z,4);
                    CRAD_Es(nCRAD_Es,3)=MassList(z,5);
                    CRAD_Es(nCRAD_Es,4)=MassList(z,3);
                    
                    if nredIsomer==0
                        nredIsomer=nredIsomer+1;
                        redIsomers(nredIsomer,:)=MassList(z,:);
                    else
                        if redIsomers(nredIsomer,2)==MassList(z,2) &&...
                                MassList(z,4)-redIsomers(nredIsomer,4)<=TimeDifferTor
                            nredIsomer=nredIsomer+1;
                            redIsomers(nredIsomer,:)=MassList(z,:);
                        else
                            redIsomers_short=unique(redIsomers,'rows');
                            clear redIsomers
                            redIsomers=redIsomers_short;
                            redIsomers=sortrows(redIsomers,3);
                            nredIsomer=size(redIsomers,1);
                            nr=nr+1;
                            if nredIsomer>1
                                o=nredIsomer;
                                for k=1:nredIsomer-1
                                    if redIsomers(k,3)~=redIsomers(k+1,3)
                                        o=k;
                                    end
                                end
                                if o<nredIsomer
                                    redIsomers1=redIsomers(1:o,1:6);
                                    redIsomers1=sortrows(redIsomers1,-5);
                                    IsoSummary2(nr,6,1)=redIsomers1(1,3);
                                    IsoSummary2(nr,4,1)=redIsomers1(1,4);
                                    IsoSummary2(nr,5,1)=0;
                                    for p=1:o
                                        if size(IsoSummary2,2)>6
                                            vot=0;
                                            for v=7:size(IsoSummary2,2)
                                                if IsoSummary2(nr,v,1)==redIsomers1(p,6)
                                                    vot=1;
                                                end
                                            end
                                            if vot==0
                                                IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                                if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                                end
                                            end
                                        else
                                            IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                            if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                                IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                            end
                                        end
                                    end
                                    
                                    redIsomers2=redIsomers(o+1:nredIsomer,1:6);
                                    redIsomers2=sortrows(redIsomers2,-5);
                                    IsoSummary2(nr,6,2)=redIsomers2(1,3);
                                    IsoSummary2(nr,5,2)=0;
                                    for p=1:nredIsomer-o
                                        if size(IsoSummary2,2)>6
                                            vot=0;
                                            for v=7:size(IsoSummary2,2)
                                                if IsoSummary2(nr,v,2)==redIsomers2(p,6)
                                                    vot=1;
                                                end
                                            end
                                            if vot==0
                                                IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                                if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                                    IsoSummary2(nr,5,2)=IsoSummary2(nr,5,1)+redIsomers2(p,5);
                                                end
                                            end
                                        else
                                            IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                            if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                                IsoSummary2(nr,5,2)=IsoSummary2(nr,5,2)+redIsomers2(p,5);
                                            end
                                        end
                                    end
                                    
                                    clear redIsomers1 redIsomers2
                                else
                                    redIsomers=sortrows(redIsomers,-5);
                                    IsoSummary2(nr,6,1)=redIsomers(1,3);
                                    IsoSummary2(nr,4,1)=redIsomers(1,4);
                                    IsoSummary2(nr,5,1)=0;
                                    for p=1:o
                                        if size(IsoSummary2,2)>6
                                            vot=0;
                                            for v=7:size(IsoSummary2,2)
                                                if IsoSummary2(nr,v,1)==redIsomers(p,6)
                                                    vot=1;
                                                end
                                            end
                                            if vot==0
                                                IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                                if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                                end
                                            end
                                        else
                                            IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                            if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                                IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                            end
                                        end
                                    end
                                end
                                
                            else
                                IsoSummary2(nr,7,1)=redIsomers(nredIsomer,6);
                                IsoSummary2(nr,6,1)=redIsomers(nredIsomer,3);
                                IsoSummary2(nr,5,1)=redIsomers(nredIsomer,5);
                                IsoSummary2(nr,4,1)=redIsomers(nredIsomer,4);
                            end
                            clear redIsomers
                            nredIsomer=1;
                            redIsomers(nredIsomer,:)=MassList(z,:);
                        end
                    end
                end
            end
            
            if nredIsomer>0
                redIsomers_short=unique(redIsomers,'rows');
                clear redIsomers
                redIsomers=redIsomers_short;
                redIsomers=sortrows(redIsomers,3);
                nredIsomer=size(redIsomers,1);
                nr=nr+1;
                if nredIsomer>1
                    o=nredIsomer;
                    for k=1:nredIsomer-1
                        if redIsomers(k,3)~=redIsomers(k+1,3)
                            o=k;
                        end
                    end
                    if o<nredIsomer
                        redIsomers1=redIsomers(1:o,1:6);
                        redIsomers1=sortrows(redIsomers1,-5);
                        IsoSummary2(nr,6,1)=redIsomers1(1,3);
                        IsoSummary2(nr,4,1)=redIsomers1(1,4);
                        IsoSummary2(nr,5,1)=0;
                        for p=1:o
                            if size(IsoSummary2,2)>6
                                vot=0;
                                for v=7:size(IsoSummary2,2)
                                    if IsoSummary2(nr,v,1)==redIsomers1(p,6)
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                    if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                        IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                    end
                                end
                            else
                                IsoSummary2(nr,6+p,1)=redIsomers1(p,6);
                                if redIsomers1(p,5)>max(redIsomers1(:,5))*0.8
                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers1(p,5);
                                end
                            end
                        end
                        
                        redIsomers2=redIsomers(o+1:nredIsomer,1:6);
                        redIsomers2=sortrows(redIsomers2,-5);
                        IsoSummary2(nr,6,2)=redIsomers2(1,3);
                        IsoSummary2(nr,5,2)=0;
                        for p=1:nredIsomer-o
                            if size(IsoSummary2,2)>6
                                vot=0;
                                for v=7:size(IsoSummary2,2)
                                    if IsoSummary2(nr,v,2)==redIsomers2(p,6)
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                    if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                        IsoSummary2(nr,5,2)=IsoSummary2(nr,5,1)+redIsomers2(p,5);
                                    end
                                end
                            else
                                IsoSummary2(nr,6+p,2)=redIsomers2(p,6);
                                if redIsomers2(p,5)>max(redIsomers2(:,5))*0.8
                                    IsoSummary2(nr,5,2)=IsoSummary2(nr,5,2)+redIsomers2(p,5);
                                end
                            end
                        end
                        
                        clear redIsomers1 redIsomers2
                    else
                        redIsomers=sortrows(redIsomers,-5);
                        IsoSummary2(nr,6,1)=redIsomers(1,3);
                        IsoSummary2(nr,4,1)=redIsomers(1,4);
                        IsoSummary2(nr,5,1)=0;
                        for p=1:o
                            if size(IsoSummary2,2)>6
                                vot=0;
                                for v=7:size(IsoSummary2,2)
                                    if IsoSummary2(nr,v,1)==redIsomers(p,6)
                                        vot=1;
                                    end
                                end
                                if vot==0
                                    IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                    if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                        IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                    end
                                end
                            else
                                IsoSummary2(nr,6+p,1)=redIsomers(p,6);
                                if redIsomers(p,5)>max(redIsomers(:,5))*0.8
                                    IsoSummary2(nr,5,1)=IsoSummary2(nr,5,1)+redIsomers(p,5);
                                end
                            end
                        end
                    end
                    
                else
                    IsoSummary2(nr,7,1)=redIsomers(nredIsomer,6);
                    IsoSummary2(nr,6,1)=redIsomers(nredIsomer,3);
                    IsoSummary2(nr,5,1)=redIsomers(nredIsomer,5);
                    IsoSummary2(nr,4,1)=redIsomers(nredIsomer,4);
                end
                clear redIsomers
            end
            
            nIsoSummary3=0;
            if nr>0
                for z=1:nr
                    nIsoSummary3=nIsoSummary3+1;
                    IsoSummary3(nIsoSummary3,1:size(IsoSummary2,2))=IsoSummary2(z,:,1);
                    if IsoSummary2(z,7,2)>0
                        nIsoSummary3=nIsoSummary3+1;
                        IsoSummary3(nIsoSummary3,1:size(IsoSummary2,2))=IsoSummary2(z,:,2);
                    end
                end
            end
            
            for iMat=1:nOfMats
                MaSuTN(1,1)=0;
                if (strcmp(Mats(iMat).name(1:4),'TDAN'))
                    if SamID<10
                        if str2double(Mats(iMat).name(8))==SamID && strcmp(Mats(iMat).name(9),'P')
                            MaSuTN(1,1)=1;
                        end
                    end
                    if SamID>=10 && SamID<100 && ConID<10
                        if str2double(Mats(iMat).name(8:9))==SamID && strcmp(Mats(iMat).name(10),'P')
                            MaSuTN(1,1)=2;
                        end
                    end
                    if SamID>=100 && ConID<10
                        if str2double(Mats(iMat).name(8:10))==SamID && strcmp(Mats(iMat).name(11),'P')
                            MaSuTN(1,1)=3;
                        end
                    end
                    if MaSuTN(1,1)>0
                        data = load(Mats(iMat).name);
                        TDAN=data.TapdancerBYAbun;
                    end
                end
            end
            
            for z=1:size(IsoSummary3,1)
                if z==1
                    MassTime1(1,1)=IsoSummary3(z,7);
                    MassTime1(1,2)=IsoSummary3(z,4);
                    SlopeLine=1;
                    if IsoSummary3(z+1,4)==0
                        No1=0;
                        for v=7:size(IsoSummary3,2)
                            if IsoSummary3(z,v)>0
                                No1=No1+1;
                            end
                        end
                        No2=0;
                        for v=7:size(IsoSummary3,2)
                            if IsoSummary3(z+1,v)>0
                                No2=No2+1;
                            end
                        end
                        if No2>No1
                            MassTime1(1,1)=IsoSummary3(z+1,7);
                        end
                        if No2==No1 && IsoSummary3(z+1,5)>IsoSummary3(z,5)
                            MassTime1(1,1)=IsoSummary3(z+1,7);
                        end
                    end
                end
                if z>1 && z<size(IsoSummary3,1) && IsoSummary3(z,4)~=0
                    MassTime1(1,1)=IsoSummary3(z,7);
                    MassTime1(1,2)=IsoSummary3(z,4);
                    SlopeLine=z;
                    if IsoSummary3(z+1,4)==0
                        if IsoSummary3(z+1,4)==0
                            No1=0;
                            for v=7:size(IsoSummary3,2)
                                if IsoSummary3(z,v)>0
                                    No1=No1+1;
                                end
                            end
                            No2=0;
                            for v=7:size(IsoSummary3,2)
                                if IsoSummary3(z+1,v)>0
                                    No2=No2+1;
                                end
                            end
                            if No2>No1
                                MassTime1(1,1)=IsoSummary3(z+1,7);
                            end
                            if No2==No1 && IsoSummary3(z+1,5)>IsoSummary3(z,5)
                                MassTime1(1,1)=IsoSummary3(z+1,7);
                            end
                        end
                    end
                end
                if z==size(IsoSummary3,1)
                    if IsoSummary3(z,4)~=0
                        SlopeLine=z;
                        MassTime1(1,1)=IsoSummary3(z,7);
                        MassTime1(1,2)=IsoSummary3(z,4);
                    end
                end
                
                nMatch=0;
                for v=1:size(TDAN,3)
                    MatchTime=0;
                    for w=1:4:size(TDAN,2)
                        for u=1:size(TDAN,1)
                            if abs(MassTime1(1,2)-TDAN(u,w+1,v))>TimeDifferTor*2 && TDAN(u,w+1,v)~=0 ...
                                    && w==1
                                MatchTime=MatchTime-0.25;
                            end
                            if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDifferTor*2
                                if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDifferTor*2 && w==1
                                    MatchTime=MatchTime+1;
                                end
                                if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                    MatchTime=MatchTime+0.25;
                                end
                            end
                        end
                    end
                    if MatchTime>0
                        nMatch=nMatch+1;
                        MatchMatrix(nMatch,1)=MatchTime;
                        MatchMatrix(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                        MatchMatrix(nMatch,5)=v;
                    end
                end
                if nMatch>0
                    nMatchShort=0;
                    for u=1:nMatch
                        if MatchMatrix(u,1)==max(MatchMatrix(:,1))
                            nMatchShort=nMatchShort+1;
                            MatchMatrixShort(nMatchShort,:)=MatchMatrix(u,:);
                        end
                    end
                    
                    MatchMatrixShort=sortrows(MatchMatrixShort,2);
                    IsoSummary3(SlopeLine,1:3)=MatchMatrixShort(1,2:4);
                    clear MatchMatrix MatchMatrixShort
                else
                    for v=1:size(TDAN,3)
                        MatchTime=0;
                        for w=1:4:size(TDAN,2)
                            for u=1:size(TDAN,1)
                                if abs(MassTime1(1,1)-TDAN(u,w,v))<MassDifferTor
                                    if abs(MassTime1(1,2)-TDAN(u,w+1,v))<TimeDifferTor*8 && w==1
                                        MatchTime=MatchTime+1;
                                    end
                                    if MassTime1(1,2)>TDAN(u,w+1,v) && w>1
                                        MatchTime=MatchTime+0.25;
                                    end
                                end
                            end
                        end
                        
                        if MatchTime>0
                            nMatch=nMatch+1;
                            MatchMatrix(nMatch,1)=MatchTime;
                            MatchMatrix(nMatch,2:4)=TDAN(1,size(TDAN,2)-2:size(TDAN,2),v);
                            MatchMatrix(nMatch,5)=v;
                        end
                    end
                    if nMatch>0
                        nMatchShort=0;
                        for u=1:nMatch
                            if MatchMatrix(u,1)==max(MatchMatrix(:,1))
                                nMatchShort=nMatchShort+1;
                                MatchMatrixShort(nMatchShort,:)=MatchMatrix(u,:);
                            end
                        end
                        MatchMatrixShort=sortrows(MatchMatrixShort,2);
                        IsoSummary3(SlopeLine,1:2)=MatchMatrixShort(1,2:3);
                        clear MatchMatrix MatchMatrixShort
                    end
                end
            end
            
            nIsoSummary4=0;
            for z=1:size(IsoSummary3,1)
                if IsoSummary3(z,3)==0 && IsoSummary3(z,4)~=0
                    if IsoSummary3(z,1)~=0
                        for u=1:size(IsoSummary3,1)
                            if IsoSummary3(z,1)==IsoSummary3(u,1) && ...
                                    IsoSummary3(z,2)==IsoSummary3(u,2) && ...
                                    IsoSummary3(u,3)~=0
                                if IsoSummary3(u+1,4)~=0
                                    for v=7:size(IsoSummary3,2)
                                        if IsoSummary3(u,v)==0
                                            v0=v-1;
                                            break
                                        end
                                    end
                                    for v=7:size(IsoSummary3,2)
                                        if IsoSummary3(z,v)>0
                                            IsoSummary3(u,v0+v-6)=IsoSummary3(z,v);
                                        end
                                    end
                                else
                                    if abs(IsoSummary3(u,6)-IsoSummary3(z,6))<abs(IsoSummary3(u+1,6)-IsoSummary3(z,6))
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(u,v)==0
                                                v0=v-1;
                                                break
                                            end
                                        end
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(z,v)>0
                                                IsoSummary3(u,v0+v-6)=IsoSummary3(z,v);
                                            end
                                        end
                                    else
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(u+1,v)==0
                                                v0=v-1;
                                                break
                                            end
                                        end
                                        for v=7:size(IsoSummary3,2)
                                            if IsoSummary3(z,v)>0
                                                IsoSummary3(u+1,v0+v-6)=IsoSummary3(z,v);
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            for z=1:size(IsoSummary3,1)
                if IsoSummary3(z,3)>0 || (IsoSummary3(z,3)==0 && IsoSummary3(z,4)==0 && IsoSummary3(z-1,3)>0)
                    nIsoSummary4=nIsoSummary4+1;
                    IsoSummary4(nIsoSummary4,1:size(IsoSummary3,2))=IsoSummary3(z,1:size(IsoSummary3,2));
                end
            end
            
            clear IsoSummary IsoSummary2 IsoSummary3
            
            IsoSummary=IsoSummary4;
            EInt=max(IsoSummary(:,5));
            IsoSummary(:,5)=IsoSummary(:,5)./EInt;
            nIsoSummary=size(IsoSummary,1);
            clear IsoSummary4
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            if nIsoSummary>0
                for u1=1:nIsoSummary
                    for u2=u1:nIsoSummary
                        if u1~=u2 && IsoSummary(u1,4)*IsoSummary(u2,4)~=0 && ...
                                IsoSummary(u1,4)==IsoSummary(u2,4) && ...
                                IsoSummary(u1,3)==IsoSummary(u2,3) && ...
                                IsoSummary(u1,2)==IsoSummary(u2,2) && ...
                                IsoSummary(u1,1)==IsoSummary(u2,1)
                            
                            RefIon1=IsoSummary(u1,7:size(IsoSummary,2))';
                            RefIon2=IsoSummary(u2,7:size(IsoSummary,2))';
                            RefIon=[RefIon1;RefIon2];
                            if u1<nIsoSummary
                                if IsoSummary(u1+1,4)==0;
                                    RefIon3=IsoSummary(u1+1,7:size(IsoSummary,2))';
                                    RefIon_A=[RefIon;RefIon3];
                                    clear RefIon
                                    RefIon=RefIon_A;
                                    clear RefIon_A
                                end
                            end
                            if u2<nIsoSummary
                                if IsoSummary(u2+1,4)==0;
                                    RefIon4=IsoSummary(u2+1,7:size(IsoSummary,2))';
                                    RefIon_A=[RefIon;RefIon4];
                                    clear RefIon
                                    RefIon=RefIon_A;
                                    clear RefIon_A
                                end
                            end
                            
                            RefIonShort=unique(RefIon,'rows');
                            RefIonShort=sortrows(RefIonShort,1);
                            nRefIonDS=0;
                            for j=1:size(RefIonShort,1)
                                for z=1:size(CRAD_Es,1)
                                    if RefIonShort(j,1)~=0 && RefIonShort(j,1)==CRAD_Es(z,1) ...
                                            && abs(IsoSummary(u1,4)-CRAD_Es(z,2))<TimeDifferTor
                                        nRefIonDS=nRefIonDS+1;
                                        RefIonDS(nRefIonDS,1:4)=CRAD_Es(z,1:4);
                                    end
                                end
                            end
                            RefIonDS=sortrows(RefIonDS,-3);
                            RefIonDSS=RefIonDS(:,1)';
                            IsoSummary(u1,7:nRefIonDS+6)=RefIonDSS;
                            IsoSummary(u2,7:nRefIonDS+6)=RefIonDSS;
                            clear RefIonDS RefIonDSS
                        end
                    end
                end
            end
            if nIsoSummary>1
                nIsoSummaryShort=1;
                IsoSummaryShort(nIsoSummaryShort,:)=IsoSummary(1,:);
                for u1=2:nIsoSummary
                    vot=0;
                    for u2=1:nIsoSummaryShort
                        if isequal(IsoSummaryShort(u2,1:4),IsoSummary(u1,1:4))==1 && ...
                                isequal(IsoSummaryShort(u2,7:size(IsoSummaryShort,2)),IsoSummary(u1,7:size(IsoSummary,2)))==1
                            vot=1;
                        end
                    end
                    if vot==0
                        nIsoSummaryShort=nIsoSummaryShort+1;
                        IsoSummaryShort(nIsoSummaryShort,:)=IsoSummary(u1,:);
                    end
                end
            end
            clear IsoSummary
            IsoSummary=IsoSummaryShort;
            nIsoSummary=nIsoSummaryShort;
            t01=cputime-t00;
            disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID),'P']);
            str= sprintf('%s/%s%s%s%s',new_folder,'IDCS','Sam',num2str(SamID),'P.txt');
            fid=fopen(str,'w');
            for u=1:nIsoSummary
                fprintf(fid,'%.4f ',IsoSummary(u,1));
                fprintf(fid,'%.4f ',IsoSummary(u,2));
                if IsoSummary(u,3)<MiMLinearity && IsoSummary(u,2)~=0
                    IsoSummary(u,3)=MiMLinearity;
                end
                fprintf(fid,'%.2f ',IsoSummary(u,3));
                fprintf(fid,'%.1f ',IsoSummary(u,4));
                fprintf(fid,'%.4f ',IsoSummary(u,5));
                fprintf(fid,'%.3f ',IsoSummary(u,6));
                
                for v=7:size(IsoSummary,2)
                    fprintf(fid,'%.2f ',IsoSummary(u,v));
                end
                fprintf(fid,'\n');
            end
            fclose(fid);
            clear IsoSummary
            str= sprintf('%s/%s%s%s%s',new_folder,'CRPL','Sam',num2str(SamID),'P.txt');
            fid=fopen(str,'w');
            for u=1:nCRAD_Es
                for v=1:4
                    fprintf(fid,'%.4f ',CRAD_Es(u,v));
                end
                fprintf(fid,'\n');
            end
            fclose(fid);
            clear CRAD_Es
            
        end
    end
    clearvars -except t0 IntensityThreshold_Positive IntensityThreshold_Negative ionMode PXSet RelArea MassRange MassResolution ...
        rDifferRatioControl IMI INTDiffer IRT IntensityThreshold IntersectDifferTolerance...
        IsotopeVariance MB MBLength MBWidth MIMAssocIons MassDifferTor Mats MaxIsotopeRatio MiMLinearity MiMRep NosEliDiffer...
        PXSet RedundantIons RelArea SamID SamNoEn SamNoSt SlopeDifferTolerance SlowestID TimeDifferTor TimeVariance files ...
        nOfFiles nOfMats new_folder t00 ConNo ConsideredConditionNo
    
    t01=cputime-t00;
    disp(['Calculation time = ' num2str(t01), ' seconds ', 'Sam', num2str(SamID)]);
end
t01=cputime-t00;
disp(['Calculation time = ',num2str(t01), ' seconds ']);
end



